package net.hb.crud;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate; //dao-context.xml���� �Ǹ������� bean����ȭ
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Repository
@Component
public class QnADAO {

	@Autowired
	SqlSessionTemplate temp;
	
	/*�˻�*/
	public int questionCountSearch(String skey, String sval) {
		QnADTO dto = new QnADTO();
		dto.setSkey(skey);
		dto.setSval(sval);
		return temp.selectOne("board.countAllSearch", dto);
	}
	
	/*���� ��� ===============================================================*/
	public void questionInsert(QnADTO dto) {
		temp.insert("qna.qustionInsert", dto);
	}//end
	
	/*���� ���===============================================================*/
	public List<QnADTO> questionSelect() {
		return temp.selectList("qna.questionSelect");
	}//end
	
	/*���� ���� ���*/
	public int  questionCount() { 
		return temp.selectOne("qna.countAll");
	}//end
	
	/*���� �Ѱ� ����=====================================================================*/
	public void  questionEdit(QnADTO dto) {
		System.out.println("===========DAO questionEdit=========");
		System.out.println("qtopic  : "+dto.getQtopic());
		System.out.println("qtitle  : "+dto.getQtitle());
		System.out.println("qcontent  : "+dto.getQcontent());
		System.out.println("===========DAO questionEdit=========");
		temp.update("qna.edit", dto);
	}//end
	
	/*���� �Ѱ� ����=====================================================================*/
	public void  qustionDelete(int qna_idx) { 
    	temp.delete("qna.delete", qna_idx);
    }//end
	
	/*���� �Ѱ� �� ==========================================================*/
	public QnADTO qnaDetail(int qna_idx) {
		return temp.selectOne("qna.questionDetail", qna_idx);
	}//end
	
	
	/*�亯 ����Ʈ ���===========================================================*/
	public List<QnADTO> answerSelect(int board_idx) {
		return temp.selectList("qna.answerSelect", board_idx);
	}//end
	
	/*�亯 ���� ���===========================================================*/
	public void answerCount(int qna_idx) {
		QnADTO dto = new QnADTO();
		int acnt = temp.selectOne("qna.answerCount", qna_idx);
		dto.setAcnt(acnt);
	}//end
	
	/*�亯 �Ѱ� ����=================================================================*/
	public void answerInsert(QnADTO dto) {
		temp.insert("qna.answerInsert", dto);
	}//end
	
	/*�亯 �Ѱ� ���=================================================================*/
	public QnADTO answerSelectOne(int Answer_idx) {
		return temp.selectOne("qna.answerSelectOne", Answer_idx);
	}//end
	
	/*�亯 ����*/
	public void  answerEdit(QnADTO dto) { 
    	temp.update("qna.answerEdit", dto);
    }//end
	
	/*���� �Ѱ� ����=====================================================================*/
	public void  answerDelete(int answer_idx) { 
    	temp.delete("qna.replyDelete", answer_idx);
    }//end
	
	
}//QnADAO class END



