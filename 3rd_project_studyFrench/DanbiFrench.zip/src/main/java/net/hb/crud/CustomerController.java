
package net.hb.crud;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;

import java.net.URLEncoder;


@Controller
public class CustomerController {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Inject
	@Autowired
	ServletContext application;
	
	@Inject
	@Autowired
	CustomerDAO dao;

	@Inject
	@Autowired
	BoardDAO bdao;
	
	@Inject
	@Autowired
	QnADAO qdao;
	
	/*������������ �����̵� ====================================================*/
	@RequestMapping("/mypage.do")
	public ModelAndView mypage_select(@RequestParam("custid") String custid, BoardDTO dto, HttpServletRequest session) {
		ModelAndView mav = new ModelAndView();
		dto.setCustid(custid);
		dto = dao.infoSelect(dto);
		int bcnt = dao.boardListCount(custid);
		
		List<BoardDTO> blist = dao.mypage_BoardSelect(dto);
		
		mav.addObject("bcnt", bcnt);
		mav.addObject("dto", dto);
		mav.addObject("bdto", blist);
		return mav;
	}//end
		
		
	/*�ۼ��� ��� ����Ʈ ==============================================================*/
	@RequestMapping("/replyList.do")
	public ModelAndView replyList(@RequestParam("custid") String custid, BoardDTO dto) {
		ModelAndView mav = new ModelAndView();
		List<BoardDTO> rdto = dao.replyList(custid);
		BoardDTO cdto = dao.infoSelect(dto);
		int rcnt = dao.replyListCount(custid);
		
		mav.addObject("rcnt", rcnt);
		mav.addObject("rdto", rdto);
		mav.addObject("cdto", cdto);
		mav.setViewName("mypage_replyList");
		return mav;
	}//end
	
	
	
	/*�ۼ��� ���� ����Ʈ======================================================================*/
	@RequestMapping("/questionList.do")
	public ModelAndView questionList(@RequestParam("custid") String custid, BoardDTO dto) {
		ModelAndView mav = new ModelAndView();
		List<BoardDTO> qdto = dao.questionList(custid);
		BoardDTO cdto = dao.infoSelect(dto);
		int qcnt = dao.questionListCount(custid);
		
		mav.addObject("qcnt", qcnt);
		mav.addObject("qdto", qdto);
		mav.addObject("cdto", cdto);
		mav.setViewName("mypage_questionList");
		return mav;
	}//end
	
	
	/*�ۼ��� �亯 ����Ʈ======================================================================*/
	@RequestMapping("/answerList.do")
	public ModelAndView answerList(@RequestParam("custid") String custid, BoardDTO dto) {
		ModelAndView mav = new ModelAndView();
		List<BoardDTO> adto = dao.answerList(custid);
		BoardDTO cdto = dao.infoSelect(dto);
		int acnt = dao.questionListCount(custid);
		
		mav.addObject("acnt", acnt);
		mav.addObject("adto", adto);
		mav.addObject("cdto", cdto);
		mav.setViewName("mypage_answerList");
		return mav;
	}//end
	
	/*��õ�� �� ����Ʈ======================================================================*/
	@RequestMapping("/heartList.do")
	public ModelAndView heartList(@RequestParam("custid") String custid, BoardDTO dto) {
		ModelAndView mav = new ModelAndView();
		List<BoardDTO> hdto = dao.heartList(custid);
		BoardDTO cdto = dao.infoSelect(dto);
		int hcnt = dao.heartListCount(custid);
		
		mav.addObject("hcnt", hcnt);
		mav.addObject("hdto", hdto);
		mav.addObject("cdto", cdto);
		mav.setViewName("mypage_heartList");
		return mav;
	}//end
	
	/*��� �Ѱ� ���� replyDelete.do*/
	@RequestMapping("/myreplyDelete.do")
	public String reply_delete(@RequestParam("idx") int rboard_idx, @RequestParam("custid") String custid, Model model) {
		bdao.replyDelete(rboard_idx);
		return "redirect:/replyList.do?custid="+custid;
	}//end
	
	/*���� �Ѱ� ���� answerDelete.do*/
	@RequestMapping("/myquestionDelete.do")
	public String qustion_Delete(@RequestParam("custid") String custid, @RequestParam("idx") int qna_idx, Model model) {
		qdao.qustionDelete(qna_idx);
		return "redirect:/questionList.do?custid="+custid;
	}//end
}//class END







