DROP TABLE TCustomerInfo;
DROP TABLE TStudentCourseInfo;
DROP TABLE TLeaderClubList;
DROP TABLE TClubInfo;
DROP TABLE TStudentCardPay;
DROP TABLE TStudentBankPay;
DROP TABLE TExpertise;
DROP TABLE TLicense; 
DROP TABLE TBoard;
COMMIT;




CREATE TABLE TCUSTOMERINFO(
    CustId VARCHAR(100),
    CustName VARCHAR(50),
    CustPassword VARCHAR(50),
    CustEmail VARCHAR(150),
    CustCall VARCHAR(100),
    CustGender VARCHAR(3),
    CustBirth DATE,
    CustAddress VARCHAR(200),
    CustPicture VARCHAR(200), 
    LeadName VARCHAR2(200),
    LeadIntro VARCHAR2(1000),
    LeadLocal VARCHAR2(100),
    LeadBankName VARCHAR2(100),
    LeadBankNum VARCHAR2(50),
    LeadCertificate VARCHAR2(3) DEFAULT 'N',
    LeadRegiDate DATE,
    LeadStopDate DATE DEFAULT TO_DATE('10000101','YY/MM/DD'),
    PRIMARY KEY(CustID)
);

CREATE TABLE TClubInfo(
    CustID VARCHAR2(100),
    ClubCode VARCHAR2(10),
    ClubDate DATE,
    CLUBTITLE VARCHAR2(500),
    ClubStart DATE,
    ClubEnd DATE,
    ClubPicture1 VARCHAR2(200),
    ClubPicture2 VARCHAR2(200),
    ClubPicture3 VARCHAR2(200),
    ClubPicture4 VARCHAR2(200),
    ClubMax VARCHAR2(10),
    ClubCurrentNum VARCHAR2(10),
    ClubLocation VARCHAR2(50),
    ClubAddress VARCHAR2(500),
    Clubsupplies VARCHAR2(300),
    AvgStarLevel VARCHAR2(30),
    ClubAmount VARCHAR2(50),
    CLUBSKILLLEVEL VARCHAR2(20) ,
    CLUBGENRE VARCHAR2(50),
    CLUBINTRO VARCHAR2(1000),
    PRIMARY KEY( CustID, ClubCode, ClubDate, ClubStart )
);


CREATE TABLE TSTUDENTCOURSEINFO(
   CUSTID VARCHAR2(100),    
   CLUBCODE VARCHAR2(20),  
   CLUBDATE DATE,
   ClubStart DATE,          
   APPLYDATE DATE,          
   CANCELDATE DATE,          
   SETTLEMENTTYPE VARCHAR2(20),  
   SettlementAmount VARCHAR2(10),  
   SettlementDate DATE,
   STARLEVEL1 VARCHAR2(10),  
   STARLEVEL2 VARCHAR2(10),  
   STARLEVEL3 VARCHAR2(10),  
   REVIEW VARCHAR2(2000), 
   REVIEWDATE DATE,
   PRIMARY KEY(CUSTID, CLUBCODE, CLUBDATE, ClubStart )
);


CREATE TABLE TLeaderClubList (
   CustID VARCHAR2(100),
   ClubCode VARCHAR2(10),
   CreateDate DATE,
   CloseDate DATE,
   ClubGenre VARCHAR2(100),
   ClubIntro VARCHAR2(2000),
   RePicture VARCHAR2(150),
   PRIMARY KEY ( CustID,ClubCode )
);




CREATE TABLE TLICENSE (
    CustID VARCHAR(15),
    License1 VARCHAR2(100),
    License2 VARCHAR2(100),
    License3 VARCHAR2(100),
    License4 VARCHAR2(100),
    License5 VARCHAR2(100),
    PRIMARY KEY(CustID)
);




CREATE TABLE TEXPERTISE(
    CustID VARCHAR2(15),
    Expertise1  VARCHAR2(100),
    Expertise2  VARCHAR2(100),
    Expertise3  VARCHAR2(100),
    Expertise4  VARCHAR2(100),
    Expertise5  VARCHAR2(100),
    PRIMARY KEY(CustID)
);



CREATE TABLE TStudentCardPay(
    CustID VARCHAR2(100),
    ClubCode VARCHAR2(10),
    CLUBDATE DATE,
    ClubStart DATE,
    PaymentDate DATE,
    CARDCOMPANY  VARCHAR2(50),
    CARDNUM VARCHAR2(30),
    CARDLimitDate DATE,
    CARDPASS VARCHAR2(30),
    PAYMENTAMT  VARCHAR2(30),
    PRIMARY KEY( CustID, ClubCode, ClubDate, ClubStart )
);

CREATE TABLE TStudentBankPay(
   CUSTID VARCHAR2(100), 
   CLUBCODE VARCHAR2(10), 
   CLUBDATE DATE,
   ClubStart DATE,
   PaymentDate DATE,
   CUSTBANKNAME VARCHAR2(50),
   CUSTBANKNUM VARCHAR2(30),
   PAYMENTAMT VARCHAR2(30), 
   PRIMARY KEY(CUSTID, CLUBCODE, CLUBDATE, ClubStart )
);

CREATE TABLE TBoard(
    CustId VARCHAR2(100),
    CustName VARCHAR2(50),
    Title VARCHAR2(100),
    CustContent VARCHAR2(1000),
    LikeNum VARCHAR2(100),
    WriteDate DATE
);

/*Admin Account*/
INSERT INTO TCUSTOMERINFO (CUSTID, CUSTNAME, CUSTPASSWORD,CUSTEMAIL,CUSTCALL,CUSTGENDER,CUSTBIRTH,CUSTADDRESS,CUSTPICTURE)
VALUES('dev_dansoo','admin','1234','admin@com','01011111111','2',TO_DATE('200929','YY/MM/DD'),'TIS','../profile/profile2.png');

COMMIT;
