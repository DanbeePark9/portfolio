var flag=false; //null 체크여부


//버튼 누르면 배경색깔 변경 
function Fclick(obj){
	if(obj.getAttribute('class') == "none"){
		if(document.getElementById('genderResult').value == 0){
			document.getElementById('GENDER_M').setAttribute('class', 'none');
			document.getElementById('GENDER_M').style.backgroundColor = 'MistyRose';
		}
		obj.style.backgroundColor = '#ffa8d4';
		document.getElementById('genderResult').setAttribute('value', '1');
	} 
	else {
		document.getElementById('GENDER_F').style.backgroundColor = 'MistyRose';
	}
	return;
}



function Mclick(obj){
	if(obj.getAttribute('class') == "none"){
		if(document.getElementById('genderResult').value == 1){
			document.getElementById('GENDER_F').setAttribute('class', 'none');
			document.getElementById('GENDER_F').style.backgroundColor = 'MistyRose';
		}
		obj.style.backgroundColor = '#ffa8d4';
		document.getElementById('genderResult').setAttribute('value', '0');
	} 
	else {
		document.getElementById('GENDER_F').style.backgroundColor = 'MistyRose';
	}
	return;
}



function hidepw(obj, maxByte){
	var strValue = obj.value;
	var strLen = strValue.length;
	var totalByte = 0;
	var len = 0;
	var oneChar ="";
	var str2 ="";
	
	for (var i = 0; i < strLen; i++) {	//한글자씩 가져와서
		oneChar = strValue.charAt(i);
		if (escape(oneChar).length > 4)	{	//길이가 4초과=유니코드/한글이면
			totalByte += 2;	//2바이트로 넣어주고
		} else {
			totalByte++;	//아니면 1바이트로 처리
		}
		if(totalByte <= maxByte) {
			len = i+1;	//입력된 데이터의 자리수 기억해주기
		}
	}
	if (totalByte > maxByte) {
		alert('비밀번호는 4자리 숫자만 가능합니다.');
		str2 = strValue.substr(0, len);	//아까 기억한 자리수까지만큼 잘라서 넣어주기
		obj.value = str2;
	}
}
//비밀번호 확인 체크
function checkpw(){
	var pw1 = signup_form.password.value;
	var pw2 = signup_form.password2.value;
	var label = document.getElementById("pwcon");
	
	if(pw1 == pw2) {
		label.innerHTML = "비밀번호가 일치합니다.";
		flag = true;	//비번일치플래그 true로 해줌
	} else {
		label.innerHTML = "<font color='red'>비밀번호가 일치하지 않습니다.</font>";
	}
}


/*아이디 중복체크*/
function checkId(){
	var a = document.signup_form.id.value;
		signup_form.id.focus();
		open("cus_IDcheck.jsp?ID="+a,"cus_IDcheck.jsp","width=400, height=200, left=700, top=300");
		return;
}//end


/*생일 형식 체크*/
function checkBirth() {
	   var birth = signup_form.birth.value.length;
	   var birth_label = document.getElementById("birth_label");
	   
	   if( birth > 6 || birth < 6 ) {
		   birth_label.innerHTML = "<font color='red'> ex)951220 형식으로 작성하세요</font>";
	   }else{
		   birth_label.innerHTML = "";
	   }
	   
}

/*이메일 형식 체크*/
function checkEmail(){
	   var mail = signup_form.email.value;
	   var mail_reg = /^([\S]{2,16})@([a-zA-Z]{2,10})\.([a-zA-Z]{2,10})$/;
	   
	   if( mail_reg.test(mail)==false){
	      msg = "<font color='red'>이메일 형식을 체크해주세요.</font>";
	      document.getElementById("emailspan").innerHTML = msg;
	      flag=false;
	      return;
	   }else{
	        flag = true;
	        document.getElementById("emailspan").innerHTML="";
	     }
}


/*프로필사진 미리보기*/
function handleFileSelect() {
    var files = document.getElementById('file').files[0];
    var reader = new FileReader();
    reader.onload = (function(theFile) {
      return function(e) {
        var img_view = ['<img src="', e.target.result, '" name="', escape(theFile.name), '"  width=300 height=200/>'].join('');                
        document.getElementById('photo_preview').innerHTML = img_view;
      };
    })(files);
    reader.readAsDataURL(files);    
}


/*취소 확인창*/
function confirm(){
	if(confirm("정말로 취소하시겠어요?")==true){
		location.href="cus_index.jsp";
	}else{
		return;
	}
}


/*널체크*/
function nullcheck(){
	var flag  	= false;
	var name 	= signup_form.name.value;
	var id 		= signup_form.id.value;
	var pw 		= signup_form.password.value;
	var pw2 	= signup_form.password2.value;
	var phone1 	= signup_form.phone1.value;
	var phone2 	= signup_form.phone2.value;
	var phone3 	= signup_form.phone3.value;
	var email	= signup_form.email.value;
	var local   = signup_form.local.value;
	var gender  = signup_form.genderResult.value;
	var birth   = signup_form.birth.value;
	var file    = signup_form.file.value;
	var check   = signup_form.agree.checked;
	
	
	
	if(name==""||name==null){
		alert('이름을 입력해주세요.');
		signup_form.name.focus();
		return;
	}
	if(id==""||id==null){
		alert('아이디를 입력해주세요.');
		signup_form.id.focus();
		return;
	} 
	if(pw==""||pw==null){
		alert('비밀번호를 입력해주세요.');
		signup_form.pw.focus();
		return;
	} 
	if(pw2==""||pw2==null){
		alert('비밀번호 확인을 입력해주세요.');
		signup_form.pw2.focus();
		return;
	}
	if(email==""||email==null){
		alert('이메일을 입력해주세요.');
		signup_form.email.focus();
		return;
	}
	if(phone1==""||phone1==null){
		alert('핸드폰 번호 앞자리를 입력해주세요.');
		signup_form.phone1.focus();
		return;
	}
	if(phone2==""||phone2==null){
		alert('핸드폰번호 가운데 자리를 입력해주세요.');
		signup_form.phone2.focus();
		return;
	}
	if(phone3==""||phone3==null){
		alert('핸드폰번호 마지막 자리를 입력해주세요.');
		signup_form.phone3.focus();
		return;
	}
	if(gender==""||gender==null){
		alert('성별을 선택해주세요.');
		return;
	}
	if(birth==""||birth==null){
		alert('생년월일을 입력해주세요.');
		return;
	}
	if(local=="x"){
		alert('지역을 선택해주세요.');
		return;
	}
	if(file==""||file==null){
		alert('프로필 사진을 선택해주세요.');
		return;
	}
	if(check==false){
		alert('이용약관에 동의해주세요.');
		return;
	}
	
	document.signup_form.submit();
}
