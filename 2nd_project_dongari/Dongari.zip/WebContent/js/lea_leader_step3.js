
//등록 완료 및 취소 안내창
function notice_completed(){
   if(confirm('동아리를 개설하시겠습니까?')){
      location.href='/dinsert1.do';
   } else {
      alert('동아리개설이 취소되었습니다.')
      location.href='/dselect.do';
   }
   return;
}
   



 /*프로필사진 미리보기*/
 function handleFileSelect(num) {
     var files = document.getElementById('file').files[0];
     var reader = new FileReader();
     reader.onload = (function(theFile) {
       return function(e) {
         var img_view = ['<img src="', e.target.result, '" name="', escape(theFile.name), '"  width=350 height=250/>'].join('');                
         document.getElementById('photo_preview').innerHTML = img_view;
       };
     })(files);
     reader.readAsDataURL(files);    
 }
 
 
 function nullCheck(){
	 var file = document.getElementById('upload-name').value;
	 var genre = document.getElementById('genre').value;
	 var intro = document.getElementById('intro').innerHTML;
	 var local = document.getElementById('local').value;
	 
	 if(file==""||file==null){
	 }
 }
 
