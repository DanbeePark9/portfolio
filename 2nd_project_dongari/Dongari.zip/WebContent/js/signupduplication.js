function doublecheck(){
	var id = signup.id.value;
	
}