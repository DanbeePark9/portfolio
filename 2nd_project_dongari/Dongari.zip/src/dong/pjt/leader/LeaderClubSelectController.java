package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;


@WebServlet("/lclubselect.do")
public class LeaderClubSelectController extends HttpServlet {
   private static final long serialVersionUID = 1L;
   static int num = 0;
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }
   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
       PrintWriter out = response.getWriter();
       HttpSession session = request.getSession();
       
       // 리더 정보
       LeaderSQL SQL = new LeaderSQL();
       String LeaderID = request.getParameter("leaderID");
       LeaderDTO dto = SQL.leaderProfile(LeaderID);
      
       // 동아리 목록
       ArrayList<DongariDTO> list = SQL.LeadClubBox( LeaderID );

       request.setAttribute("list", list);
       request.setAttribute("dto", dto);
       request.setAttribute("LeaderID", LeaderID);
     
       RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_leaderProfile.jsp");
       dis.forward(request, response);
   }
}