package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;

@WebServlet("/linsert1.do")
public class LeaderInsertSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out     = response.getWriter();
      HttpSession session = request.getSession();
      
       LeaderSQL LeadSQL      = new LeaderSQL();
       String ID              = (String) session.getAttribute("CustId");
       String LEADCERTIFICATE = LeadSQL.LeadCheck(ID);
       
       if( LEADCERTIFICATE==null) {
             RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_leader_step1.jsp");
             dis.forward(request, response);
      }else {
         RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_index.jsp");
          dis.forward(request, response);
      }
   }
}