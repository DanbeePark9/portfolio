package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;
import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;
import club.pjt.sql.ReviewDTO;
import club.pjt.sql.CalendarDTO;;


@WebServlet("/lselect.do")
public class LeaderSelectController extends HttpServlet {
   private static final long serialVersionUID = 1L;
   static int num = 0;
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }
   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
       PrintWriter out = response.getWriter();
       HttpSession session = request.getSession();
         
       String ID = (String) session.getAttribute("CustId");
       LeaderSQL LeadSQL =  new LeaderSQL();
       DongariSQL DongSQL = new DongariSQL();
       LeaderDTO LeadDTO =  LeadSQL.LeadSelect(ID);
       
       if( LeadDTO.getLeadName() == null || LeadDTO.getLeadName() == "" ) {
           PrintWriter writer = response.getWriter(); 
           writer.println("<script>alert('리더 페이지에 접근하려면 리더 권한이 필요 합니다'); location.href='/jsp/lea_leader_step1.jsp';</script>");
           writer.close();
       } 
       String LEADERNICKNAME = LeadDTO.getLeadName();
       String LEARDERINTRO   = LeadDTO.getLeadIntro();
       String CUSTPICTURE    = LeadDTO.getCustPicture();
       
       /*0926=================================================*/
       //경력 유무
       int ExpertExist = LeadSQL.LeadExpertExist(ID);
       request.setAttribute("ExpertExist", ExpertExist); //1이면 경력 있음 0이면 경력 없음
       
       //경력 내역
       LeaderDTO Experties =  LeadSQL.LeadExpertSelect(ID);
       request.setAttribute("EXP", Experties);
       
       //자격증 유무
       int LicenseExist = LeadSQL.LeadLicenseExist(ID);
       request.setAttribute("LicenseExist", LicenseExist);
       
       //자격증 내역
       LeaderDTO License =  LeadSQL.LeadLicenseSelect(ID);
       request.setAttribute("LIC", License);
       /*0926=================================================*/
       
       
       // 대금 내역
       ArrayList<DongariDTO>  DTO = LeadSQL.LeadClubAmtSelect(ID);
       if(DTO.isEmpty()) {
          String zeroPay = "0";
          request.setAttribute("zeroPay", zeroPay);
       }else {
          request.setAttribute("DTO", DTO);
       }
       // 일정
       CalendarDTO calDTO = new CalendarDTO();
       calDTO.setCustId(ID);
       String month   = request.getParameter("month");
       
       if( month == null || month == "" ) {
          Date date = new Date();
           int iMonth = date.getMonth()+1;
           month = Integer.toString(iMonth);
           calDTO.setMonth(month);
       }else {
           calDTO.setMonth(month);
       }
         ArrayList<CalendarDTO> Callist = LeadSQL.LeadCalendarSelect (calDTO);
         
         CalendarDTO day01 = Callist.get(0); request.setAttribute("day01", day01);
         CalendarDTO day02 = Callist.get(1); request.setAttribute("day02", day02);
         CalendarDTO day03 = Callist.get(2); request.setAttribute("day03", day03);
         CalendarDTO day04 = Callist.get(3); request.setAttribute("day04", day04);
         CalendarDTO day05 = Callist.get(4); request.setAttribute("day05", day05);
         CalendarDTO day06 = Callist.get(5); request.setAttribute("day06", day06);
         CalendarDTO day07 = Callist.get(6); request.setAttribute("day07", day07);
         CalendarDTO day08 = Callist.get(7); request.setAttribute("day08", day08);
         CalendarDTO day09 = Callist.get(8); request.setAttribute("day09", day09);
         CalendarDTO day10 = Callist.get(9); request.setAttribute("day10", day10);
         CalendarDTO day11 = Callist.get(10); request.setAttribute("day11", day11);
         CalendarDTO day12 = Callist.get(11); request.setAttribute("day12", day12);
         CalendarDTO day13 = Callist.get(12); request.setAttribute("day13", day13);
         CalendarDTO day14 = Callist.get(13); request.setAttribute("day14", day14);
         CalendarDTO day15 = Callist.get(14); request.setAttribute("day15", day15);
         CalendarDTO day16 = Callist.get(15); request.setAttribute("day16", day16);
         CalendarDTO day17 = Callist.get(16); request.setAttribute("day17", day17);
         CalendarDTO day18 = Callist.get(17); request.setAttribute("day18", day18);
         CalendarDTO day19 = Callist.get(18); request.setAttribute("day19", day19);
         CalendarDTO day20 = Callist.get(19); request.setAttribute("day20", day20);
         CalendarDTO day21 = Callist.get(20); request.setAttribute("day21", day21);
         CalendarDTO day22 = Callist.get(21); request.setAttribute("day22", day22);
         CalendarDTO day23 = Callist.get(22); request.setAttribute("day23", day23);
         CalendarDTO day24 = Callist.get(23); request.setAttribute("day24", day24);
         CalendarDTO day25 = Callist.get(24); request.setAttribute("day25", day25);
         CalendarDTO day26 = Callist.get(25); request.setAttribute("day26", day26);
         CalendarDTO day27 = Callist.get(26); request.setAttribute("day27", day27);
         CalendarDTO day28 = Callist.get(27); request.setAttribute("day28", day28);
         CalendarDTO day29 = Callist.get(28); request.setAttribute("day29", day29);
         CalendarDTO day30 = Callist.get(29); request.setAttribute("day30", day30);
         CalendarDTO day31 = Callist.get(30); request.setAttribute("day31", day31);
         
      // 동아리 현황
         ArrayList<DongariDTO> Genrelist = DongSQL.LeadClubSelect(ID);
         
         if(Genrelist.isEmpty()==true) {
            String zeroTitle = "0";
            request.setAttribute("zeroTitle", zeroTitle);
         }else {
            request.setAttribute("Genrelist", Genrelist);
         }
         
         // 리뷰
         ReviewDTO LEADER = new ReviewDTO();
         String pageNum     = request.getParameter("pageNum");
         String ClubTitle   = request.getParameter("ClubTitle");
         LEADER.setCustId(ID);
         ArrayList<String> list = LeadSQL.LeadClubReviewTitle(ID);
         
         String zeroPay = "";
         if( ClubTitle == null ||  ClubTitle == "" ) {
            ClubTitle ="";
         }else if( ClubTitle.equals("up") ){
            if( num == list.size()-1 ) {
                LEADER.setClubTitle(list.get(num));
                ClubTitle = list.get(num);
            }else {
                LEADER.setClubTitle(list.get(++num));
                ClubTitle = list.get(num);
            }
         }else if( ClubTitle.equals("down") ){
            if( num == 0 ) {
                LEADER.setClubTitle(list.get(num));
                ClubTitle = list.get(num);
            }else {
                LEADER.setClubTitle(list.get(--num));
                ClubTitle = list.get(num);
            }
         }else{
               LEADER.setClubTitle(list.get(0));
               ClubTitle = list.get(0);
         }
         ArrayList<ReviewDTO> REVIEW =  LeadSQL.LeadClubReview( LEADER, pageNum );

         request.setAttribute("ClubTitle", ClubTitle);
         request.setAttribute("REVIEW", REVIEW);
         request.setAttribute("LEADERNICKNAME", LEADERNICKNAME);
         request.setAttribute("LEARDERINTRO"  , LEARDERINTRO  );
         request.setAttribute("CUSTPICTURE"    , CUSTPICTURE  );
         RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_profile.jsp");
         dis.forward(request, response);
   }
}