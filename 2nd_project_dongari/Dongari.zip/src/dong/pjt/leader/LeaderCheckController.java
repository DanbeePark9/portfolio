package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;

@WebServlet("/lCheck.do")
public class LeaderCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		String CustId = request.getParameter("CustId");
		System.out.println("CustId : " + CustId);
		
		if(CustId.contains("null")) {
			out.println("<script>alert('로그인하세요');</script>");
			RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_login_check.jsp");
			dis.forward(request, response);
			return;
		} else {
			LeaderSQL leadSQL = new LeaderSQL();

			String LeadCheck = leadSQL.LeadCheck(CustId);
			
			if(LeadCheck.contains("N")) {
				session.setAttribute("CustId", CustId);
				RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_leader_step1.jsp");
				dis.forward(request, response);
			} 
			
			if(LeadCheck.contains("Y")) {
				out.println("<script>alert('이미 리더 등록을 하셨습니다.');</script>");
				RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_leader_check.jsp");
				dis.forward(request, response);
			}
		}
	}
}
