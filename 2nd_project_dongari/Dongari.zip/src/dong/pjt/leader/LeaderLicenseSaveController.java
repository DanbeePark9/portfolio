package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.DongariDTO;
import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;

@WebServlet("/lLicenseSave.do")
public class LeaderLicenseSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out     = response.getWriter();
      HttpSession session = request.getSession();
      
      String ID    = (String) session.getAttribute("CustId");
      String lic1 = request.getParameter("lic1");
      String lic2 = request.getParameter("lic2");
      String lic3 = request.getParameter("lic3");
      String lic4 = request.getParameter("lic4");
      String lic5 = request.getParameter("lic5");
      
      LeaderSQL LeadSQL = new LeaderSQL();
      LeadSQL.UpdateLicense(ID, lic1, lic2, lic3, lic4, lic5);

      RequestDispatcher dis = request.getRequestDispatcher("/lselect.do");
      dis.forward(request, response);
   }
}