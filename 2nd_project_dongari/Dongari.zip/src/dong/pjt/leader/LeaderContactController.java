package dong.pjt.leader;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.CustomerFront;
import club.pjt.sql.DongariDTO;
import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;
import club.pjt.sql.ReviewDTO;

@WebServlet("/lcontact.do")
public class LeaderContactController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out     = response.getWriter();
      HttpSession session = request.getSession();
      
      LeaderSQL LeadSQL  = new LeaderSQL();
      String ID    = (String) session.getAttribute("CustId");
      
      //  ex) 10120920 => 10월 12일 09:20
      String idx1 = request.getParameter("idx1");
      // 달력에서 누른 title 정보 구해오기
      String title = LeadSQL.LeadStudentTitle(ID, idx1);
      // 수업 신청한 회원정보
      ArrayList<CustomerFront> list = LeadSQL.LeadStudentInfo(ID, idx1);
      // 리뷰
      ArrayList<ReviewDTO> Leadreview = LeadSQL.LeadReview(ID);
      // 동아리 정보
      DongariDTO DongInfo = LeadSQL.LeadDongariInfo(ID, title, idx1);
      // 평균 평점
      ReviewDTO totalDTO = Leadreview.get(Leadreview.size()-1);
      String totalAVG = totalDTO.getTotalStarLevel();

      request.setAttribute("DongInfo", DongInfo  );
      request.setAttribute("totalAVG", totalAVG  );
      request.setAttribute("Leadreview", Leadreview  );
      request.setAttribute("list"  , list  );
      request.setAttribute("title"  , title);
    
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_contact.jsp");
      dis.forward(request, response);
      
   }
}