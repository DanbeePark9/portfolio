package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariLeaderDTO;
import club.pjt.sql.DongariSQL;
import club.pjt.sql.LeaderSQL;
import club.pjt.sql.ReviewDTO;

@WebServlet("/dselect.do")
public class DongariSelectController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();

      String ID = (String) session.getAttribute("CustId");
      DongariSQL DongSQL = new DongariSQL();
      DongariDTO DongDTO = new DongariDTO();
      LeaderSQL  LeadSQL =  new LeaderSQL();
      
      // 상세보기
      String LeaderId = request.getParameter("CustId");
      String clubCode = request.getParameter("clubCode");
      String clubDate = request.getParameter("clubDate");
      ArrayList<DongariDTO> list;
      
      if( clubDate==null ) {
         String clubTitleCode = request.getParameter("clubTitleCode");
         DongDTO.setDongDetail2( LeaderId, clubCode, clubTitleCode );
         list = DongSQL.DongDetail2(DongDTO);
      }else {
         DongDTO.setDongDetail1( LeaderId, clubCode, clubDate );
         list = DongSQL.DongDetail1(DongDTO);
      }

      request.setAttribute("list", list);
      String clubStart = request.getParameter("clubStart");
      String clubAmount = request.getParameter("clubAmount");
      
      // 확인 및 결제창으로 보낼 때 필요한 속성
      request.setAttribute("LeaderId", LeaderId);
      request.setAttribute("clubCode", clubCode);
      request.setAttribute("clubDate", clubDate);
      request.setAttribute("clubAmount", clubAmount);
      request.setAttribute("clubStart", clubStart);
      
      // 수업 사진
      DongariDTO  clubMain = list.get(0);
      request.setAttribute("clubMain", clubMain);
      
      // 수업 소개
      DongDTO.setClubTitle(clubMain.getClubTitle());
      DongariLeaderDTO LEADER = DongSQL.DongLeadDetail(DongDTO);
      request.setAttribute("LEADER", LEADER);
      
        // 리뷰
      ReviewDTO Review = new ReviewDTO();
      
      ArrayList<ReviewDTO> ReviewList;
      String ClubTitle = clubMain.getClubTitle();
      String pageNum = request.getParameter("pageNum");
      
      Review.setClubTitle(ClubTitle);
      Review.setClubDate(clubDate);
      Review.setCustId(LeaderId);

      if( pageNum==null || pageNum=="") {
         ReviewList = LeadSQL.LeadClubReview (Review,"1");
      }else {
         ReviewList = LeadSQL.LeadClubReview (Review, pageNum);
      }
      request.setAttribute("ClubTitle" , ClubTitle);
      request.setAttribute("ReviewList", ReviewList);
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/club_detail.jsp");
      dis.forward(request, response);
      
   }
}