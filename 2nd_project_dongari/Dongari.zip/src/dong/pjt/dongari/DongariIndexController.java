package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;

@WebServlet("/dindex.do")
public class DongariIndexController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();
      
      
      DongariSQL DongSQL = new DongariSQL();
      
      /*인기동아리*/
      DongariDTO PopDTO = DongSQL.DongPopular();

      /*신규동아리*/
      DongariDTO NewDTO = DongSQL.DongNew();
      
      session.setAttribute("Pop", PopDTO);
      session.setAttribute("New", NewDTO);
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_index.jsp");
      dis.forward(request, response);
   }
}