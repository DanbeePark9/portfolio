package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;

@WebServlet("/dlist.do")
public class DongariListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		/*페이지 관련 전역변수*/
	  String pnum;
	  int pageNUM, pagecount;  
	  int start, end;
	  int startpage, endpage;
	  int tmp; 
	  
	  /*사용자가 선택한 페이지넘버*/
	  pnum = request.getParameter("pageNum"); //1
	  if(pnum==null||pnum=="") {pnum="1";}
	  pageNUM = Integer.parseInt(pnum); //1
	  session.setAttribute("pageNUM", pageNUM);//1
	  
	  /*14페이지를 선택했을때 가장 위에 있는 행번호와 끝번호*/
		start = (pageNUM-1)*10+1; //행번호 131번
		end   = (pageNUM*10);			//행번호 140번
		
		/*데이터 select 해오기*/
		String ClubCode = request.getParameter("ClubCode");
		DongariSQL DongSQL = new DongariSQL();
		int Gtotal = DongSQL.RecordTotal(ClubCode); // 요가 레코드 수 뽑아오기
		session.setAttribute("Gtotal", Gtotal);
		
		String ClubGenre = DongSQL.ClubGenreSelect(ClubCode);
		session.setAttribute("ClubGenre", ClubGenre);
		
		//총 레코드 갯수를 10으로 나눠서 총 페이지수를 뽑아오기
		if(Gtotal%10 == 0) {pagecount = Gtotal/10;}
		else {pagecount = (Gtotal/10)+1;}
		session.setAttribute("pagecount", pagecount);
		
		tmp = (pageNUM-1)%10; 		//3
		startpage = pageNUM-tmp; 	//11p
		endpage   = startpage+9;	//20p
		if(endpage>pagecount) {endpage=pagecount;}
		session.setAttribute("startpage", startpage);
		session.setAttribute("endpage", endpage);
		
		ArrayList<DongariDTO> listDTO = DongSQL.DongListSelect(ClubCode, start, end); //각 클럽 코드를 집어넣어서 해당 코드와 일치하는 동아리들만 모아놓은것
		session.setAttribute("listDTO", listDTO);
		session.setAttribute("ClubCode", ClubCode);
		
		RequestDispatcher dis = request.getRequestDispatcher("/jsp/club_list.jsp");
		dis.forward(request, response);
	}
}
