package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSession;

import club.pjt.check.ClubGenre;
import club.pjt.check.LeadLocal;
import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;

@WebServlet("/dinsert1.do")
public class DongariInsertSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html; charset=UTF-8");
      request.setCharacterEncoding("UTF-8");
      HttpSession session = request.getSession();
      
      DongariDTO DongDTO = new DongariDTO();
      DongariSQL DongSQL = new DongariSQL();
      ClubGenre CG = new ClubGenre();
      LeadLocal LL = new LeadLocal();
      
      String RePicture = "../repicture/"+request.getParameter("file");
      String ClubGenre = request.getParameter("dGenre");
      String ClubIntro = request.getParameter("dIntro");
      String ClubLocal = request.getParameter("dLocal");
      String ClubCode  = "SP" + ClubGenre;

      // 종목코드, 지역코드는 변경 전에 띄운다
      request.setAttribute("ClubGenre", ClubGenre);
      request.setAttribute("ClubLocal", ClubLocal);
      
      ClubCode = DongSQL.ClubCodeSelect(ClubCode);
      String FrontClubGenre = CG.ClubGenreToKorean(ClubGenre);
      String FrontClubLocal = LL.LeadLocalToKorean(ClubLocal);
      
      DongDTO.setFile(RePicture);
      DongDTO.setClubGenre(ClubGenre);
      DongDTO.setClubIntro(ClubIntro);
      DongDTO.setLeadLocal(ClubLocal);
      DongDTO.setClubCode(ClubCode);
      
      String ID  = (String) session.getAttribute("CustId");
      DongSQL.DongInsert(ID, DongDTO);

      // ClubCode,FrontClubGenre,FrontClubLocal 프론트형으로 변경후에 띄운다
      request.setAttribute("clubCode", ClubCode);
      request.setAttribute("RePicture", RePicture);
      request.setAttribute("ClubIntro", ClubIntro);
      request.setAttribute("FrontClubGenre", FrontClubGenre);
      request.setAttribute("FrontClubLocal", FrontClubLocal);
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_leader_step3-1.jsp");
      dis.forward(request, response);
      }
}