package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.check.ClubGenre;
import club.pjt.check.LeadLocal;
import club.pjt.sql.DongariClubDTO;
import club.pjt.sql.DongariSQL;

@WebServlet("/dclubsaveinsert.do")
public class DongariClubInsertSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       response.setContentType("text/html; charset=UTF-8");
       request.setCharacterEncoding("UTF-8");
       HttpSession session = request.getSession();
         
      DongariClubDTO DTO = new DongariClubDTO();
      DongariSQL SQL = new DongariSQL();
       ClubGenre CG = new ClubGenre();
       LeadLocal LL = new LeadLocal();
         
      String LEADERID = (String) session.getAttribute("CustId");

      System.out.println("clubCode : " + request.getParameter("clubCode"));
      System.out.println("clubGenre : " + request.getParameter("clubGenre"));
      System.out.println("clubLocal : " + request.getParameter("leadLocal"));
      
      
      DTO.setCustid(LEADERID);
      DTO.setClubcode(request.getParameter("clubCode"));
      DTO.setClubDate(request.getParameter("clubdate"));
      DTO.setClubTitle(request.getParameter("clubtitle"));
      DTO.setClubpicture1(request.getParameter("file1"));
      DTO.setClubpicture2(request.getParameter("file2"));
      DTO.setClubpicture3(request.getParameter("file3"));
      DTO.setClubpicture4(request.getParameter("file4"));
      DTO.setClubmax(request.getParameter("clubmax"));
      
      DTO.setClubAddress(request.getParameter("clubaddress"));
      DTO.setClubsupplies(request.getParameter("clubsupplies"));
      DTO.setClubamount(request.getParameter("clubamount"));
      DTO.setClubSkillLevel(request.getParameter("clubskilllevel"));
      DTO.setClubIntro(request.getParameter("clubintro"));
      DTO.setClubGenre(request.getParameter("clubGenre"));
      DTO.setLocation(request.getParameter("clubLocal"));
      
      String clubtitlecode = SQL.ClubTitleCode(request.getParameter("clubtitle"));
      DTO.setClubTitleCode(clubtitlecode);
      
      String clubstart =  request.getParameter("clubstartH")+":"+request.getParameter("clubstartM");
      DTO.setClubstart(clubstart);
      
      String clubend =  request.getParameter("clubendH")+":"+request.getParameter("clubendM") ;
      DTO.setClubend(clubend);
      
      SQL.DongClubInsert( DTO );
      
      RequestDispatcher dis = request.getRequestDispatcher("/lselect.do");
      dis.forward(request, response);
    }
}