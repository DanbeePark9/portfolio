package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;

@WebServlet("/deditSave.do")
public class DongariEditSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();
      
      DongariSQL DongSQL = new DongariSQL();
      DongariDTO DTO  = new DongariDTO();
      System.out.println("===DongariEditSaveController===");
      
      // 수업 식별 정보
      String ID  = (String) session.getAttribute("CustId");
      System.out.println("ID : " + ID);
      DTO.setCustId(ID);
      
      String ClubCode = request.getParameter("clubCode");
      System.out.println("ClubCode : " + ClubCode);
      DTO.setClubCode(ClubCode);
      
      String clubTitleCode = request.getParameter("clubTitleCode");
      System.out.println("clubTitleCode : " + clubTitleCode);
      DTO.setClubTitleCode(clubTitleCode);
      
      String clubDate = request.getParameter("clubDate");
      System.out.println("clubDate : " + clubDate);
      DTO.setClubDate(clubDate);
      
      String clubStart = request.getParameter("clubStart");
      System.out.println("clubStart : " + clubStart);
      DTO.setClubStart(clubStart);
         
      // 업데이트 정보
   
      String clubintro = request.getParameter("clubintro");
      System.out.println("clubintro : " + clubintro);
      DTO.setClubIntro(clubintro);
      
      String clubaddress = request.getParameter("clubaddress");
      System.out.println("clubaddress : " + clubaddress);
      DTO.setClubAddress(clubaddress);

      String clubmax = request.getParameter("clubmax");
      System.out.println("clubmax : " + clubmax);
      DTO.setClubMax(clubmax);

      String clubsupplies = request.getParameter("clubsupplies");
      System.out.println("clubsupplies : " + clubsupplies);
      DTO.setClubSupplies(clubsupplies);
      
      String file1 = request.getParameter("file1");
      System.out.println("file1 : " + file1);
      DTO.setClubPicture1(file1);
      
      String file2 = request.getParameter("file2");
      System.out.println("file2 : " + file2);
      DTO.setClubPicture2(file2);
      
      String file3 = request.getParameter("file3");
      System.out.println("file3 : " + file3);
      DTO.setClubPicture3(file3);
      
      String file4 = request.getParameter("file4");
      System.out.println("file4 : " + file4);
      DTO.setClubPicture4(file4);
      
      DongSQL.LeadClubUpdateSelect(DTO);
      
      RequestDispatcher dis = request.getRequestDispatcher("/lselect.do");
      dis.forward(request, response);
   }
}