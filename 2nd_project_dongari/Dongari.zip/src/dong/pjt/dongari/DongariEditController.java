package dong.pjt.dongari;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.DongariSQL;
import club.pjt.sql.LeaderSQL;

@WebServlet("/dedit.do")
public class DongariEditController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();
      
      LeaderSQL LeadSQL  = new LeaderSQL();
      DongariSQL DongSQL = new DongariSQL();

      String ID  = (String) session.getAttribute("CustId");
      String clubCode = request.getParameter("clubCode");
      String clubTitleCode = request.getParameter("clubTitleCode");
      String clubDate = request.getParameter("clubDate");
      String clubStart = request.getParameter("clubStart");
      
      request.setAttribute("clubCode", clubCode);
      request.setAttribute("clubTitleCode", clubTitleCode);
      request.setAttribute("clubDate", clubDate);
      request.setAttribute("clubStart", clubStart);
      
      DongariDTO DTO = DongSQL.LeadClubUpdateSelect(ID, clubCode, clubTitleCode, clubDate, clubStart);
      request.setAttribute("DTO", DTO);
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/lea_clubEdit.jsp");
      dis.forward(request, response);
   }
}