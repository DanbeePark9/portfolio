package dong.pjt.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.DB;
import club.pjt.sql.DongariDTO;
import club.pjt.sql.LeaderDTO;

public class AdminSQL {
	
	Connection CN;
	Statement ST;
	PreparedStatement PST;
	CallableStatement CST;
	ResultSet RS;
	String msg;
	
	
	public AdminSQL() {
		CN = DB.getConnection();
	}
	
	
	public ArrayList<CustomerDTO> TCustomerInfo(){
		ArrayList<CustomerDTO> list = new ArrayList<CustomerDTO>();
		try {
			msg="SELECT * FROM TCUSTOMERINFO";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				CustomerDTO CustDTO = new CustomerDTO();
				CustDTO.setCustId(RS.getString("CustID"));
				CustDTO.setCustName(RS.getString("CustName"));
				CustDTO.setCustPass(RS.getString("CustPassword"));
				CustDTO.setCustEmail(RS.getString("CustEmail"));
				CustDTO.setCustPhone(RS.getString("CustCall"));
				CustDTO.setCustGender(RS.getString("CustGender"));
				CustDTO.setCustBirth(RS.getString("CustBirth"));
				CustDTO.setCustAddress(RS.getString("CustAddress"));
				CustDTO.setCustPhoto(RS.getString("CustPicture"));
				CustDTO.setLeadNick(RS.getString("LeadName"));
				CustDTO.setLeadIntro(RS.getString("LeadIntro"));
				CustDTO.setLeadLocal(RS.getString("LeadLocal"));
				CustDTO.setLeadBankName(RS.getString("LeadBankName"));
				CustDTO.setLeadAccount(RS.getString("LeadBankNum"));
				CustDTO.setLeadCertification(RS.getString("Leadcertificate"));
				CustDTO.setLeadGrveDate(RS.getString("LeadRegidate"));
				CustDTO.setLeadStopDate(RS.getString("LeadStopDate"));
				list.add(CustDTO);
			}
		} catch (Exception e) {System.out.println("[TCustomerInfo] error : "+e);
		}
		return list;
	}
	
	public ArrayList<AdminDTO> TLeaderClubList(){
		ArrayList<AdminDTO> list = new ArrayList<AdminDTO>();
		try {
			msg="SELECT * FROM TLEADERCLUBLIST";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				AdminDTO AdminDTO = new AdminDTO();
				AdminDTO.setCustId(RS.getString("CustID"));
				AdminDTO.setClubCode(RS.getString("ClubCode"));
				AdminDTO.setCreateDate(RS.getString("CreateDate"));
				AdminDTO.setCloseDate(RS.getString("CloseDate"));
				AdminDTO.setClubGenre(RS.getString("ClubGenre"));
				AdminDTO.setClubIntro(RS.getString("ClubIntro"));
				AdminDTO.setRePicture(RS.getString("RePicture"));
				AdminDTO.setLeadLocal(RS.getString("LeadLocal"));
				list.add(AdminDTO);
			}
		} catch (Exception e) {System.out.println("[TLeaderClubList] error : "+e);
		}
		return list;
	}
	
	
	public ArrayList<AdminDTO> TClubInfo(){
		ArrayList<AdminDTO> list = new ArrayList<AdminDTO>();
		try {
			msg="SELECT * FROM TClubInfo";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				AdminDTO AdminDTO = new AdminDTO();
				AdminDTO.setCustId(RS.getString("CustID"));
				AdminDTO.setClubCode(RS.getString("ClubCode"));
				AdminDTO.setClubDate(RS.getString("ClubDate"));
				AdminDTO.setClubTitle(RS.getString("ClubTitle"));
				AdminDTO.setClubStart(RS.getString("ClubStart"));
				AdminDTO.setClubEnd(RS.getString("ClubEnd"));
				AdminDTO.setClubPicture1(RS.getString("ClubPicture1"));
				AdminDTO.setClubPicture2(RS.getString("ClubPicture2"));
				AdminDTO.setClubPicture3(RS.getString("ClubPicture3"));
				AdminDTO.setClubPicture4(RS.getString("ClubPicture4"));
				AdminDTO.setClubMax(RS.getString("ClubMax"));
				AdminDTO.setClubCurrentNum(RS.getString("ClubCurrentNum"));
				AdminDTO.setClubLocation(RS.getString("ClubLocation"));
				AdminDTO.setClubAddress(RS.getString("ClubAddress"));
				AdminDTO.setClubSupplies(RS.getString("ClubSupplies"));
				AdminDTO.setAVGStarLevel(RS.getString("AVGStarLevel"));
				AdminDTO.setClubAmount(RS.getString("ClubAmount"));
				AdminDTO.setClubSkillLevel(RS.getString("ClubSkillLevel"));
				AdminDTO.setClubTitleCode(RS.getString("ClubTitleCode"));
				list.add(AdminDTO);
			}
		} catch (Exception e) {System.out.println("[TClubInfo] error : "+e);
		}
		return list;
	}
	
	
	
	
	public ArrayList<AdminDTO> TStudentCourseInfo(){
		ArrayList<AdminDTO> list = new ArrayList<AdminDTO>();
		try {
			msg="SELECT * FROM TStudentCourseInfo";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				AdminDTO AdminDTO = new AdminDTO();
				AdminDTO.setCustId(RS.getString("CustID"));
				AdminDTO.setClubCode(RS.getString("ClubCode"));
				AdminDTO.setClubDate(RS.getString("ClubDate"));
				AdminDTO.setClubStart(RS.getString("ClubStart"));
				AdminDTO.setApplyDate(RS.getString("ApplyDate"));
				AdminDTO.setCancelDate(RS.getString("CancelDate"));
				AdminDTO.setSettlementType(RS.getString("SettlementType"));
				AdminDTO.setSettlementAmount(RS.getString("SettlementAmount"));
				AdminDTO.setSettlementDate(RS.getString("SettlementDate"));
				AdminDTO.setStarLevel1(RS.getString("StarLevel1"));
				AdminDTO.setStarLevel2(RS.getString("StarLevel2"));
				AdminDTO.setStarLevel3(RS.getString("StarLevel3"));
				AdminDTO.setReview(RS.getString("Review"));
				AdminDTO.setReviewDate(RS.getString("ReviewDate"));
				list.add(AdminDTO);
			}
		}catch (Exception e) {System.out.println("[TStudentCourseInfo] error : "+e);
		}
		return list;
	}
	
	
	public ArrayList<AdminDTO> TStudentCardPay(){
		ArrayList<AdminDTO> list = new ArrayList<AdminDTO>();
		try {
			msg="SELECT * FROM TStudentCardPay";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				AdminDTO AdminDTO = new AdminDTO();
				AdminDTO.setCustId(RS.getString("CustID"));
				AdminDTO.setClubCode(RS.getString("ClubCode"));
				AdminDTO.setClubDate(RS.getString("ClubDate"));
				AdminDTO.setClubStart(RS.getString("ClubStart"));
				AdminDTO.setPaymentDate(RS.getString("PaymentDate"));
				AdminDTO.setCardCompany(RS.getString("CardCompany"));
				AdminDTO.setCardNum(RS.getString("CardNum"));
				AdminDTO.setCardLimitDate(RS.getString("CardLimitDate"));
				AdminDTO.setCardPass(RS.getString("CardPass"));
				AdminDTO.setPaymentAMT(RS.getString("PaymentAMT"));
				list.add(AdminDTO);
			}
		}catch (Exception e) {System.out.println("[TStudentCardPay] error : "+e);
		}
		return list;
	}
	
	public ArrayList<AdminDTO> TStudentBankPay(){
		ArrayList<AdminDTO> list = new ArrayList<AdminDTO>();
		try {
			msg="SELECT * FROM TStudentBankPay";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			while (RS.next() == true) {
				AdminDTO AdminDTO = new AdminDTO();
				AdminDTO.setCustId(RS.getString("CustID"));
				AdminDTO.setClubCode(RS.getString("ClubCode"));
				AdminDTO.setClubDate(RS.getString("ClubDate"));
				AdminDTO.setClubStart(RS.getString("ClubStart"));
				AdminDTO.setCustBankName(RS.getString("CustBankName"));
				AdminDTO.setCustBankNum(RS.getString("CustBankNum"));
				AdminDTO.setPaymentAMT(RS.getString("PaymentAMT"));
				list.add(AdminDTO);
			}
		}catch (Exception e) {System.out.println("[TStudentBankPay] error : "+e);
		}
		return list;
	}
	
	
	public void CustDelete(String CustId) {
		try {
			msg="DELETE FROM TCustomerInfo WHERE CUSTID='"+CustId+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
		} catch (Exception e) {System.out.println("[CustDelete] error : "+e);
		}
	}
	
	public void LeadDelete(String CustId) {
		try {
			msg="DELETE FROM TLeaderClublist WHERE CUSTID='"+CustId+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			System.out.println("LeadDelete 삭제 완료");
			
			msg="UPDATE TCUSTOMERINFO SET Leadcertificate='N' WHERE CUSTID='"+CustId+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			System.out.println("TCUSTOMERINFO 의 Leadcertificate를 N으로 변경");
		} catch (Exception e) {System.out.println("[LeadDelete] error : "+e);
		}
	}
	
	
	public void ClubDelete(String CustId, String ClubCode, String ClubDate, String ClubStart) {
		try {
			msg="DELETE FROM TClubInfo \r\n" + 
					"WHERE CUSTID='"+CustId+"' \r\n" + 
					"AND CLUBCODE='"+ClubCode+"'\r\n" + 
					"AND ClubDate="+ClubDate+"\r\n" + 
					"AND ClubStart="+ClubStart;
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
		} catch (Exception e) {System.out.println("[ClubDelete] error : "+e);
		}
	}
	
	
	public void StudDelete(String CustId, String ClubCode, String ClubDate, String ClubStart) {
		try {
			msg="DELETE FROM TStudentCourseInfo \r\n" + 
					"WHERE CUSTID='"+CustId+"' \r\n" + 
					"AND CLUBCODE='"+ClubCode+"'\r\n" + 
					"AND ClubDate="+ClubDate+"\r\n" + 
					"AND ClubStart="+ClubStart;
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
		} catch (Exception e) {System.out.println("[ClubDelete] error : "+e);
		}
	}
	
	
}
