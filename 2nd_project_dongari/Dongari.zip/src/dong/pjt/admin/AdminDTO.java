package dong.pjt.admin;

public class AdminDTO {

	
	/*DESC TLeaderClubList*/
	private String CustId;
	private String ClubCode;
	private String CreateDate;
	private String CloseDate;
	private String ClubGenre;
	private String ClubIntro;
	private String RePicture;
	private String LeadLocal;
	
	/*desc TCUSTOMERINFO*/
	private String ClubDate;
	private String ClubTitle;
	private String ClubStart;
	private String ClubEnd;
	private String ClubPicture1;
	private String ClubPicture2;
	private String ClubPicture3;
	private String ClubPicture4;
	private String ClubMax;
	private String ClubCurrentNum;
	private String ClubLocation;
	private String ClubAddress;
	private String ClubSupplies;
	private String AVGStarLevel;
	private String ClubAmount;
	private String ClubSkillLevel;
	private String ClubTitleCode;

	/*DESC TSTUDENTCOURSEINFO;*/
	private String ApplyDate;
	private String CancelDate;
	private String SettlementType;
	private String SettlementAmount;
	private String StarLevel1;
	private String StarLevel2;
	private String StarLevel3;
	private String Review;
	private String ReviewDate;
	private String SettlementDate;
	
	
	/*DESC TStudentCardPay;*/
	private String PaymentDate;
	private String CardCompany;
	private String CardNum;
	private String CardLimitDate;
	private String CardPass;
	private String PaymentAMT;
	
	/*DESC TStudentBankPay;*/
	private String CustBankName;
	private String CustBankNum;
	
	
	public String getCustBankName() {
		return CustBankName;
	}
	public void setCustBankName(String custBankName) {
		CustBankName = custBankName;
	}
	public String getCustBankNum() {
		return CustBankNum;
	}
	public void setCustBankNum(String custBankNum) {
		CustBankNum = custBankNum;
	}
	public String getApplyDate() {
		return ApplyDate;
	}
	public String getPaymentDate() {
		return PaymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		PaymentDate = paymentDate;
	}
	public String getCardCompany() {
		return CardCompany;
	}
	public void setCardCompany(String cardCompany) {
		CardCompany = cardCompany;
	}
	public String getCardNum() {
		return CardNum;
	}
	public void setCardNum(String cardNum) {
		CardNum = cardNum;
	}
	public String getCardLimitDate() {
		return CardLimitDate;
	}
	public void setCardLimitDate(String cardLimitDate) {
		CardLimitDate = cardLimitDate;
	}
	public String getCardPass() {
		return CardPass;
	}
	public void setCardPass(String cardPass) {
		CardPass = cardPass;
	}
	public String getPaymentAMT() {
		return PaymentAMT;
	}
	public void setPaymentAMT(String paymentAMT) {
		PaymentAMT = paymentAMT;
	}
	public void setApplyDate(String applyDate) {
		ApplyDate = applyDate;
	}
	public String getCancelDate() {
		return CancelDate;
	}
	public void setCancelDate(String cancelDate) {
		CancelDate = cancelDate;
	}
	public String getSettlementType() {
		return SettlementType;
	}
	public void setSettlementType(String settlementType) {
		SettlementType = settlementType;
	}
	public String getSettlementAmount() {
		return SettlementAmount;
	}
	public void setSettlementAmount(String settlementAmount) {
		SettlementAmount = settlementAmount;
	}
	public String getStarLevel1() {
		return StarLevel1;
	}
	public void setStarLevel1(String starLevel1) {
		StarLevel1 = starLevel1;
	}
	public String getStarLevel2() {
		return StarLevel2;
	}
	public void setStarLevel2(String starLevel2) {
		StarLevel2 = starLevel2;
	}
	public String getStarLevel3() {
		return StarLevel3;
	}
	public void setStarLevel3(String starLevel3) {
		StarLevel3 = starLevel3;
	}
	public String getReview() {
		return Review;
	}
	public void setReview(String review) {
		Review = review;
	}
	public String getReviewDate() {
		return ReviewDate;
	}
	public void setReviewDate(String reviewDate) {
		ReviewDate = reviewDate;
	}
	public String getSettlementDate() {
		return SettlementDate;
	}
	public void setSettlementDate(String settlementDate) {
		SettlementDate = settlementDate;
	}
	public String getClubDate() {
		return ClubDate;
	}
	public void setClubDate(String clubDate) {
		ClubDate = clubDate;
	}
	public String getClubTitle() {
		return ClubTitle;
	}
	public void setClubTitle(String clubTitle) {
		ClubTitle = clubTitle;
	}
	public String getClubStart() {
		return ClubStart;
	}
	public void setClubStart(String clubStart) {
		ClubStart = clubStart;
	}
	public String getClubEnd() {
		return ClubEnd;
	}
	public void setClubEnd(String clubEnd) {
		ClubEnd = clubEnd;
	}
	public String getClubPicture1() {
		return ClubPicture1;
	}
	public void setClubPicture1(String clubPicture1) {
		ClubPicture1 = clubPicture1;
	}
	public String getClubPicture2() {
		return ClubPicture2;
	}
	public void setClubPicture2(String clubPicture2) {
		ClubPicture2 = clubPicture2;
	}
	public String getClubPicture3() {
		return ClubPicture3;
	}
	public void setClubPicture3(String clubPicture3) {
		ClubPicture3 = clubPicture3;
	}
	public String getClubPicture4() {
		return ClubPicture4;
	}
	public void setClubPicture4(String clubPicture4) {
		ClubPicture4 = clubPicture4;
	}
	public String getClubMax() {
		return ClubMax;
	}
	public void setClubMax(String clubMax) {
		ClubMax = clubMax;
	}
	public String getClubCurrentNum() {
		return ClubCurrentNum;
	}
	public void setClubCurrentNum(String clubCurrentNum) {
		ClubCurrentNum = clubCurrentNum;
	}
	public String getClubLocation() {
		return ClubLocation;
	}
	public void setClubLocation(String clubLocation) {
		ClubLocation = clubLocation;
	}
	public String getClubAddress() {
		return ClubAddress;
	}
	public void setClubAddress(String clubAddress) {
		ClubAddress = clubAddress;
	}
	public String getClubSupplies() {
		return ClubSupplies;
	}
	public void setClubSupplies(String clubSupplies) {
		ClubSupplies = clubSupplies;
	}
	public String getAVGStarLevel() {
		return AVGStarLevel;
	}
	public void setAVGStarLevel(String aVGStarLevel) {
		AVGStarLevel = aVGStarLevel;
	}
	public String getClubAmount() {
		return ClubAmount;
	}
	public void setClubAmount(String clubAmount) {
		ClubAmount = clubAmount;
	}
	public String getClubSkillLevel() {
		return ClubSkillLevel;
	}
	public void setClubSkillLevel(String clubSkillLevel) {
		ClubSkillLevel = clubSkillLevel;
	}
	public String getClubTitleCode() {
		return ClubTitleCode;
	}
	public void setClubTitleCode(String clubTitleCode) {
		ClubTitleCode = clubTitleCode;
	}
	public String getCustId() {
		return CustId;
	}
	public void setCustId(String custId) {
		CustId = custId;
	}
	public String getClubCode() {
		return ClubCode;
	}
	public void setClubCode(String clubCode) {
		ClubCode = clubCode;
	}
	public String getCreateDate() {
		return CreateDate;
	}
	public void setCreateDate(String createDate) {
		CreateDate = createDate;
	}
	public String getCloseDate() {
		return CloseDate;
	}
	public void setCloseDate(String closeDate) {
		CloseDate = closeDate;
	}
	public String getClubGenre() {
		return ClubGenre;
	}
	public void setClubGenre(String clubGenre) {
		ClubGenre = clubGenre;
	}
	public String getClubIntro() {
		return ClubIntro;
	}
	public void setClubIntro(String clubIntro) {
		ClubIntro = clubIntro;
	}
	public String getRePicture() {
		return RePicture;
	}
	public void setRePicture(String rePicture) {
		RePicture = rePicture;
	}
	public String getLeadLocal() {
		return LeadLocal;
	}
	public void setLeadLocal(String leadLocal) {
		LeadLocal = leadLocal;
	}
	
	
	
}
