package dong.pjt.board;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import club.pjt.sql.DB;

public class BoardSQL {
	Connection CN;
	Statement ST;
	PreparedStatement PST;
	CallableStatement CST;
	ResultSet RS;
	String msg;
	
	
	/*
	  
CREATE TABLE TBoard(
    CustId VARCHAR2(100),
    CustName VARCHAR2(50),
    Title VARCHAR2(100),
    CustContent VARCHAR2(1000),
    LikeNum VARCHAR2(100),
    WriteDate DATE
);
	  */
	public BoardSQL() {
		CN = DB.getConnection();
	}
	
	//이름출력
	public String NameSelect(String ID) {
    String CustName="";
		try {
			msg="SELECT CUSTNAME FROM TCUSTOMERINFO WHERE CUSTID='"+ID+"'";
			ST = CN.createStatement();
			RS=ST.executeQuery(msg);
			RS.next();
			CustName=RS.getString("CUSTNAME");
		} catch (Exception e) {System.out.println("[NameSelect] "+e);
		} return CustName;
	}
	
	//글저장
	public void WriteSave(String ID,String title,String content) {
		try {
			String Name = NameSelect(ID);
			msg="INSERT INTO TBoard VALUES(\r\n" + 
					"'"+ID+"','"+Name+"','"+title+"','"+content+"','0', sysdate)";
			ST = CN.createStatement();
			System.out.println(msg);
      ST.executeUpdate(msg);
		} catch (Exception e) {System.out.println("[WriteSave] "+e);
		}
	}
	
	//글출력
	public ArrayList<BoardDTO> BoardSelect() {
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
		try {
			msg="SELECT * FROM TBoard ORDER BY WRITEDATE";
			ST = CN.createStatement();
			RS=ST.executeQuery(msg);
			while(RS.next()==true) {
				BoardDTO DTO = new BoardDTO();
				DTO.setCustId(RS.getString("CustId"));
				DTO.setCustName(RS.getString("CustName"));
				DTO.setTitle(RS.getString("Title"));
				DTO.setCustContent(RS.getString("CustContent"));
				DTO.setLikeNum(RS.getString("LikeNum"));
				DTO.setWriteDate(RS.getString("WriteDate"));
				list.add(DTO);
			}
		} catch (Exception e) {System.out.println("[BoardSelect] "+e);
		} return list;
	}
	
	
	//글상세
	public BoardDTO BoardDetail(String ID,String title,String writeDate,String likeNum) {
		BoardDTO DTO = new BoardDTO();
		writeDate = writeDate.substring(0,10);
		try {
			msg="SELECT CUSTID,CustName,Title,CustContent,LikeNum,TO_CHAR(WriteDate,'YY.MM.DD') AS WriteDate  FROM TBoard \r\n" + 
					"WHERE CUSTID='"+ID+"'\r\n" + 
					"AND TITLE='"+title+"'\r\n" + 
					"AND TO_CHAR(WRITEDATE,'YYYY-MM-DD')=TO_DATE('"+writeDate+"','YYYY-MM-DD')\r\n" + 
					"AND LIKENUM='"+likeNum+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			DTO.setCustId(RS.getString("CUSTID"));
			DTO.setCustName(RS.getString("CustName"));
			DTO.setTitle(RS.getString("Title"));
			DTO.setCustContent(RS.getString("CustContent"));
			DTO.setLikeNum(RS.getString("LikeNum"));
			DTO.setWriteDate(RS.getString("WriteDate"));
		} catch (Exception e) {System.out.println("[BoardDetail] "+e);
		}
		return DTO;
	}
}
