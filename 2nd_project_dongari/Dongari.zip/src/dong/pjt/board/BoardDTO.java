package dong.pjt.board;

public class BoardDTO {
	private String CustId;
	private String CustName;
	private String Title;
  //sqldeveloper에서 Content가 예약어라서 어쩔수 없이 앞에 Cust 붙임
	private String CustContent; 
  //sqldeveloper에서 Like가 예약어라서 어쩔수 없이 뒤에 Num 붙임
	private String LikeNum;
	private String WriteDate;
	public String getCustId() {
		return CustId;
	}
	public void setCustId(String custId) {
		CustId = custId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getCustContent() {
		return CustContent;
	}
	public void setCustContent(String custContent) {
		CustContent = custContent;
	}
	public String getLikeNum() {
		return LikeNum;
	}
	public void setLikeNum(String likeNum) {
		LikeNum = likeNum;
	}
	public String getWriteDate() {
		return WriteDate;
	}
	public void setWriteDate(String writeDate) {
		WriteDate = writeDate;
	}
	
	
}
