package dong.pjt.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/bselect.do")
public class BoardSelectController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}
	
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 	   response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     HttpSession session = request.getSession();
     
     String ID    = (String) session.getAttribute("CustId");
     session.setAttribute("CustId", ID);
     
     BoardSQL BoarSQL = new BoardSQL();
     ArrayList<BoardDTO> Board = BoarSQL.BoardSelect();
     session.setAttribute("Board", Board);
     
     RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_board.jsp");
     dis.forward(request, response);
  }
}
