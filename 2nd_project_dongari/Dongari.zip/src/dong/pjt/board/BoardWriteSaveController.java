package dong.pjt.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;

@WebServlet("/bwriteSave.do")
public class BoardWriteSaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}
	
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 	   response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
     HttpSession session = request.getSession();
     
     String ID    = (String) session.getAttribute("CustId");
     String title = request.getParameter("title");
     String content = request.getParameter("content");
     
     BoardSQL BoarSQL = new BoardSQL();
     BoarSQL.WriteSave(ID,title,content);
     
     RequestDispatcher dis = request.getRequestDispatcher("/bselect.do");
     dis.forward(request, response);
  }
}
