package dong.pjt.customer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.CustomerSQL;
import club.pjt.sql.StudentSQL;

@WebServlet("/cedit.do")
public class customerEditController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      //response.getWriter().append("Served at: ").append(request.getContextPath());
      doUsser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUsser(request, response);
   }
   protected void doUsser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html; charset=UTF-8");
      request.setCharacterEncoding("UTF-8");
      HttpSession session = request.getSession();
      
      String CustId = (String) session.getAttribute("CustId");
      
      CustomerSQL CustSQL = new CustomerSQL();
      CustomerDTO CustDTO = CustSQL.CustProfile(CustId);
      
      request.setAttribute("CustDTO", CustDTO);
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_profileEdit.jsp");
 			dis.forward(request, response);
   }
}