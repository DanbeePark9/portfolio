package dong.pjt.customer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.CustomerSQL;

@WebServlet("/cinsert.do")
public class customerInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		String CustId     = request.getParameter("id");
		String CustName   = request.getParameter("name");
		String CustPass   = request.getParameter("password");
		String CustEmail  = request.getParameter("email");
		String CustPhone1 = request.getParameter("phone1");
		String CustPhone2 = request.getParameter("phone2");
		String CustPhone3 = request.getParameter("phone3");
		String CustGender = request.getParameter("genderResult");
		String CustBirth  = request.getParameter("birth");
		String CustAddress  = request.getParameter("local");
		String CustPhoto  = request.getParameter("file");
		String CustPhone  = CustPhone1 + CustPhone2 + CustPhone3;
		
		CustomerSQL CustSQL = new CustomerSQL();
		CustomerDTO CustDTO = new CustomerDTO();
		
		CustDTO.setCustId(CustId);
		CustDTO.setCustName(CustName);
		CustDTO.setCustPass(CustPass);
		CustDTO.setCustEmail(CustEmail);
		CustDTO.setCustPhone(CustPhone);
		CustDTO.setCustGender(CustGender);
		CustDTO.setCustBirth(CustBirth);
		CustDTO.setCustAddress(CustAddress);
		CustDTO.setCustPhoto(CustPhoto);
		
		CustSQL.CustInsert(CustDTO);
		
		System.out.println("회원가입 후 로그인 된 아이디 : "+CustId);
		
		request.setAttribute("CustDTO", CustDTO);
		session.setAttribute("CustId", CustId);
		
		RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_index.jsp");
		dis.forward(request, response);
	}
}
