package dong.pjt.customer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CustomerDTO;
import club.pjt.sql.CustomerSQL;

@WebServlet("/ceditSave.do")
public class customerEditSaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUsser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUsser(request, response);
   }
   protected void doUsser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html; charset=UTF-8");
      request.setCharacterEncoding("UTF-8");
      HttpSession session = request.getSession();
      
      String CustId = (String) session.getAttribute("CustId");
      
      String photo 	= request.getParameter("photo");
      String name 	= request.getParameter("name");
      String email 	= request.getParameter("email");
      String phone 	= request.getParameter("phone");
      String birth 	= request.getParameter("birth");
      			 birth = birth.substring(0,10);
      String address = request.getParameter("address");
      
      
      CustomerSQL CustSQL = new CustomerSQL();
      CustSQL.CustEdit(CustId,photo,name,email,phone,birth,address);
      
      CustomerDTO CustDTO = CustSQL.CustProfile(CustId);
      request.setAttribute("CustDTO", CustDTO);
      
      String msg="회원 정보 수정이 완료되었습니다.";
      String url="/cprofile.do";
      PrintWriter writer = response.getWriter(); 
      writer.println("<script>alert('"+msg+"'); location.href='"+url+"';</script>");
      writer.close();
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_profile.jsp");
 			dis.forward(request, response);
   }
}