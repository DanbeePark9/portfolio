package dong.pjt.customer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.LeaderDTO;
import club.pjt.sql.LeaderSQL;

@WebServlet("/leadercheck.do")
public class customerCheckController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      //response.getWriter().append("Served at: ").append(request.getContextPath());
      doUsser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUsser(request, response);
   }
   protected void doUsser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         response.setContentType("text/html; charset=UTF-8");
         request.setCharacterEncoding("UTF-8");
         
         HttpSession session = request.getSession();
         LeaderSQL SQL = new LeaderSQL();
         
         String Ccheck  = (String) session.getAttribute("CustId");
         String C = request.getParameter("C");
         String msg = "";
         String url = "";
         String Lcheck = SQL.LeadCheck(Ccheck);
         
         if( C.equals("1") ) {
            if( Ccheck=="" || Ccheck==null) {
               // 로그인을 안했을 경우에는 로그인을 하라고 한다.
               msg = "로그인을 먼저 하세요";
               url = "/jsp/cus_login.jsp";
            } else if(Lcheck=="" || Lcheck==null){
               // 리더가 아니면 리더 등록을 하라고 한다.
               msg = "리더 등록을 하러 갑니다";
               url = "/jsp/lea_leader_step1.jsp";
            } else {
               // 리더가 아니면 리더 등록 못한다.
               msg = "이미 리더로 등록되어있습니다";
               url = "/jsp/index.jsp";
            }
            
         }else if(C.equals("2")) {
            if( Ccheck=="" || Ccheck==null) {
             // 로그인을 안했을 경우에는 로그인을 하라고 한다.
               msg = "로그인을 먼저 하세요.";
               url = "/jsp/cus_login.jsp";
            } else if( Lcheck=="" || Lcheck==null ){
               // 리더가 아니면 리더 등록을 하라고 한다.
               msg = "리더 등록을 먼저 하세요.";
               url = "/jsp/lea_leader_step1.jsp";
            } else {
               // 회원이고 리더라면 동아리 등록을 하러 간다.
               msg = "동아리 등록을 하러 갑니다.";
               url = "/jsp/lea_leader_step3.jsp";
            }
            
         }else {
            msg = "?";
            url = "/jsp/cus_login.jsp";
         }
         
         PrintWriter writer = response.getWriter(); 
         writer.println("<script>alert('"+msg+"'); location.href='"+url+"';</script>");
         writer.close();
   }
}