package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CalendarDTO;
import club.pjt.sql.StudentDTO;
import club.pjt.sql.StudentSQL;

@WebServlet("/sschedule.do")
public class StudentScheduleController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}
	
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
    HttpSession session = request.getSession();
    
    String ID    = (String) session.getAttribute("CustId");
    String idx1 = request.getParameter("idx1"); //10월 02일 09시 20분
   
    StudentSQL StudSQL = new StudentSQL();
    //String ClubDate = StudSQL.StudentClubDate(ID, idx1);
    
    ArrayList<StudentDTO> StudDTO = StudSQL.ScheduleSelect(ID); //지금은 고정값이지만 나중에 매개인자로 ID받기
    
    request.setAttribute("StudDTO"  , StudDTO);
    
    
    RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_schedule.jsp");
    dis.forward(request, response);
	}
}
