package dong.pjt.student;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.ReviewSQL;

@WebServlet("/sreviewInsert.do")
public class StudentReviewInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
	  HttpSession session = request.getSession();
	  
	  String ID = (String) session.getAttribute("CustId"); //학생 아이디
	  String StarLevel1 = request.getParameter("hiddenValue1");
	  String StarLevel2 = request.getParameter("hiddenValue2");
	  String StarLevel3 = request.getParameter("hiddenValue3");
	  String review = request.getParameter("review");
	  String ClubCode = request.getParameter("ClubCode");
	  
	  ReviewSQL RSQL = new ReviewSQL();
	  /*후기 INSERT*/
	  RSQL.ReviewInsert(ID,StarLevel1,StarLevel2,StarLevel3,review,ClubCode);
	  
	  /*후기 평점 INSERT*/
	  int Star1 = Integer.parseInt(request.getParameter("hiddenValue1"));
	  int Star2 = Integer.parseInt(request.getParameter("hiddenValue2"));
	  int Star3 = Integer.parseInt(request.getParameter("hiddenValue3"));
	  int AVGStarLevel = (Star1+Star2+Star3)/3; //후기에서 입력 받은 평점을 계산해서 매개인자로 넣어주기
	  RSQL.ReviewAVGInsert(ClubCode, AVGStarLevel);
	  
	  RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_profile.jsp");
    dis.forward(request, response);
	}
}
