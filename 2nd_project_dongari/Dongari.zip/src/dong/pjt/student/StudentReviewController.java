package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.ReviewSQL;

@WebServlet("/sreview.do")
public class StudentReviewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
	  PrintWriter out = response.getWriter();
	  HttpSession session = request.getSession();
	  
	  String ID = (String) session.getAttribute("CustId");
	  String ClubTitle = request.getParameter("ClubTitle");
	  String LeadName = request.getParameter("LeadName");
	  String ClubCode = request.getParameter("ClubCode");
	  
	  session.setAttribute("LeadName", LeadName);
	  session.setAttribute("ClubTitle", ClubTitle);
	  session.setAttribute("ClubCode", ClubCode);
	  
	  
	  RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_review.jsp");
    dis.forward(request, response);
	}
}
