package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.CalendarDTO;
import club.pjt.sql.ReviewDTO;
import club.pjt.sql.ReviewSQL;
import club.pjt.sql.StudentDTO;
import club.pjt.sql.StudentSQL;

@WebServlet("/sselect.do")
public class StudentSelectController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }
   
   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
    PrintWriter out = response.getWriter();
    HttpSession session = request.getSession();
    
    /*학생 페이지*/
    String ID = (String) session.getAttribute("CustId");
    StudentSQL StudSQL = new StudentSQL();
    //일정
    CalendarDTO CalDTO = new CalendarDTO();
    CalDTO.setCustId(ID);
    String month   = request.getParameter("month");
    if( month == null || month == "" ) {
        Date date = new Date();
        int iMonth = date.getMonth()+1;
        month = Integer.toString(iMonth);
        CalDTO.setMonth(month);
    }else {
       CalDTO.setMonth(month);
    }
    ArrayList<CalendarDTO> Callist = StudSQL.StudCalendarSelect (CalDTO);
    CalendarDTO day01 = Callist.get(0); request.setAttribute("day01", day01);
    CalendarDTO day02 = Callist.get(1); request.setAttribute("day02", day02);
    CalendarDTO day03 = Callist.get(2); request.setAttribute("day03", day03);
    CalendarDTO day04 = Callist.get(3); request.setAttribute("day04", day04);
    CalendarDTO day05 = Callist.get(4); request.setAttribute("day05", day05);
    CalendarDTO day06 = Callist.get(5); request.setAttribute("day06", day06);
    CalendarDTO day07 = Callist.get(6); request.setAttribute("day07", day07);
    CalendarDTO day08 = Callist.get(7); request.setAttribute("day08", day08);
    CalendarDTO day09 = Callist.get(8); request.setAttribute("day09", day09);
    CalendarDTO day10 = Callist.get(9); request.setAttribute("day10", day10);
    CalendarDTO day11 = Callist.get(10); request.setAttribute("day11", day11);
    CalendarDTO day12 = Callist.get(11); request.setAttribute("day12", day12);
    CalendarDTO day13 = Callist.get(12); request.setAttribute("day13", day13);
    CalendarDTO day14 = Callist.get(13); request.setAttribute("day14", day14);
    CalendarDTO day15 = Callist.get(14); request.setAttribute("day15", day15);
    CalendarDTO day16 = Callist.get(15); request.setAttribute("day16", day16);
    CalendarDTO day17 = Callist.get(16); request.setAttribute("day17", day17);
    CalendarDTO day18 = Callist.get(17); request.setAttribute("day18", day18);
    CalendarDTO day19 = Callist.get(18); request.setAttribute("day19", day19);
    CalendarDTO day20 = Callist.get(19); request.setAttribute("day20", day20);
    CalendarDTO day21 = Callist.get(20); request.setAttribute("day21", day21);
    CalendarDTO day22 = Callist.get(21); request.setAttribute("day22", day22);
    CalendarDTO day23 = Callist.get(22); request.setAttribute("day23", day23);
    CalendarDTO day24 = Callist.get(23); request.setAttribute("day24", day24);
    CalendarDTO day25 = Callist.get(24); request.setAttribute("day25", day25);
    CalendarDTO day26 = Callist.get(25); request.setAttribute("day26", day26);
    CalendarDTO day27 = Callist.get(26); request.setAttribute("day27", day27);
    CalendarDTO day28 = Callist.get(27); request.setAttribute("day28", day28);
    CalendarDTO day29 = Callist.get(28); request.setAttribute("day29", day29);
    CalendarDTO day30 = Callist.get(29); request.setAttribute("day30", day30);
    CalendarDTO day31 = Callist.get(30); request.setAttribute("day31", day31);
    
    ReviewSQL RSQL = new ReviewSQL();
    /*안쓴 후기가 몇개인지 카운트 출력*/
    int cnt = RSQL.NotWrittendReviewCount(ID);
    session.setAttribute("cnt", cnt);
    /*리뷰 작성 여부*/
    if(RSQL.ReviewCheck(ID)==1) {
       session.setAttribute("CheckResult", 1); //작성하지 않은 후기가 있음
    } else {
       session.setAttribute("CheckResult", 0); //작성하지 않은 후기가 없음
    }
    
    /*리뷰 리스트 뽑기*/
    List<ReviewDTO> ReviewList = RSQL.StudentReview(ID);
    if( ReviewList == null ) {
         PrintWriter writer = response.getWriter(); 
         writer.println("<script>alert('수강한 수업이 없습니다.'); location.href='/jsp/index.jsp';</script>");
         writer.close();
    }else {
        request.setAttribute("ReviewList", ReviewList);
    }
    
    
    RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_profile.jsp");
    dis.forward(request, response);
   }
}