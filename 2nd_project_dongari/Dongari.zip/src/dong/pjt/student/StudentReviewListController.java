package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.ReviewSQL;

@WebServlet("/sreviewList.do")
public class StudentReviewListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
    request.setCharacterEncoding("UTF-8");
	  HttpSession session = request.getSession();
	  String ID = (String) session.getAttribute("CustId");
	  
	  ReviewSQL RSQL = new ReviewSQL();
	  
	  /*작성하지 않은 후기의 동아리타이틀, 리더이름, 참여한 날짜 출력*/
	  ArrayList<DongariDTO> ReviewDTO = RSQL.NotWrittendReviewData(ID);
	  session.setAttribute("ReviewDTO", ReviewDTO);
	  
	  RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_reviewList.jsp");
    dis.forward(request, response);
	}
}
