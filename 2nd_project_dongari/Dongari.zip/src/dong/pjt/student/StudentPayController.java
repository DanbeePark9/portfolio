package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.PaymentDTO;
import club.pjt.sql.PaymentSQL;

@WebServlet("/spay.do")
public class StudentPayController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }
   
   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();
    
      String ID  = (String) session.getAttribute("CustId");
      if( ID == null || ID == "" ) {
      	String msg="로그인을 하셔야 이용하실수 있습니다.";
        String url="/jsp/cus_login.jsp";
        PrintWriter writer = response.getWriter(); 
        writer.println("<script>alert('"+msg+"'); location.href='"+url+"';</script>");
        writer.close();
      }
      String LeaderId = request.getParameter("LeaderId"    );
      String clubCode = request.getParameter("clubCode"    );
      String clubDate = request.getParameter("clubDate"    );
      String clubStart = request.getParameter("clubStart"  );
      String clubAmount = request.getParameter("clubAmount");

      PaymentDTO LeadDTO = new PaymentDTO( LeaderId, clubCode, clubDate, clubStart);
      PaymentSQL payDTO  = new PaymentSQL();
      PaymentDTO clubInfo = payDTO.PaymentInfo(LeadDTO);
      request.setAttribute("clubInfo", clubInfo );

      // 결제할 때 사용. 보여주기로 형식 변화가 일어나기 때문에 일일이 request
      request.setAttribute("clubCode", clubCode    );
      request.setAttribute("clubDate", clubDate    );
      request.setAttribute("clubStart", clubStart  );
      request.setAttribute("clubAmount", clubAmount);
      
      
      RequestDispatcher dis = request.getRequestDispatcher("/jsp/cus_register.jsp");
      dis.forward(request, response);
   }
}