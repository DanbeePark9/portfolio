package dong.pjt.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import club.pjt.sql.DongariDTO;
import club.pjt.sql.PaymentDTO;
import club.pjt.sql.PaymentSQL;

@WebServlet("/spaysave.do")
public class StudentPaySaveController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doUser(request, response);
   }
   
   protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  	 response.setContentType("text/html; charset=UTF-8");
     request.setCharacterEncoding("UTF-8");
      PrintWriter out = response.getWriter();
      HttpSession session = request.getSession();
      PaymentDTO DTO = new PaymentDTO();
      PaymentSQL SQL = new PaymentSQL();
      String ID  = (String) session.getAttribute("CustId");
      boolean C ;
      // 기본 정보
      DTO.setCustId(ID);
      DTO.setClubCode(request.getParameter("clubCode"));
      DTO.setClubDate(request.getParameter("clubDate"));
      DTO.setClubStart(request.getParameter("clubStart"));
      DTO.setClubAmount(request.getParameter("clubAmount"));
      DTO.setPhoneNumber(request.getParameter("phoneNumber"));
      
      String check  = request.getParameter("cardCvc");
      
      // 계좌 결제
      if( check.equals(null)||check.equals("")) {
         DTO.setBankCustName(request.getParameter("bankCustName"));
         DTO.setBankName(request.getParameter("bankName"));
         DTO.setBankNumber(request.getParameter("bankNumber"));
         DTO.BanktoString(DTO);
         C = SQL.ClubBankPayment(DTO);

      // 카드 결제 
      }else {
         DTO.setCardName(request.getParameter("cardName"));
         DTO.setCardNum1(request.getParameter("cardNum1"));
         DTO.setCardNum2(request.getParameter("cardNum2"));
         DTO.setCardNum3(request.getParameter("cardNum3"));
         DTO.setCardNum4(request.getParameter("cardNum4"));
         DTO.setExpiryDate(request.getParameter("expiryDate1") + "/" + request.getParameter("expiryDate2"));
         DTO.setCardPassword(request.getParameter("cardPassword"));
         DTO.setCardCvc(request.getParameter("cardCvc"));
         DTO.CardtoString(DTO);
         C = SQL.ClubCardPayment(DTO);
     }
    
      // 저장 성공
     if( C==true ) {
         RequestDispatcher dis = request.getRequestDispatcher("/jsp/stu_profile.jsp");
         dis.forward(request, response);
     // 저장 실패
     }else {
         RequestDispatcher dis = request.getRequestDispatcher("/jsp/index.jsp");
         dis.forward(request, response);
     }

   }
}