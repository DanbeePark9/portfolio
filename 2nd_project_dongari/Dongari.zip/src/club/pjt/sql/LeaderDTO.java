package club.pjt.sql;

public class LeaderDTO {
   
   // 고객ID
   private String CustId;
   // 리더 별칭
   private String LeadName;
   // 리더 소개
   private String LeadIntro;
   // 리더 지역
   private String LeadLocal;
   // 계좌번호
   private String LeadBankName;
   // 은행명
   private String LeadBankNum; 
   // 리더자격유무
   private String LeadCertificate; 
   // 자격부여일자
   private String LeadregiDate;
   // 자격정지일자
   private String LeadStopDate;
   
   private String CustPicture;
   
   // 경력
   private String expertise1;
   private String expertise2;
   private String expertise3;
   private String expertise4;
   private String expertise5;
   private String expertiseCNT;
   
   // 자격증
   private String license1;
   private String license2;
   private String license3;
   private String license4;
   private String license5;
   
   
   
   
   public String getExpertiseCNT() {
		return expertiseCNT;
	}
	public void setExpertiseCNT(String expertiseCNT) {
		this.expertiseCNT = expertiseCNT;
	}
	public String getCustId() {
      return CustId;
   }
   public void setCustId(String custId) {
      CustId = custId;
   }
   public String getLeadName() {
      return LeadName;
   }
   public void setLeadName(String leadName) {
      LeadName = leadName;
   }
   public String getLeadIntro() {
      return LeadIntro;
   }
   public void setLeadIntro(String leadIntro) {
      System.out.println(leadIntro);
      LeadIntro = leadIntro;
   }
   public String getLeadLocal() {
      return LeadLocal;
   }
   public void setLeadLocal(String leadLocal) {
      LeadLocal = leadLocal;
   }
   public String getLeadBankName() {
      return LeadBankName;
   }
   public void setLeadBankName(String leadBankName) {
      LeadBankName = leadBankName;
   }
   public String getLeadBankNum() {
      return LeadBankNum;
   }
   public void setLeadBankNum(String leadBankNum) {
      LeadBankNum = leadBankNum;
   }
   public String getLeadCertificate() {
      return LeadCertificate;
   }
   public void setLeadCertificate(String leadCertificate) {
      LeadCertificate = leadCertificate;
   }
   public String getLeadregiDate() {
      return LeadregiDate;
   }
   public void setLeadregiDate(String leadregiDate) {
      LeadregiDate = leadregiDate;
   }
   public String getLeadStopDate() {
      return LeadStopDate;
   }
   public void setLeadStopDate(String leadStopDate) {
      LeadStopDate = leadStopDate;
   }
   public String getCustPicture() {
      return CustPicture;
   }
   public void setCustPicture(String CustPicture) {
      this.CustPicture = CustPicture;
   }
   public String getExpertise1() {
      return expertise1;
   }
   public void setExpertise1(String expertise1) {
      this.expertise1 = expertise1;
   }
   public String getExpertise2() {
      return expertise2;
   }
   public void setExpertise2(String expertise2) {
      this.expertise2 = expertise2;
   }
   public String getExpertise3() {
      return expertise3;
   }
   public void setExpertise3(String expertise3) {
      this.expertise3 = expertise3;
   }
   public String getExpertise4() {
      return expertise4;
   }
   public void setExpertise4(String expertise4) {
      this.expertise4 = expertise4;
   }
   public String getExpertise5() {
      return expertise5;
   }
   public void setExpertise5(String expertise5) {
      this.expertise5 = expertise5;
   }
   public String getLicense1() {
      return license1;
   }
   public void setLicense1(String license1) {
      this.license1 = license1;
   }
   public String getLicense2() {
      return license2;
   }
   public void setLicense2(String license2) {
      this.license2 = license2;
   }
   public String getLicense3() {
      return license3;
   }
   public void setLicense3(String license3) {
      this.license3 = license3;
   }
   public String getLicense4() {
      return license4;
   }
   public void setLicense4(String license4) {
      this.license4 = license4;
   }
   public String getLicense5() {
      return license5;
   }
   public void setLicense5(String license5) {
      this.license5 = license5;
   }
   
   
   
}