package club.pjt.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import club.pjt.check.PageCalculate;
import club.pjt.check.pageNum;
import club.pjt.sql.DB;

public class LeaderSQL {

	Connection CN;
	Statement ST;
	PreparedStatement PST;
	CallableStatement CST;
	ResultSet RS;
	String msg;

	String CustId;
	String LeadName;
	String LeadIntro;
	String LeadLocal;
	String LeadBankName;
	String LeadBankNum;
	String LeadCertificate;
	String LeadRegiDate;
	String LeadStopDate;
	String LeadCheck;

	public LeaderSQL() {
		CN = DB.getConnection();
	}

  public ArrayList<DongariDTO> LeadDongariSelect(String ID) {
    ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
    try {
       msg = "SELECT CLUBTITLE, CLUBDATE, CLUBCODE FROM TCLUBINFO WHERE CUSTID='"+ID+"' ORDER BY CLUBTITLE";
       ST = CN.createStatement();
       RS = ST.executeQuery(msg);
       int i=0;
       while (RS.next() == true) {
         if( i++ == 0 ) {
            if(RS.getString("ClubTitle")==""||RS.getString("ClubTitle")==null) {
               return null;
            }
         }
          DongariDTO DongDTO = new DongariDTO();
          DongDTO.setClubTitle(RS.getString("ClubTitle"));
          DongDTO.setClubDate(RS.getString("ClubDate"));
          DongDTO.setClubCode(RS.getString("ClubCode"));
          list.add(DongDTO);
       }
    } catch (SQLException e) {System.out.println("[LeadDongariSelect] ERROR : " + e);}
    return list;
 }

	public DongariDTO LeadDongariInfo(String ID, String title, String idx1) {
		DongariDTO DTO = new DongariDTO();

		String date = idx1.substring(0, 2) + "/" + idx1.substring(2, 4);
		String time = idx1.substring(4, 6) + ":" + idx1.substring(6, 8);

		try {
			msg = " SELECT TCI.CLUBDATE, TO_CHAR( TCI.CLUBSTART, 'HH24:MI') AS CLUBSTART , TO_CHAR( TCI.CLUBEND, 'HH24:MI') AS CLUBEND, TCI.CLUBADDR, TCI.CLUBSUPPLIES, TLCL.REPICTURE, TO_CHAR( TCI.CLUBDATE, 'YY MM DD') AS CLUBDATE \r\n"
					+ "  FROM TCLUBINFO TCI, TLeaderClubList TLCL\r\n" + " WHERE TCI.CUSTID = TLCL.CUSTID\r\n"
					+ "   AND TCI.CUSTID='sky12'\r\n" + "   AND TCI.CLUBTITLE='" + title + "'\r\n"
					+ "   AND TO_CHAR( TCI.CLUBDATE,'MM/DD' )='" + date + "'\r\n" + "   AND TO_CHAR( TCI.CLUBSTART,'HH24:MI' )='"
					+ time + "'";

			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();

			DTO.setClubDate(RS.getString("CLUBDATE"));
			DTO.setClubStart(RS.getString("CLUBSTART"));
			DTO.setClubStart(RS.getString("CLUBSTART"));
			DTO.setClubEnd(RS.getString("CLUBEND"));
			DTO.setClubAddress(RS.getString("CLUBADDR"));
			DTO.setClubSupplies(RS.getString("CLUBSUPPLIES"));
			DTO.setRePicture(RS.getString("REPICTURE"));
		} catch (SQLException e) {
			System.out.println("LeadDongariInfo ERROR : " + e);
		}
		return DTO;
	}

	public ArrayList<ReviewDTO> LeadReview(String ID) {

		ArrayList<ReviewDTO> list = new ArrayList<ReviewDTO>();
		int sum = 0;
		int avg = 0;
		int i = 0;
		try {
			msg = "SELECT TSCI.CUSTID , CI.CUSTNAME, TSCI.REVIEW, TSCI.REVIEWDATE, TSCI.STARLEVEL1, TSCI.STARLEVEL2,  TSCI.STARLEVEL3\r\n"
					+ " FROM TCLUBINFO TCI, TSTUDENTCOURSEINFO TSCI, CUSTOMERINFO CI\r\n"
					+ " WHERE TCI.CLUBCODE      = TSCI.CLUBCODE\r\n" + "       AND CI.CUSTID     = TSCI.CUSTID \r\n"
					+ "       AND TCI.CLUBDATE  = TSCI.CLUBDATE\r\n" + "       AND TCI.CLUBSTART = TSCI.CLUBSTART\r\n"
					+ "       AND TCI.CUSTID='" + ID + "'\r\n" + "       AND TO_CHAR( TCI.CLUBDATE,'MM/DD' )='10/12'\r\n"
					+ "       AND TO_CHAR( TCI.CLUBSTART,'HH24:MI' )='09:20'";
			ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			RS = ST.executeQuery(msg);
			RS.last();
			int rowCount = RS.getRow();
			RS.beforeFirst();

			while (RS.next() == true) {
				ReviewDTO dto = new ReviewDTO();

				dto.setCustId(RS.getString("CUSTID"));
				dto.setCustName(RS.getString("CUSTNAME"));
				dto.setReview(RS.getString("REVIEW"));
				dto.setReviewDate1(RS.getString("REVIEWDATE"));
				String sStar1 = RS.getString("STARLEVEL1");
				String sStar2 = RS.getString("STARLEVEL1");
				String sStar3 = RS.getString("STARLEVEL1");
				dto.setStarLevel1(sStar1);
				dto.setStarLevel2(sStar2);
				dto.setStarLevel3(sStar3);
				dto.setStarLevel(sStar1, sStar2, sStar3);
				sum += (Integer.parseInt(sStar1) + Integer.parseInt(sStar2) + Integer.parseInt(sStar3)) / 3;
				i++;
				if (rowCount == i) {
					dto.setTotalStarLevel(sum / i);
				}
				list.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("LeadReview ERROR : " + e);
		}
		avg = sum / i;
		return list;
	}

	public String LeadStudentTitle(String ID, String idx1) {

		String date = idx1.substring(0, 2) + "/" + idx1.substring(2, 4);
		String time = idx1.substring(4, 6) + ":" + idx1.substring(6, 8);
		String title = "";
		try {
			msg = "SELECT CLUBTITLE FROM TCLUBINFO \r\n" + "WHERE TO_CHAR( CLUBDATE, 'MM/DD'  )='" + date + "'"
					+ "  AND TO_CHAR( CLUBSTART,'HH24:MI')='" + time + "'" + "  AND CUSTID='" + ID + "'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			title = RS.getString("CLUBTITLE");

		} catch (SQLException e) {
			System.out.println("LeadStudentInfo ERROR : " + e);
		}
		return title;
	}

	public ArrayList<CustomerFront> LeadStudentInfo(String ID, String idx1) {
		ArrayList<CustomerFront> list = new ArrayList<CustomerFront>();

		String date = idx1.substring(0, 2) + "/" + idx1.substring(2, 4);
		String time = idx1.substring(4, 6) + ":" + idx1.substring(6, 8);

		try {
			msg = "SELECT CI.CUSTID , CI.CUSTNAME, CI.CUSTEMAIL, CI.CUSTCALL, CI.CUSTGENDER, TO_CHAR(CI.CUSTBIRTH, 'YY MM DD') AS CUSTBIRTH \r\n"
					+ "  FROM TCLUBINFO TCI, TSTUDENTCOURSEINFO TSCI, CUSTOMERINFO CI\r\n"
					+ " WHERE TCI.CLUBCODE      = TSCI.CLUBCODE\r\n" + "       AND CI.CUSTID     = TSCI.CUSTID \r\n"
					+ "       AND TCI.CLUBDATE  = TSCI.CLUBDATE\r\n" + "       AND TCI.CLUBSTART = TSCI.CLUBSTART\r\n"
					+ "       AND TCI.CUSTID='" + ID + "'\r\n" + "       AND TO_CHAR( TCI.CLUBDATE,'MM/DD' )='" + date + "'\r\n"
					+ "       AND TO_CHAR( TCI.CLUBSTART,'HH24:MI' )='" + time + "'";

			ST = CN.createStatement();
			RS = ST.executeQuery(msg);

			while (RS.next() == true) {
				CustomerFront DTO = new CustomerFront();
				DTO.setCustId(RS.getString("CUSTID"));
				DTO.setCustName(RS.getString("CUSTNAME"));
				DTO.setCustEmail(RS.getString("CUSTEMAIL"));
				DTO.setCustPhone(RS.getString("CUSTCALL"));
				DTO.setCustGender(RS.getString("CUSTGENDER"));
				DTO.setCustBirth(RS.getString("CUSTBIRTH"));
				list.add(DTO);
			}
		} catch (SQLException e) {
			System.out.println("LeadStudentInfo ERROR : " + e);
		}
		return list;
	}

	public ArrayList<CalendarDTO> LeadCalendarSelect(CalendarDTO LEADER) {
		ArrayList<CalendarDTO> list = new ArrayList<CalendarDTO>();
		try {
			msg = "SELECT TO_CHAR(ClubDate,'DD')    AS ClubDate, CLUBTITLE, \r\n"
					+ "       TO_CHAR(ClubStart,'HH24')AS startM,   TO_CHAR(ClubStart,'MI')  AS startH, \r\n"
					+ "       TO_CHAR(ClubEnd,'HH24')  AS endM,     TO_CHAR(ClubEnd,'MI')    AS endH\r\n"
					+ "  FROM  TClubInfo WHERE CustId='" + LEADER.getCustId() + "' AND TO_CHAR(ClubDate,'MM') =11";
			// 추가 시키기 나중에 지금은 10월 데이터 뽑기위해 고정값"+LEADER.getMonth()+"
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);

			while (RS.next() == true) {
				CalendarDTO dto = new CalendarDTO();
				dto.setTitle(RS.getString("CLUBTITLE"));
				dto.setYear("20");
				dto.setDay(RS.getString("ClubDate"));
				dto.setStartM(RS.getString("startM"));
				dto.setstartH(RS.getString("startH"));
				dto.setEndM(RS.getString("endM"));
				dto.setEndH(RS.getString("endH"));
				dto.setidx1("10" + RS.getString("ClubDate") + RS.getString("startM") + RS.getString("startH"));
				list.add(dto);
			}

			for (int i = list.size(); i <= 31; i++) {
				CalendarDTO dto = new CalendarDTO();
				dto.setTitle("X");
				dto.setYear("");
				dto.setDay("");
				dto.setStartM("");
				dto.setstartH("");
				dto.setEndM("");
				dto.setEndH("");
				list.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("LeadCalendarSelect ERROR : " + e);
		}
		return list;
	}

	public String LeadCheck(String CustId) {
		try {
			msg = "SELECT LEADCERTIFICATE FROM TCUSTOMERINFO WHERE CUSTID='" + CustId + "'";

			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			LeadCheck = RS.getString("LEADCERTIFICATE");
		} catch (Exception e) {
			System.out.println("LeadCheck :" + e);
		}

		return LeadCheck;
	}

	public void LeadInsert(CustomerDTO LEADER) {
		try {
			msg = " UPDATE TCUSTOMERINFO SET " + " LeadName=?, LeadIntro=?, LeadLocal=?, LeadBankName=?, "
					+ " LeadBankNum=?, LeadCertificate='Y', LeadRegiDate=SYSDATE " + " WHERE CustId=?";
			PST = CN.prepareStatement(msg);
			PST.setString(1, LEADER.getLeadNick());
			PST.setString(2, LEADER.getLeadIntro());
			PST.setString(3, LEADER.getLeadLocal());
			PST.setString(4, LEADER.getLeadBankName());
			PST.setString(5, LEADER.getLeadAccount());
			PST.setString(6, LEADER.getCustId());
			PST.executeUpdate();
		} catch (Exception e) {
			System.out.println("LeadInsert :" + e);
		}
	}

	public LeaderDTO LeadSelect(String ID) {
		LeaderDTO DTO = new LeaderDTO();
		try {
			msg = "SELECT LEADNAME, CUSTPICTURE, LEADINTRO FROM TCUSTOMERINFO WHERE CustId='" + ID + "'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			if (RS.next() == true) {
				DTO.setLeadName(RS.getString("LEADNAME"));
				DTO.setLeadIntro(RS.getString("LEADINTRO"));
				DTO.setCustPicture(RS.getString("CUSTPICTURE"));
			}
		} catch (SQLException e) {
			System.out.println("LeadSelect ERROR : " + e);
		}
		return DTO;
	}

  public ArrayList<DongariDTO> LeadClubAmtSelect(String ID) {
    ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
    try {
       msg = "SELECT TO_CHAR(CLUBDATE,'MM') AS ClubDate ,SUM(PAYMENTAMT) AS ClubMonthlySum "
             + "FROM TSTUDENTBANKPAY " + "WHERE CLUBCODE IN( SELECT CLUBCODE "
             + "                    FROM TCLUBINFO " + "                    WHERE CUSTID = '" + ID + "') "
             + "GROUP BY TO_CHAR( CLUBDATE, 'MM' )" + "ORDER BY CLUBDATE";
       ST = CN.createStatement();
       RS = ST.executeQuery(msg);
       int i =0;
       while (RS.next() == true) {
            if(i++ == 0) {
               if(RS.getString("ClubMonthlySum")==""||RS.getString("ClubMonthlySum")==null) {
                  return null;
               }
            }
          DongariDTO DTO = new DongariDTO();
          DTO.setClubMonthlySum(RS.getString("ClubMonthlySum"));
          DTO.setClubDate(RS.getString("ClubDate"));
          list.add(DTO);
       }

    } catch (SQLException e) {
       System.out.println("LeadClubAmtSelect ERROR : " + e);
    }
    return list;
 }

	public HashMap<String, ArrayList<DongariDTO>> LeadClubAmtDetailSelect1(DongariDTO LEADER) {

		HashMap<String, ArrayList<DongariDTO>> hash = new HashMap<String, ArrayList<DongariDTO>>();
		LeaderSQL sql = new LeaderSQL();
		DongariDTO d = new DongariDTO();

		try {
			msg = "SELECT CLUBTITLE, SUM(CLUBCURRENTNUM*CLUBAMOUNT) AS CLUBAMTSUM \r\n" + "FROM TCLUBINFO\r\n"
					+ "WHERE CUSTID='" + LEADER.getCustId() + "'\r\n" + "GROUP BY CLUBTITLE";

			ST = CN.createStatement();
			RS = ST.executeQuery(msg);

			while (RS.next() == true) {
				LEADER.setClubTitle(RS.getString("CLUBTITLE"));
				ArrayList<DongariDTO> dto = sql.LeadClubAmtDetailSelect2(LEADER);
				hash.put(LEADER.getClubTitle(), dto);

			}
		} catch (SQLException e) {
			System.out.println("LeadClubAmtDetailSelect1( DongariDTO LEADER ) ERROR : " + e);
		}

		return hash;
	}

	public HashMap<String, ArrayList<DongariDTO>> LeadClubAmtDetailSelect1(DongariDTO LEADER, String pageNum,
			String title1) {
		HashMap<String, ArrayList<DongariDTO>> hash = new HashMap<String, ArrayList<DongariDTO>>();
		LeaderSQL sql = new LeaderSQL();
		DongariDTO d = new DongariDTO();

		try {
			msg = "SELECT CLUBTITLE \r\n" + "FROM TCLUBINFO\r\n" + "WHERE CUSTID='" + LEADER.getCustId() + "'\r\n"
					+ "GROUP BY CLUBTITLE";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);

			while (RS.next() == true) {
				ArrayList<DongariDTO> dto;
				String CLUBTITLE = RS.getString("CLUBTITLE");
				LEADER.setClubTitle(CLUBTITLE);
				if (title1.contains(CLUBTITLE)) {
					dto = sql.LeadClubAmtDetailSelect2(LEADER, pageNum);
				} else {
					dto = sql.LeadClubAmtDetailSelect2(LEADER);
				}
				hash.put(LEADER.getClubTitle(), dto);
			}
		} catch (SQLException e) {
			System.out.println("LeadClubAmtDetailSelect1( DongariDTO LEADER, String pageNum, String title1) ERROR : " + e);
		}

		return hash;
	}

	public ArrayList<DongariDTO> LeadClubAmtDetailSelect2(DongariDTO LEADER) {
		LeaderSQL sql = new LeaderSQL();
		PageCalculate PAGE = new PageCalculate();
		ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
		int culuamtsum = 0;
		String CLUBAMTSUM = "";

		try {
			msg = " SELECT * FROM (SELECT ROWNUM RN, X.* FROM(\r\n"
					+ " SELECT TO_CHAR(TSCI.CLUBDATE,'YY-MM-DD') AS CLUBDATE, TSCI.CUSTID , CI.CustName, TSCI.SettlementAmount, TCI.ClubTitle\r\n"
					+ "   FROM TStudentCourseInfo TSCI, TCUSTOMERINFO CI, TClubInfo TCI\r\n"
					+ "  WHERE TSCI.CUSTID   = CI.CUSTID\r\n" + "    AND TSCI.CLUBCODE = TCI.CLUBCODE\r\n"
					+ "    AND TSCI.CLUBDATE= TCI.CLUBDATE\r\n" + "    AND TSCI.CLUBSTART= TCI.CLUBSTART\r\n"
					+ "    AND TO_CHAR(TSCI.CLUBDATE,'MM') ='" + LEADER.getClubDate() + "'\r\n" + "    AND TCI.CLUBTITLE='"
					+ LEADER.getClubTitle() + "'" + "    AND TCI.CUSTID='" + LEADER.getCustId() + "'\r\n"
					+ "     ORDER BY TSCI.CLUBDATE ) X) WHERE RN BETWEEN 1 AND 10";
			ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			RS = ST.executeQuery(msg);
			int i = 0;
			RS.last();
			int rowCount = RS.getRow();
			RS.beforeFirst();

			while (RS.next() == true) {
				DongariDTO DTO = new DongariDTO();
				DTO.setRowNum(RS.getString("RN"));
				DTO.setClubDate(RS.getString("CLUBDATE"));
				DTO.setCustId(RS.getString("CUSTID"));
				DTO.setCustName(RS.getString("CustName"));
				DTO.setSettlementAmount(RS.getString("SettlementAmount"));
				i++;
				if (i == rowCount) {
					int SettlementAmount = Integer.parseInt(RS.getString("SettlementAmount"));
					int num = sql.TotalSelect(LEADER);
					DTO.setPageData(PAGE.LeaderDetailPage(num, 0));
					CLUBAMTSUM = Integer.toString(SettlementAmount * num);
					DTO.setClubAmtSum(CLUBAMTSUM);
				}

				list.add(DTO);
			}
		} catch (SQLException e) {
			System.out.println("LeadClubAmtDetailSelect2 ERROR : " + e);
		}
		return list;
	}

	public ArrayList<DongariDTO> LeadClubAmtDetailSelect2(DongariDTO LEADER, String pageNum) {
		ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
		PageCalculate PAGE = new PageCalculate();
		LeaderSQL sql = new LeaderSQL();
		String CLUBAMTSUM = "";
		int pagenum = Integer.parseInt(pageNum);
		int num = sql.TotalSelect(LEADER);
		int i = 0;

		pageNum page = PAGE.LeaderDetailPage(num, pagenum);

		try {
			msg = " SELECT * FROM (SELECT ROWNUM RN, X.* FROM(\r\n"
					+ " SELECT TO_CHAR(TSCI.CLUBDATE,'YY-MM-DD') AS CLUBDATE, TSCI.CUSTID , CI.CustName, TSCI.SettlementAmount, TCI.ClubTitle\r\n"
					+ "   FROM TStudentCourseInfo TSCI, TCUSTOMERINFO CI, TClubInfo TCI\r\n"
					+ "  WHERE TSCI.CUSTID   = CI.CUSTID\r\n" + "    AND TSCI.CLUBCODE = TCI.CLUBCODE\r\n"
					+ "    AND TSCI.CLUBDATE= TCI.CLUBDATE\r\n" + "    AND TSCI.CLUBSTART= TCI.CLUBSTART\r\n"
					+ "    AND TO_CHAR(TSCI.CLUBDATE,'MM') ='" + LEADER.getClubDate() + "'\r\n" + "    AND TCI.CLUBTITLE='"
					+ LEADER.getClubTitle() + "'" + "    AND TCI.CUSTID='" + LEADER.getCustId() + "'\r\n"
					+ "     ORDER BY TSCI.CLUBDATE" + "    ) X) WHERE RN BETWEEN " + page.getStart() + " AND " + page.getEnd();

			ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			RS = ST.executeQuery(msg);

			RS.last();
			int rowCount = RS.getRow();
			RS.beforeFirst();

			while (RS.next() == true) {
				DongariDTO DTO = new DongariDTO();
				DTO.setRowNum(RS.getString("RN"));
				DTO.setClubDate(RS.getString("CLUBDATE"));
				DTO.setCustId(RS.getString("CUSTID"));
				DTO.setCustName(RS.getString("CustName"));
				DTO.setSettlementAmount(RS.getString("SettlementAmount"));
				i++;

				if (i == rowCount) {
					int SettlementAmount = Integer.parseInt(RS.getString("SettlementAmount"));
					DTO.setPageData(page);
					CLUBAMTSUM = Integer.toString(SettlementAmount * num);
					DTO.setClubAmtSum(CLUBAMTSUM);
				}
				list.add(DTO);
			}
		} catch (SQLException e) {
			System.out.println("LeadClubAmtDetailSelect2 ERROR : " + e);
		}
		return list;
	}

	public int TotalSelect(DongariDTO LEADER) {
		int total = 0;

		try {
			msg = " SELECT COUNT( TSCI.CUSTID ) as CNT\r\n"
					+ "   FROM TStudentCourseInfo TSCI, TCUSTOMERINFO CI, TClubInfo TCI\r\n"
					+ "  WHERE TSCI.CUSTID   = CI.CUSTID\r\n" + "    AND TSCI.CLUBCODE = TCI.CLUBCODE\r\n"
					+ "    AND TSCI.CLUBDATE= TCI.CLUBDATE\r\n" + "    AND TSCI.CLUBSTART= TCI.CLUBSTART\r\n"
					+ "    AND TO_CHAR(TSCI.CLUBDATE,'MM') ='" + LEADER.getClubDate() + "'\r\n" + "    AND TCI.CLUBTITLE='"
					+ LEADER.getClubTitle() + "'\r\n" + "    AND TCI.CUSTID='" + LEADER.getCustId() + "'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			total = Integer.parseInt(RS.getString("CNT"));
		} catch (SQLException e) {
			System.out.println("LeadClubAmtDetailSelect2 ERROR : " + e);
		}
		return total;
	}

	/* 리더 후기 */
	public ArrayList<ReviewDTO> LeadClubReview(ReviewDTO LEADER, String pageNum) {
		ArrayList<ReviewDTO> list = new ArrayList<ReviewDTO>();
		PageCalculate page = new PageCalculate();
		LeaderSQL sql = new LeaderSQL();
		if (pageNum == null || pageNum == "0") {
			pageNum = "1";
		}
		int pagenum = Integer.parseInt(pageNum);
		pageNum PAGE = page.LeaderReviewPage(sql.ReviewTotal(LEADER), pagenum);

		try {
			msg = " SELECT * FROM (SELECT ROWNUM RN, X.* FROM(\r\n"
					+ "            SELECT TCI.CLUBTITLE, TSIC.CUSTID, TSIC.CLUBDATE, TSIC.REVIEW, TSIC.REVIEWDATE,  TSIC.STARLEVEL1, TSIC.STARLEVEL2, TSIC.STARLEVEL3,  CI.CUSTPICTURE\r\n"
					+ "            FROM TCLUBINFO TCI, TSTUDENTCOURSEINFO TSIC, TCUSTOMERINFO CI\r\n"
					+ "            WHERE TCI.CLUBCODE = TSIC.CLUBCODE\r\n" + "             AND  TSIC.CUSTID   = CI.CUSTID\r\n"
					+ "             AND  TCI.CLUBDATE  = TSIC.CLUBDATE\r\n"
					+ "             AND  TCI.CLUBSTART = TSIC.CLUBSTART\r\n" + "            AND  TCI.CLUBTITLE = '"
					+ LEADER.getClubTitle() + "'\r\n" + "            AND  TCI.CUSTID='" + LEADER.getCustId() + "'\r\n"
					+ "        ORDER BY TCI.CLUBTITLE, TSIC.REVIEWDATE ) X) WHERE RN BETWEEN " + PAGE.getStart() + " AND "
					+ PAGE.getEnd() + "";

			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			int i = 0;
			while (RS.next() == true) {
				ReviewDTO DTO = new ReviewDTO();
				DTO.setRowNum(RS.getString("RN"));
				DTO.setClubTitle(RS.getString("CLUBTITLE"));
				DTO.setCustId(RS.getString("CUSTID"));
				DTO.setClubDate(RS.getString("CLUBDATE"));
				DTO.setReview(RS.getString("REVIEW"));
				DTO.setReviewDate(RS.getString("REVIEWDATE"));
				DTO.setStarLevel1(RS.getString("STARLEVEL1"));
				DTO.setStarLevel2(RS.getString("STARLEVEL2"));
				DTO.setStarLevel3(RS.getString("STARLEVEL3"));
				DTO.setCustPicture(RS.getString("CUSTPICTURE"));
				if (i == 4) {
					DTO.setPageData(PAGE);
				}
				i++;
				list.add(DTO);
			}
		} catch (SQLException e) {
			System.out.println("LeadClubReview ERROR : " + e);
		}
		return list;
	}

	public int ReviewTotal(ReviewDTO LEADER) {
		int total = 0;
		try {
			msg = "SELECT COUNT(TSIC.CUSTID) COUNT\r\n" + "FROM TCLUBINFO TCI, TSTUDENTCOURSEINFO TSIC\r\n"
					+ "WHERE TCI.CLUBCODE = TSIC.CLUBCODE\r\n" + "AND  TCI.CLUBDATE = TSIC.CLUBDATE\r\n"
					+ "AND  TCI.CLUBSTART = TSIC.CLUBSTART\r\n" + "AND  TCI.CLUBTITLE = '" + LEADER.getClubTitle() + "'\r\n"
					+ "AND  TCI.CUSTID='" + LEADER.getCustId() + "'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			total = Integer.parseInt(RS.getString("COUNT"));
		} catch (SQLException e) {
			System.out.println("ReviewTotal ERROR : " + e);
		}
		return total;
	}

	public ArrayList<String> LeadClubReviewTitle(String ID) {
		ArrayList<String> list = new ArrayList<String>();
		try {
			msg = "SELECT CLUBTITLE FROM TCLUBINFO WHERE CUSTID='" + ID + "' GROUP BY CLUBTITLE ORDER BY CLUBTITLE";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);

			while (RS.next() == true) {
				list.add(RS.getString("CLUBTITLE"));
			}
		} catch (SQLException e) {
			System.out.println("LeadClubReviewTitle ERROR : " + e);
		}
		return list;
	}

	
	
	
	//====================================================================================================================================================
	
	
  // 리더의 cus_leaderProfile.jsp 에서 사용할 정보들
  public LeaderDTO leaderProfile(String leaderID) {
     LeaderDTO DTO = new LeaderDTO();
     try {
        msg = "SELECT TCI.LEADNAME, TCI.LEADINTRO, TCI.LEADREGIDATE, TCI.CUSTPICTURE, \r\n"
              + "       TL.LICENSE1, TL.LICENSE2, TL.LICENSE3, TL.LICENSE4, TL.LICENSE5,\r\n"
              + "       TE.EXPERTISE1, TO_CHAR(TE.EXPERTSTART1,'YY/MM') AS EXPERTSTART1, TO_CHAR(TE.EXPERTEND1,'YY/MM') AS EXPERTEND1,\r\n"
              + "       TE.EXPERTISE2, TO_CHAR(TE.EXPERTSTART2,'YY/MM') AS EXPERTSTART2, TO_CHAR(TE.EXPERTEND2,'YY/MM') AS EXPERTEND2,\r\n"
              + "       TE.EXPERTISE3, TO_CHAR(TE.EXPERTSTART3,'YY/MM') AS EXPERTSTART3, TO_CHAR(TE.EXPERTEND3,'YY/MM') AS EXPERTEND3,\r\n"
              + "       TE.EXPERTISE4, TO_CHAR(TE.EXPERTSTART4,'YY/MM') AS EXPERTSTART4, TO_CHAR(TE.EXPERTEND4,'YY/MM') AS EXPERTEND4,\r\n"
              + "       TE.EXPERTISE5, TO_CHAR(TE.EXPERTSTART4,'YY/MM') AS EXPERTSTART5, TO_CHAR(TE.EXPERTEND5,'YY/MM') AS EXPERTEND5\r\n"
              + "FROM TCUSTOMERINFO TCI, TEXPERTISE TE, TLICENSE TL  \r\n" + "WHERE TL.CUSTID = TE.CUSTID\r\n"
              + "  AND TE.CUSTID = TCI.CUSTID\r\n" + "  AND TCI.CUSTID LIKE '" + leaderID + "'";
        ST = CN.createStatement();
        RS = ST.executeQuery(msg);
        RS.next();
        DTO.setLeadName(RS.getString("LEADNAME"));
        DTO.setLeadIntro(RS.getString("LEADINTRO"));
        DTO.setCustPicture(RS.getString("CUSTPICTURE"));
        DTO.setLeadregiDate(RS.getString("LEADREGIDATE"));
        DTO.setLicense1(RS.getString("LICENSE1"));
        DTO.setLicense2(RS.getString("LICENSE2"));
        DTO.setLicense3(RS.getString("LICENSE3"));
        DTO.setLicense4(RS.getString("LICENSE4"));
        DTO.setLicense5(RS.getString("LICENSE5"));
        DTO.setExpertise1(RS.getString("EXPERTISE1"));
        DTO.setExpertise2(RS.getString("EXPERTISE2"));
        DTO.setExpertise3(RS.getString("EXPERTISE3"));
        DTO.setExpertise4(RS.getString("EXPERTISE4"));
        DTO.setExpertise5(RS.getString("EXPERTISE5"));
     } catch (SQLException e) {
        System.out.println("leaderProfile ERROR : " + e);
     }
     return DTO;
  }
  

  // 리더의 동아리 목록과 속성 club_boxList.jsp 에서 사용
  public ArrayList<DongariDTO> LeadClubBox(String leaderID) {
     ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
     try {
        msg = "  SELECT CLUBTITLE,  CLUBPICTURE1, AVGSTARLEVEL,CLUBSKILLLEVEL, CLUBAMOUNT , CLUBCODE, CLUBTITLECODE \r\n"
              + "    FROM TCLUBINFO \r\n" + "   WHERE CUSTID LIKE '" + leaderID + "'\r\n"
              + "GROUP BY CLUBTITLE, CLUBPICTURE1, AVGSTARLEVEL, CLUBSKILLLEVEL, CLUBAMOUNT, CLUBCODE, CLUBTITLECODE \r\n "
              + "ORDER BY CLUBTITLE";
        ST = CN.createStatement();
        RS = ST.executeQuery(msg);

        while (RS.next() == true) {
           DongariDTO DTO = new DongariDTO();
           DTO.setCustId(leaderID);
           DTO.setClubTitle(RS.getString("CLUBTITLE"));
           DTO.setClubCode(RS.getString("CLUBCODE"));
           DTO.setClubTitleCode(RS.getString("CLUBTITLECODE"));
           DTO.setRePicture(RS.getString("CLUBPICTURE1"));
           DTO.setAverage(RS.getString("AVGSTARLEVEL"));
           DTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
           DTO.setClubAmount(RS.getString("CLUBAMOUNT"));
           list.add(DTO);
        }
     } catch (SQLException e) {
        System.out.println("LeadClubBox ERROR : " + e);
     }
     return list;
  }
  
  
  //================================0926
  //이 리더가 경력이 있는지 없는지 알아내는 함수
  public int LeadExpertExist(String CustId) {
  	int count=0;
  	try {
  		msg="SELECT COUNT(*) AS CNT FROM TExpertise WHERE CUSTID='"+CustId+"'";
			ST = CN.createStatement();
      RS = ST.executeQuery(msg);
      RS.next();
      count = Integer.parseInt(RS.getString("CNT"));
      if(count==0) {      //경력이 없음 
      	count=0;
      } else {
      	count=1; 				//경력이 있음  
      }
		} catch (Exception e) {System.out.println("[LeadExpertExist] ERROR : " + e);}
  		return count;
		}
  	
  
  //경력 내용 출력
  public LeaderDTO LeadExpertSelect(String CustID) {
  	LeaderDTO leadDTO = new LeaderDTO();
  	try {
  		msg="SELECT * FROM TExpertise WHERE CUSTID='"+CustID+"'";
			ST = CN.createStatement();
      RS = ST.executeQuery(msg);
      RS.next();
      	leadDTO.setExpertise1(RS.getString("EXPERTISE1"));
      	leadDTO.setExpertise2(RS.getString("EXPERTISE2"));
      	leadDTO.setExpertise3(RS.getString("EXPERTISE3"));
      	leadDTO.setExpertise4(RS.getString("EXPERTISE4"));
      	leadDTO.setExpertise4(RS.getString("EXPERTISE5"));
		} catch (Exception e) {System.out.println("[LeadExpertSelect] ERROR : " + e);}
  	return leadDTO;
  }
  
  //경력 등록
  public void UpdateExpertie(String CustId, String exp1, String exp2, String exp3, String exp4, String exp5) {
  	try {
  	msg="INSERT INTO TEXPERTISE VALUES(\r\n" + 
        "'"+CustId+"',"+
  			"'"+exp1+"',"+
  			"'"+exp2+"',"+
  			"'"+exp3+"',"+
  			"'"+exp4+"',"+
  			"'"+exp5+"')";
		ST = CN.createStatement();
    RS = ST.executeQuery(msg);
    RS.next();
  	} catch(Exception e) {System.out.println("[UpdateExpertie] ERROR : " + e);}
  }
  
  // 경력 수정
  public void EditExpertie(String CustId, String exp1, String exp2, String exp3, String exp4, String exp5) {
  	try {
    	msg="UPDATE TEXPERTISE SET \r\n" + 
    			"EXPERTISE1='"+exp1+"',\r\n" + 
    			"EXPERTISE2='"+exp2+"',\r\n" + 
    			"EXPERTISE3='"+exp3+"',\r\n" + 
    			"EXPERTISE4='"+exp4+"',\r\n" + 
    			"EXPERTISE5='"+exp5+"'\r\n" +
    			"WHERE CUSTID='"+CustId+"'";
    	ST = CN.createStatement();
      ST.executeUpdate(msg); 
    	} catch(Exception e) {System.out.println("[EditExpertie] ERROR : " + e);}
  }
  
  
  //자격증 유무
  public int LeadLicenseExist(String CustId) {
  	int count=0;
  	try {
  		msg="SELECT COUNT(*) AS CNT FROM TLICENSE WHERE CUSTID='"+CustId+"'";
			ST = CN.createStatement();
      RS = ST.executeQuery(msg);
      RS.next();
      count = Integer.parseInt(RS.getString("CNT"));
      if(count==0) {      //자격증이 없음 
      	count=0;
      } else {
      	count=1; 				//자격증이 있음 
      }
		} catch (Exception e) {System.out.println("[LeadExpertExist] ERROR : " + e);}
  		return count;
		}
  
  //자격증 등록
  public void UpdateLicense(String CustId, String lic1, String lic2, String lic3, String lic4, String lic5) {
  	try {
  	msg="INSERT INTO TLICENSE VALUES(\r\n" + 
        "'"+CustId+"',"+
  			"'"+lic1+"',"+
  			"'"+lic2+"',"+
  			"'"+lic3+"',"+
  			"'"+lic4+"',"+
  			"'"+lic5+"')";
		ST = CN.createStatement();
    RS = ST.executeQuery(msg);
    RS.next();
  	} catch(Exception e) {System.out.println("[UpdateLicense] ERROR : " + e);}
  }
  
  //자격증 내용
  public LeaderDTO LeadLicenseSelect(String CustID) {
  	LeaderDTO leadDTO = new LeaderDTO();
  	try {
  		msg="SELECT * FROM TLICENSE WHERE CUSTID='"+CustID+"'";
			ST = CN.createStatement();
      RS = ST.executeQuery(msg);
      RS.next();
      	leadDTO.setLicense1(RS.getString("License1"));
      	leadDTO.setLicense2(RS.getString("License2"));
      	leadDTO.setLicense3(RS.getString("License3"));
      	leadDTO.setLicense4(RS.getString("License4"));
      	leadDTO.setLicense5(RS.getString("License5"));
		} catch (Exception e) {System.out.println("[LeadLicenseSelect] ERROR : " + e);}
  	return leadDTO;
  }
  
  
  public void EditLicense(String CustId, String lic1, String lic2, String lic3, String lic4, String lic5) {
  	try {
    	msg="UPDATE TLICENSE SET \r\n" + 
    			"License1='"+lic1+"',\r\n" + 
    			"License2='"+lic2+"',\r\n" + 
    			"License3='"+lic3+"',\r\n" + 
    			"License4='"+lic4+"',\r\n" + 
    			"License5='"+lic5+"'\r\n" +
    			"WHERE CUSTID='"+CustId+"'";
    	ST = CN.createStatement();
      ST.executeUpdate(msg); 
    	} catch(Exception e) {System.out.println("[EditExpertie] ERROR : " + e);}
  }
  
  
  public LeaderDTO LeadSelect2(String ID) {
		LeaderDTO DTO = new LeaderDTO();
		try {
			msg = "SELECT LEADNAME, LEADINTRO, LEADLOCAL, LEADBANKNAME, LEADBANKNUM, LEADREGIDATE \r\n" + 
					"FROM TCUSTOMERINFO WHERE CUSTID='"+ID+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			if (RS.next() == true) {
				DTO.setLeadName(RS.getString("LEADNAME"));
				DTO.setLeadIntro(RS.getString("LEADINTRO"));
				DTO.setLeadLocal(RS.getString("LEADLOCAL"));
				DTO.setLeadBankName(RS.getString("LeadBankName"));
				DTO.setLeadBankNum(RS.getString("LeadBankNum"));
				DTO.setLeadregiDate(RS.getString("LEADREGIDATE"));
			}
		} catch (SQLException e) {System.out.println("[LeadSelect2] ERROR : " + e);}
		return DTO;
	}
  
  
  
  public void LeadEditSave(String ID, String Nick, String Intro, String Local, String Bank, String BankNum) {
  	try {
  		msg = "UPDATE TCUSTOMERINFO SET\r\n" + 
  					"LEADNAME='"+Nick+"',\r\n" + 
  					"LEADINTRO='"+Intro+"',\r\n" + 
  					"LEADLOCAL='"+Local+"',\r\n" + 
  					"LEADBANKNAME='"+Bank+"',\r\n" + 
  					"LEADBANKNUM='"+BankNum+"'\r\n" + 
  					"WHERE CUSTID='"+ID+"'";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
		} catch (Exception e) {System.out.println("[LeadSelect] ERROR : " + e);}
  }
}