package club.pjt.sql;

public class PaymentDTO {
   
   // 확인 및 결제창에 띄우기 위해서 변형해서 반환해줄 속성
   private String LeaderId;
   private String custId;
   private String clubCode;
   private String clubTitle;
   private String clubRunTime;
   private String clubLeaderName;
   private String clubDate;
   private String clubStart;
   private String clubEnd;
   private String clubAmount;
   
   private String phoneNumber;
   // 카드 정보
   private String cardName;
   private String cardNum1;
   private String cardNum2;
   private String cardNum3;
   private String cardNum4;
   private String expiryDate;
   private String cardPassword;
   private String cardCvc;

   // 결제 정보
   private String bankCustName;
   private String bankName;
   private String bankNumber;

    
   public PaymentDTO() {
      
   }
   // 확인 및 결제창에 띄우기 위한 속성들 구해 올때 설정하는 역활.
   public PaymentDTO( String LeaderId, String clubCode, String clubDate, String clubStart) {
      this.LeaderId = LeaderId;
      this.clubCode = clubCode;
      this.clubDate = clubDate;
      this.clubStart = clubStart;
      
   }
   
   public String getCustId() {
      return custId;
   }
   public void setCustId(String custId) {
      this.custId = custId;
   }
   public String getLeaderId() {
      return LeaderId;
   }
   public void setLeaderId(String leaderId) {
      LeaderId = leaderId;
   }
   public String getClubCode() {
      return clubCode;
   }
   public void setClubCode(String clubCode) {
      this.clubCode = clubCode;
   }
   public String getClubTitle() {
      return clubTitle;
   }
   public void setClubTitle(String clubTitle) {
      this.clubTitle = clubTitle;
   }
   public String getClubRunTime() {
      return clubRunTime;
   }
   public void setClubRunTime(String clubRunTime) {
      this.clubRunTime = clubRunTime;
   }
   public String getClubLeaderName() {
      return clubLeaderName;
   }
   public void setClubLeaderName(String clubLeaderName) {
      this.clubLeaderName = clubLeaderName;
   }
   public String getClubDate() {
      return clubDate;
   }
   public void setClubDate(String clubDate) {
      this.clubDate = clubDate;
   }
   public String getClubStart() {
      return clubStart;
   }
   public void setClubStart(String clubStart) {
      this.clubStart = clubStart;
   }
   public String getClubEnd() {
      return clubEnd;
   }
   public void setClubEnd(String clubEnd) {
      this.clubEnd = clubEnd;
   }
   public String getClubAmount() {
      return clubAmount;
   }
   public void setClubAmount(String clubAmount) {
      this.clubAmount = clubAmount;
   }
   public String getPhoneNumber() {
      return phoneNumber;
   }
   public void setPhoneNumber(String phoneNumber) {
      this.phoneNumber = phoneNumber;
   }
   public String getCardName() {
      return cardName;
   }
   public void setCardName(String cardName) {
      this.cardName = cardName;
   }
   // 카드번호 합쳐서 반환
   public String getCardNumber() {
      return cardNum1 + cardNum2 + cardNum3 + cardNum4;
   }

   public String getCardNum1() {
      return cardNum1;
   }
   public void setCardNum1(String cardNum1) {
      this.cardNum1 = cardNum1;
   }
   public String getCardNum2() {
      return cardNum2;
   }
   public void setCardNum2(String cardNum2) {
      this.cardNum2 = cardNum2;
   }
   public String getCardNum3() {
      return cardNum3;
   }
   public void setCardNum3(String cardNum3) {
      this.cardNum3 = cardNum3;
   }
   public String getCardNum4() {
      return cardNum4;
   }
   public void setCardNum4(String cardNum4) {
      this.cardNum4 = cardNum4;
   }
   public String getExpiryDate() {
      return expiryDate;
   }
   public void setExpiryDate(String expiryDate) {
      this.expiryDate = expiryDate;
   }
   public String getCardPassword() {
      return cardPassword;
   }
   public void setCardPassword(String cardPassword) {
      this.cardPassword = cardPassword;
   }
   public String getCardCvc() {
      return cardCvc;
   }
   public void setCardCvc(String cardCvc) {
      this.cardCvc = cardCvc;
   }
   public String getBankCustName() {
      return bankCustName;
   }
   public void setBankCustName(String bankCustName) {
      this.bankCustName = bankCustName;
   }
   public String getBankName() {
      return bankName;
   }
   public void setBankName(String bankName) {
      this.bankName = bankName;
   }
   public String getBankNumber() {
      return bankNumber;
   }
   public void setBankNumber(String bankNumber) {
      this.bankNumber = bankNumber;
   }
   
   // SQL 에서 결제 정보를 가져와 보여줄 때 은행이름, 카드 이름은 아래 Get을 이용 할 것 (code->한국말)
   public String CardBankNumGet( String Code ) {
      if( Code.equals("381")) {
         return "KB 국민카드";
      }else if( Code.equals("366") ) {
         return "신한카드";
      }else if( Code.equals("044") ) {
         return "하나카드";
      }else if( Code.equals("368") ) {
         return "롯데카드";
      }else if( Code.equals("361") ) {
         return "BC카드";
      }else if( Code.equals("371") ) {
         return "NH농협카드";
      }else if( Code.equals("365") ) {
         return "삼성카드";
      }else if( Code.equals("367") ) {
         return "현대카드";
      }
      return "";
   }
   public String CashBankNumGet( String Code ) {
      if( Code.equals("011")) {
         return "농협 은행";
      }else if( Code.equals("081") ) {
         return "하나 은행";
      }else if( Code.equals("005") ) {
         return "외환 은행";
      }else if( Code.equals("020") ) {
         return "우리 은행";
      }else if( Code.equals("004") ) {
         return "국민 은행";
      }else if( Code.equals("027") ) {
         return "씨티 은행";
      }else if( Code.equals("071") ) {
         return "우채국 은행";
      }else if( Code.equals("048") ) {
         return "산업 은행";
      }else if( Code.equals("007") ) {
         return "수협 은행";
      }else if( Code.equals("088") ) {
         return "신한 은행";
      }else if( Code.equals("045") ) {
         return "새마을금고 은행";
      }
      return "";
   }
   
   // 카드
   public void CardtoString( PaymentDTO DTO ) {
      System.out.println("CardtoString 데이터 잘 들어왔나 체크 후 삭제");
      System.out.println("\nCustId        = " + this.custId + 
                     "\nclubCode     = " + this.clubCode +
                     "\nclubDate     = " + this.clubDate + 
                     "\nclubStart    = " + this.clubStart + 
                     "\ncardName     = " + this.cardName +
                     "\ncardNum1     = " + this.cardNum1 + 
                     "\ncardNum2     = " + this.cardNum2 + 
                     "\ncardNum3     = " + this.cardNum3 + 
                     "\ncardNum4     = " + this.cardNum4 + 
                     "\nexpiryDate   = " + this.expiryDate + 
                     "\ncardPassword = " + this.cardPassword + 
                     "\ncardCvc      = " + this.cardCvc +
                     "\nclubAmount   = " + this.clubAmount );
   }
   // 계좌
   public void BanktoString( PaymentDTO DTO ) {
      System.out.println("BanktoString 데이터 잘 들어왔나 체크 후 삭제");
      System.out.println("\nCustId        = " + this.custId + 
                     "\nclubCode     = " + this.clubCode +
                     "\nclubDate     = " + this.clubDate + 
                     "\nclubStart    = " + this.clubStart + 
                     "\nphoneNumber  = " + this.phoneNumber + 
                     "\nbankCustName = " + this.bankCustName + 
                     "\nbankName     = " + this.bankName + 
                     "\nbankNumber   = " + this.bankNumber +
                     "\nclubAmount   = " + this.clubAmount );
   }
}