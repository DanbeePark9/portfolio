package club.pjt.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PaymentSQL {
   
    Connection CN;
    Statement ST; 
    PreparedStatement PST;
    CallableStatement CST; 
    ResultSet RS; 
    String msg,a,b;
    DongariDTO DongDTO;
    ReviewDTO ReviewDTO;
    
    public PaymentSQL() {
        CN = DB.getConnection();
     }
    
    // 확인 결제 창에 보여줄 수업 정보
    public PaymentDTO PaymentInfo( PaymentDTO DTO ) {
       PaymentSQL SQL = new PaymentSQL();
       try {
          msg = "SELECT CLUBTITLE, TO_CHAR(CLUBDATE, 'YY/MM/DD(DY)') AS CLUBDATE,\r\n" + 
                "       TO_CHAR(CLUBEND, 'HH24:MI')                AS CLUBEND ,\r\n" + 
                "       TO_CHAR(CLUBSTART, 'YYYY/MM/DD HH24:MI')   AS TIME1,\r\n" + 
                "       TO_CHAR(CLUBEND,   'YYYY/MM/DD HH24:MI')   AS TIME2,\r\n"+
                "       CLUBAMOUNT\r\n" + 
                "FROM TCLUBINFO\r\n" + 
                "WHERE CUSTID   LIKE '"+DTO.getLeaderId()+"'\r\n" + 
                "  AND CLUBCODE LIKE '"+DTO.getClubCode()+"'\r\n" + 
                "  AND TO_CHAR(CLUBDATE, 'YY/MM/DD') LIKE '"+DTO.getClubDate()+"'\r\n" + 
                "  AND TO_CHAR(CLUBSTART, 'HH24:MI') LIKE '"+DTO.getClubStart()+"'";
          ST = CN.createStatement();
          RS = ST.executeQuery(msg);
          RS.next();
          DTO.setClubTitle(RS.getString("CLUBTITLE"));
          DTO.setClubDate(RS.getString("CLUBDATE"));
          DTO.setClubEnd(RS.getString("CLUBEND"));
          DTO.setClubAmount(RS.getString("CLUBAMOUNT"));
          DTO.setClubRunTime(SQL.RunTimeGet( RS.getString("TIME1"), RS.getString("TIME2")));
       } catch (SQLException e) {
            System.out.println("(PaymentSQL) PaymentInfo ERROR : " + e);
       }
       return DTO;
    }
    
    // 수업 런타임 구해주는 쿼리
    public String RunTimeGet( String T1, String T2 ) {
       String runTime="";
       try {
          msg = "SELECT TRUNC( MOD(SI,  24)) AS SI,\r\n" + 
                "        TRUNC( MOD(MIN, 60)) AS MIN\r\n" + 
                "   FROM ( SELECT COL*24*60 AS MIN,\r\n"  + 
                "                     COL*24    AS SI\r\n"+ 
                "                FROM ( SELECT TO_DATE('"+T2+"','YYYY/MM/DD HH24:MI:SS') - TO_DATE('"+T1+"','YYYY-MM-DD HH24:MI:SS') COL FROM DUAL))";
          ST = CN.createStatement();
          RS = ST.executeQuery(msg);
          RS.next();
          // 시간차
          T1 = RS.getString("SI");
          // 분차이
          T2 = RS.getString("MIN");
          if( T2.equals("0") ) {
             runTime = T1 + "시간 "; 
          }else {
             runTime = T1 + "시간 " + T2 + "분"; 
          }
       } catch (SQLException e) {
            System.out.println("(PaymentSQL) RunTimeGet ERROR : " + e);
       }
       return runTime;
    }
    
    // 학생 수강정보 저장
    public void TStudentCourseInfoInsert(PaymentDTO DTO, String SettlemenType ){
        try {
           msg = "INSERT INTO TStudentCourseInfo\r\n" + 
                 "( CUSTID, CLUBCODE ,CLUBDATE, CLUBSTART, APPLYDATE, SETTLEMENTTYPE, SETTLEMENTAMOUNT ) \r\n" + 
                 "VALUES( '"+ DTO.getCustId() +"',\r\n" + 
                 "        '"+ DTO.getClubCode() +"', \r\n" + 
                 "        TO_DATE('"+ DTO.getClubDate() +"','YY/MM/DD'), \r\n" + 
                 "        TO_DATE('"+ DTO.getClubStart() +"','HH24:MI'), \r\n" + 
                 "        SYSDATE, \r\n" + 
                 "        '"+ SettlemenType +"',\r\n" + 
                 "        '"+ DTO.getClubAmount() +"' )";
           
            PST = CN.prepareStatement(msg);
              PST.executeUpdate(); 
        } catch (Exception e) {System.out.println("(PaymentSQL) TStudentCourseInfoInsert ERROR : "+e);}
     }
     
    
    // 카드 결제 정보 저장
    public boolean ClubCardPayment(PaymentDTO DTO){
       PaymentSQL SQL = new PaymentSQL();
        try {
           msg = "INSERT INTO TStudentCardPay VALUES(\r\n" + 
                 "                '"+ DTO.getCustId() +"',\r\n" + 
                 "                '"+ DTO.getClubCode() +"',\r\n" + 
                 "                TO_DATE('"+ DTO.getClubDate() +"','YY/MM/DD'),\r\n" + 
                 "                TO_DATE('"+ DTO.getClubStart()+"','HH24:MI'),\r\n" + 
                 "                SYSDATE,\r\n" + 
                 "                '"+ DTO.getCardName() +"',\r\n" + 
                 "                '"+ DTO.getCardNumber() + "'\r\n" + 
                 "                ,TO_DATE('"+DTO.getExpiryDate()+"','YY/MM'),\r\n" + 
                 "                '"+DTO.getCardPassword()+"',\r\n" + 
                 "                '"+DTO.getClubAmount()+"')";
            PST = CN.prepareStatement(msg);
              PST.executeUpdate(); 
             SQL.TStudentCourseInfoInsert( DTO, "CARD" );
             return true;
        } catch (Exception e) {
           System.out.println("(PaymentSQL) ClubCardPayment ERROR : "+e);
            return false;
        }
     }
     
    // 계좌 결제 정보 저장
    public boolean ClubBankPayment(PaymentDTO DTO){
       PaymentSQL SQL = new PaymentSQL();
        try {
           msg = "INSERT INTO TStudentBankPay VALUES(?,?,TO_DATE(?,'YY/MM/DD'),TO_DATE(?,'HH24:MI'),SYSDATE,?,?,?)";

             PST = CN.prepareStatement(msg);
             PST.setString(1, DTO.getCustId());
             PST.setString(2, DTO.getClubCode());
             PST.setString(3, DTO.getClubDate());
             PST.setString(4, DTO.getClubStart());
             PST.setString(5, DTO.getBankName());
             PST.setString(6, DTO.getBankNumber());
             PST.setString(7, DTO.getClubAmount());
              PST.executeUpdate(); 
             SQL.TStudentCourseInfoInsert( DTO, "CASH" );
           return true;
        } catch (Exception e) {
           System.out.println("(PaymentSQL) ClubCardPayment ERROR : "+e);
           return false;
    }
     }
}