package club.pjt.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentSQL {
	Connection CN;
  Statement ST; 
  PreparedStatement PST;
  CallableStatement CST; 
  ResultSet RS; 
  String msg;
  
  
  public StudentSQL() {
    CN = DB.getConnection();
}
	
	 public ArrayList<CalendarDTO> StudCalendarSelect( CalendarDTO LEADER  ) {
     ArrayList<CalendarDTO> list = new ArrayList<CalendarDTO>();
      try {
         msg = "SELECT DISTINCT TO_CHAR(CI.ClubDate,'DD')   AS ClubDate, CI.CLUBTITLE, \r\n" + 
         		"       TO_CHAR(CI.ClubStart,'HH24')AS startM,   TO_CHAR(CI.ClubStart,'MI')  AS startH,        \r\n" + 
         		"       TO_CHAR(CI.ClubEnd,'HH24')  AS endM,     TO_CHAR(CI.ClubEnd,'MI')    AS endH     \r\n" + 
         		"       FROM TClubInfo CI, TSTUDENTCOURSEINFO TSCI\r\n" + 
         		"       WHERE TSCI.CustId='sky1' AND TO_CHAR(CI.ClubDate,'MM')=11 ORDER BY CLUBDATE";
          // 추가 시키기 나중에 지금은 10월 데이터 뽑기위해 고정값"+LEADER.getMonth()+"
         ST = CN.createStatement();
         RS = ST.executeQuery(msg);
          while(RS.next()==true) {
             CalendarDTO dto = new CalendarDTO();
             dto.setTitle(RS.getString("CLUBTITLE"));
             dto.setYear("20");
             dto.setDay(RS.getString("ClubDate"));
             dto.setStartM(RS.getString("startM"));
             dto.setstartH(RS.getString("startH"));
             dto.setEndM(RS.getString("endM"));
             dto.setEndH(RS.getString("endH"));
             dto.setidx1("10"+RS.getString("ClubDate")+RS.getString("startM")+RS.getString("startH"));   
             list.add(dto);
           }

          for( int i=list.size(); i<=31; i++ ) {
             CalendarDTO dto = new CalendarDTO();
             dto.setTitle("X");
             dto.setYear("");
             dto.setDay("");
             dto.setStartM("");
             dto.setstartH("");
             dto.setEndM("");
             dto.setEndH("");
             list.add(dto);
           }
       } catch (SQLException e) {System.out.println("LeadCalendarSelect ERROR : " + e );}
       return list;
    }
	 
	 public ArrayList<StudentDTO> ScheduleSelect(String ID){
		 ArrayList<StudentDTO> list = new ArrayList<StudentDTO>();
		 try {
			 msg = "SELECT * FROM TSTUDENTCOURSEINFO WHERE CUSTID='"+ID+"' ORDER BY CLUBDATE";
			 ST = CN.createStatement();
       RS = ST.executeQuery(msg);
       while(RS.next()==true) {
         StudentDTO StudDTO = new StudentDTO();
         StudDTO.setClubCode(RS.getString("ClubCode"));
         StudDTO.setClubDate(RS.getString("ClubDate"));
         StudDTO.setClubStart(RS.getString("ClubStart"));
         StudDTO.setApplyDate(RS.getString("ApplyDate"));
         StudDTO.setApplyDate(RS.getString("CancelDate"));
         StudDTO.setSettlementType(RS.getString("SettlementType"));
         StudDTO.setSettlementAmount(RS.getString("SettlementAmount"));
         StudDTO.setStarLevel1(RS.getString("StarLevel1"));
         StudDTO.setStarLevel2(RS.getString("StarLevel2"));
         StudDTO.setStarLevel3(RS.getString("StarLevel3"));
         StudDTO.setReview(RS.getString("Review"));
         StudDTO.setReviewDate(RS.getString("ReviewDate"));
         list.add(StudDTO);
       }
		} catch (Exception e) {System.out.println("[ScheduleSelect] ERROR : " + e );}
		 return list;
	 }
	 
	 public String StudentClubDate( String ID , String idx1 ) {
     
     String date = idx1.substring(0,2) + "/" + idx1.substring(2,4);
     String time = idx1.substring(4,6) + ":" + idx1.substring(6,8);
     String title ="";
        try {
           msg = "SELECT CLUBTITLE FROM TCLUBINFO \r\n" + 
                 "WHERE TO_CHAR( CLUBDATE, 'MM/DD'  )='"+date+"'" + 
                 "  AND TO_CHAR( CLUBSTART,'HH24:MI')='"+time+"'" +
                 "  AND CUSTID='"+ID+"'"; 
           ST = CN.createStatement();
           RS = ST.executeQuery(msg);
           if(RS.next()==true) {
          	 title = RS.getString("CLUBTITLE");
           } else {
          	 title="null";
           }
        } catch (SQLException e) {
           System.out.println("StudentClubTitle ERROR : " + e );
        }
        return title;
   }
	 
	 
}
