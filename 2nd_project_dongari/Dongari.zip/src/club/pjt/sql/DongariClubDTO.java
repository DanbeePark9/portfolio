package club.pjt.sql;

public class DongariClubDTO {
   
   private String custid;
   private String clubcode;
   private String clubTitle;
   private String clubIntro;
   private String clubAddress;
   private String clubSkillLevel;
   private String clubDate;
   private String clubTitleCode;
   private String custId;
   private String clubstart;
   private String clubend;
   private String clubsupplies;
   private String clubamount;
   private String clubpicture1;
   private String clubpicture2;
   private String clubpicture3;
   private String clubpicture4;
   private String clubmax;
   private String clubGenre;
   private String location;
   
   public String getClubcode() {
      return clubcode;
   }
   public void setClubcode(String clubcode) {
      this.clubcode = clubcode;
   }
   public String getClubTitle() {
      return clubTitle;
   }
   public void setClubTitle(String clubTitle) {
      this.clubTitle = clubTitle;
   }
   public String getClubIntro() {
      return clubIntro;
   }
   public void setClubIntro(String clubIntro) {
      this.clubIntro = clubIntro;
   }
   public String getClubAddress() {
      return clubAddress;
   }
   public void setClubAddress(String clubAddress) {
      this.clubAddress = clubAddress;
   }
   public String getClubSkillLevel() {
      return clubSkillLevel;
   }
   public void setClubSkillLevel(String clubSkillLevel) {
      this.clubSkillLevel = clubSkillLevel;
   }
   public String getClubDate() {
      return clubDate;
   }
   public void setClubDate(String clubDate) {
      this.clubDate = clubDate;
   }
   public String getClubTitleCode() {
      return clubTitleCode;
   }
   public void setClubTitleCode(String clubTitleCode) {
      this.clubTitleCode = clubTitleCode;
   }
   public String getCustId() {
      return custId;
   }
   public void setCustId(String custId) {
      this.custId = custId;
   }
   public String getClubstart() {
      return clubstart;
   }
   public void setClubstart(String clubstart) {
      this.clubstart = clubstart;
   }
   public String getClubend() {
      return clubend;
   }
   public void setClubend(String clubend) {
      this.clubend = clubend;
   }
   public String getClubsupplies() {
      return clubsupplies;
   }
   public void setClubsupplies(String clubsupplies) {
      this.clubsupplies = clubsupplies;
   }
   public String getClubamount() {
      return clubamount;
   }
   public void setClubamount(String clubamount) {
      this.clubamount = clubamount;
   }
   public String getClubmax() {
      return clubmax;
   }
   public void setClubmax(String clubmax) {
      this.clubmax = clubmax;
   }
   public String getCustid() {
      return custid;
   }
   public void setCustid(String custid) {
      this.custid = custid;
   }
   public String getClubpicture3() {
      return clubpicture3;
   }
   public void setClubpicture3(String clubpicture3) {
      this.clubpicture3 = clubpicture3;
   }
   public String getClubpicture1() {
      return clubpicture1;
   }
   public void setClubpicture1(String clubpicture1) {
      this.clubpicture1 = clubpicture1;
   }
   public String getClubpicture2() {
      return clubpicture2;
   }
   public void setClubpicture2(String clubpicture2) {
      this.clubpicture2 = clubpicture2;
   }
   public String getClubpicture4() {
      return clubpicture4;
   }
   public void setClubpicture4(String clubpicture4) {
      this.clubpicture4 = clubpicture4;
   }
   public String getClubGenre() {
      return clubGenre;
   }
   public void setClubGenre(String clubGenre) {
      this.clubGenre = clubGenre;
   }
   public String getLocation() {
      return location;
   }
   public void setLocation(String location) {
      this.location = location;
   }
}