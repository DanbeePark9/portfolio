package club.pjt.sql;


public class CustomerDTO {
   
   /*CUSTOMERINFO TABLE*/
   private String CustName;
   private String CustId;
   private String CustPass;
   private String CustEmail;
   private String CustPhone;
   private String CustGender;
   private String CustBirth;
   private String CustAddress;
   private String CustPhoto;
   
   private String LeadNick;
   private String LeadIntro;
   private String LeadAccount;
   private String LeadLocal;
   private String LeadBankName;
   private String LeadCertification;
   private String LeadGrveDate;
   private String LeadStopDate;
   
   
   
   public String getCustPhone() {
      return CustPhone;
   }
   public void setCustPhone(String custPhone) {
      CustPhone = custPhone;
   }
   public String getCustGender() {
      return CustGender;
   }
   public void setCustGender(String custGender) {
      CustGender = custGender;
   }
   public String getCustBirth() {
      return CustBirth;
   }
   public void setCustBirth(String custBirth) {
      CustBirth = custBirth;
   }
   public String getCustAddress() {
      return CustAddress;
   }
   public void setCustAddress(String custAddress) {
      CustAddress = custAddress;
   }
   public String getCustId() {
      return CustId;
   }
   public void setCustId(String custId) {
      CustId = custId;
   }
   public String getCustName() {
      return CustName;
   }
   public void setCustName(String custName) {
      CustName = custName;
   }
   public String getCustPass() {
      return CustPass;
   }
   public void setCustPass(String custPass) {
      CustPass = custPass;
   }
   public String getCustEmail() {
      return CustEmail;
   }
   public void setCustEmail(String custEmail) {
      CustEmail = custEmail;
   }
   public String getCustPhoto() {
      return CustPhoto;
   }
   public void setCustPhoto(String custPhoto) {
      CustPhoto = custPhoto;
   }
   public String getLeadNick() {
      return LeadNick;
   }
   public void setLeadNick(String leadNick) {
      LeadNick = leadNick;
   }
   public String getLeadIntro() {
      return LeadIntro;
   }
   public void setLeadIntro(String leadIntro) {
      LeadIntro = leadIntro;
   }
   public String getLeadAccount() {
      return LeadAccount;
   }
   public void setLeadAccount(String leadAccount) {
      LeadAccount = leadAccount;
   }
   public String getLeadLocal() {
      return LeadLocal;
   }
   public void setLeadLocal(String leadLocal) {
      LeadLocal = leadLocal;
   }

   public String getLeadBankName() {
      return LeadBankName;
   }
   public void setLeadBankName(String leadBankName) {
      LeadBankName = leadBankName;
   }
   public String getLeadCertification() {
      return LeadCertification;
   }
   public void setLeadCertification(String leadCertification) {
      LeadCertification = leadCertification;
   }
   public String getLeadGrveDate() {
      return LeadGrveDate;
   }
   public void setLeadGrveDate(String leadGrveDate) {
      LeadGrveDate = leadGrveDate;
   }
   public String getLeadStopDate() {
      return LeadStopDate;
   }
   public void setLeadStopDate(String leadStopDate) {
      LeadStopDate = leadStopDate;
   }
   
   
}