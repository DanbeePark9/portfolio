package club.pjt.sql;


import java.text.SimpleDateFormat;
import java.util.Date;
import club.pjt.check.pageNum;

public class ReviewDTO {

   private String rowNum;
   private String Review;
   private String ReviewDate;
   private String TotalStarLevel;
   private String StarLevel;
   private String StarLevel1;
   private String StarLevel2;
   private String StarLevel3;
   private String ClubTitle;
   private String CustId;
   private String CustName;
   private String ClubDate;
   private String CustPicture;
   private pageNum PageData;
   
   

   
   public String getRowNum() {
      return rowNum;
   }

   public void setRowNum(String rowNum) {
      this.rowNum = rowNum;
   }

   
   public String getCustName() {
   return CustName;
   }   

   public void setCustName(String custName) {
      CustName = custName;
   }
   
   public String getClubTitle() {
      return ClubTitle;
   }

   public void setClubTitle(String clubTitle) {
      ClubTitle = clubTitle;
   }

   public String getCustId() {
      return CustId;
   }

   public void setCustId(String custId) {
      CustId = custId;
   }

   public String getClubDate() {
      return ClubDate;
   }

   public void setClubDate(String clubDate) {
      ClubDate = clubDate;
   }

   public String getCustPicture() {
		return CustPicture;
	}

	public void setCustPicture(String custPicture) {
		CustPicture = custPicture;
	}

	public void setTotalStarLevel(String totalStarLevel) {
		TotalStarLevel = totalStarLevel;
	}

	public void setStarLevel(String starLevel) {
		StarLevel = starLevel;
	}

	public String getReview() {
      return Review;
   }

   public void setReview(String review) {
      Review = review;
   }

   public String getReviewDate() {
      return ReviewDate;
   }

   
   public String getTotalStarLevel() {
   return TotalStarLevel;
   }
   
   public void setTotalStarLevel(int totalStarLevel) {
      
      if(totalStarLevel==5) {
         this.TotalStarLevel = "★★★★★";
      }else if(totalStarLevel==4) {
         this.TotalStarLevel = "★★★★☆";
      }else if(totalStarLevel==3) {
         this.TotalStarLevel = "★★★☆☆";
      }else if(totalStarLevel==2) {
         this.TotalStarLevel = "★★☆☆☆";
      }else if(totalStarLevel==1) {
         this.TotalStarLevel = "★☆☆☆☆";
      }else {
         this.TotalStarLevel = "☆☆☆☆☆";
      }
      
   }

   // 날짜
   public void setReviewDate1(String ReviewDate) {
         this.ReviewDate = ReviewDate;
   }
   
   // 일전
   public void setReviewDate(String date1) {
      try {

         SimpleDateFormat sDate = new SimpleDateFormat("yyyy-MM-dd");
         String date2 = sDate.format(new Date());
         
         SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
           Date reviewDate  = format.parse(date1);
           Date SecondDate = format.parse(date2);
           
           long calDate = reviewDate.getTime() - SecondDate.getTime();
           long calDateDays = calDate / ( 24*60*60*1000); 
          
           calDateDays = Math.abs(calDateDays);
           ReviewDate = Integer.toString((int)calDateDays) + "일전";

           
      } catch (Exception e) {
      }

   }
   
    public String getStarLevel() {
       return StarLevel;
   }
   
   public void setStarLevel(String starLevel1,String starLevel2,String starLevel3) {
      int total = (Integer.parseInt(starLevel1) + Integer.parseInt(starLevel2) + Integer.parseInt(starLevel3))/3;
      
      if(total==5) {
         StarLevel = "★★★★★";
      }else if(total==4) {
         StarLevel = "☆★★★★";
      }else if(total==3) {
         StarLevel = "☆☆★★★";
      }else if(total==2) {
         StarLevel = "☆☆☆★★";
      }else if(total==1) {
         StarLevel = "☆☆☆☆★";
      }else {
         StarLevel = "☆☆☆☆";
      }
      
      
   }

   public String getStarLevel1() {
      return StarLevel1;
   }

   public void setStarLevel1(String starLevel1) {
      StarLevel1 = getStarLevel(starLevel1);
   }

   public String getStarLevel2() {
      return StarLevel2;
   }

   public void setStarLevel2(String starLevel2) {
      StarLevel2 = getStarLevel(starLevel2);
   }

   public String getStarLevel3() {
      return StarLevel3;
   }

   public void setStarLevel3(String starLevel3) {
      StarLevel3 = getStarLevel(starLevel3);
   }

   public void setPageData(pageNum pageData) {
      PageData = pageData;
   }
   public pageNum getPageData() {
      return PageData;
   }
   public String getStarLevel(String sStar) {
      int iStar = Integer.parseInt(sStar);

      if (iStar == 0) {
         return "☆☆☆☆☆";
      } else if (iStar == 1) {
         return "☆☆☆☆★";
      } else if (iStar == 2) {
         return "☆☆☆★★";
      } else if (iStar == 3) {
         return "☆☆★★★";
      } else if (iStar == 4) {
         return "☆★★★★";
      } else if (iStar == 5) {
         return "★★★★★";
      }

      return "☆☆☆☆☆";
   }


   
   

}