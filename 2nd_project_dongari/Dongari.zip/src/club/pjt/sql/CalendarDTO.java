package club.pjt.sql;

public class CalendarDTO {
   
   private String CustId;
   private String Month;
   private String title;
   private String year;
   private String startM;
   private String startH;
   private String endM;
   private String endH;
   private String day;
   private String idx1;
   
   public String getCustId() {
      return CustId;
   }
   public void setCustId(String custId) {
      CustId = custId;
   }
   
   public String getMonth() {
      return Month;
   }
   public void setMonth(String month) {
      Month = month;
   }
   public String getYear() {
      return year;
   }
   public void setYear(String year) {
      this.year = year;
   }
   public String getStartH() {
      return startH;
   }
   public void setStartH(String startH) {
      this.startH = startH;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getStartM() {
      return startM;
   }
   public void setStartM(String startM) {
      this.startM = startM;
   }
   public String getstartH() {
      return startH;
   }
   public void setstartH(String starH) {
      this.startH = starH;
   }
   public String getEndM() {
      return endM;
   }
   public void setEndM(String endM) {
      this.endM = endM;
   }
   public String getEndH() {
      return endH;
   }
   public void setEndH(String endH) {
      this.endH = endH;
   }
   public String getDay() {
      return day;
   }
   public void setDay(String day) {
      this.day = day;
   }
   public String getidx1() {
      return idx1;
   }
   public void setidx1(String idx1) {
      this.idx1 = idx1;
   }

   
}