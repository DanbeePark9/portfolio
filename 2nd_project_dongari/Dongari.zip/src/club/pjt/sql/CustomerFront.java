package club.pjt.sql;

public class CustomerFront {

   private String CustName;
   private String CustId;
   private String CustEmail;
   private String CustPhone;
   private String CustGender;
   private String CustBirth;
   
   public String getCustName() {
      return CustName;
   }
   public void setCustName(String custName) {
      CustName = custName;
   }
   public String getCustId() {
      return CustId;
   }
   public void setCustId(String custId) {
      CustId = custId;
   }
   public String getCustEmail() {
      return CustEmail;
   }
   public void setCustEmail(String custEmail) {
      CustEmail = custEmail;
   }
   public String getCustPhone() {
      return CustPhone;
   }
   public void setCustPhone(String custPhone) {
      CustPhone = custPhone.substring(0,3) + "-" +custPhone.substring(3,7)  + "-" +custPhone.substring(7,11)  ;
   }
   public String getCustGender() {
      return CustGender;
   }
   public void setCustGender(String custGender) {
        if( custGender.equals("2") ){
           CustGender = "여자";
        }else if( custGender.equals("1") ){
           CustGender = "남자";
        }else {
           CustGender = custGender;
        }
   }
   public String getCustBirth() {
      return CustBirth;
   }
   public void setCustBirth(String custBirth) {
      CustBirth = custBirth;
   }
}