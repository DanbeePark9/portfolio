package club.pjt.sql;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import club.pjt.check.ClubGenre;
import club.pjt.check.LeadLocal;


public class DongariSQL {
     Connection CN;
     Statement ST; 
     PreparedStatement PST;
     CallableStatement CST; 
     ResultSet RS; 
     String msg,a,b;
     DongariDTO DongDTO;
     ReviewDTO ReviewDTO;
     
     public DongariSQL() {
         CN = DB.getConnection();
     }
     
     //0922변경===================================dinsert1.do가 호출
     public void DongInsert( String ID,  DongariDTO DongDTO ) {
        try {
           //클럽코드를 생성하기 위한 생성자
          String CurrentClubCode = DongDTO.getClubCode(); //현재 클럽 코드 SPF
          DongariSQL DongSQL = new DongariSQL();
          ClubGenre CG = new ClubGenre();
          LeadLocal LL = new LeadLocal();
          
          a = "INSERT INTO TLEADERCLUBLIST (CUSTID, CLUBCODE, CREATEDATE, CLOSEDATE, CLUBGENRE, CLUBINTRO, REPICTURE, LEADLOCAL)";
          b = " VALUES(?, ?, TO_CHAR(SYSDATE,'YY/MM/DD'), TO_DATE('00-01-01','YY/MM/DD'),?,?,?,?)";
          msg = a+b;
          PST = CN.prepareStatement(msg);
          PST.setString(1, ID);
          PST.setString(2, DongDTO.getClubCode());
          PST.setString(3, DongDTO.getClubGenre()); //축구가 A로 바뀌도록
          PST.setString(4, DongDTO.getClubIntro());
          PST.setString(5, DongDTO.getFile());
          PST.setString(6, DongDTO.getLeadLocal()); //서울이 00으로 바뀌도록
          PST.executeUpdate(); 
        }catch (Exception e) {System.out.println("[DongInsert] ERROR "+ e);}
     }
     
     
     public String ClubCodeSelect(String CurrentClubCode) {
    	 String ClubCode="";
    	 try {
				msg="SELECT COUNT(*) AS CNT FROM TLEADERCLUBLIST WHERE CLUBCODE LIKE '%"+CurrentClubCode+"%'";
				ST = CN.createStatement();
        RS = ST.executeQuery(msg);
        RS.next();
        
        String CNT = RS.getString("CNT");//현재 존재하는 동아리 1
        int Num = Integer.parseInt(CNT)+1; //2로 만듬
        
        //10보다 작은 경우 앞에 "0" 붙여주기
        if(Num < 10){
        	String addZero = "0" + Num;
        	ClubCode = CurrentClubCode + addZero; //SPF02
        } else {
        	ClubCode = CurrentClubCode + Num;
        }
			} catch (Exception e) {System.out.println("[ClubCodeSelect] ERROR "+ e);}
    	 return ClubCode;
     }
     
     
     
     public DongariDTO DongPopular() {
       DongDTO = new DongariDTO();
       try {
          msg=" SELECT DISTINCT TCI.CustID, TCI.ClubCode, TCI.ClubTitle, TLCL.rePicture, TCI.CLUBTITLE, TLCL.CLUBGENRE, TO_CHAR(TCI.CLUBDATE,'YY/MM/DD')  AS CLUBDATE,"+
              " TCI.CLUBSTART, TCI.CLUBLOCATION, TCI.CLUBAMOUNT, TLCL.CLUBINTRO, TCI.CLUBSKILLLEVEL " + 
              " FROM TClubInfo TCI, TLEADERCLUBLIST TLCL " + 
              " WHERE AVGSTARLEVEL > 1 ";
          ST = CN.createStatement();
          RS = ST.executeQuery(msg);
          RS.next();
          DongDTO.setCustId(RS.getString("CustID"));
          DongDTO.setClubCode(RS.getString("ClubCode"));
          DongDTO.setClubTitle(RS.getString("ClubTitle"));
          DongDTO.setClubDate(RS.getString("ClubDate"));
          DongDTO.setRePicture(RS.getString("RePicture"));
          DongDTO.setClubGenre(RS.getString("CLUBGENRE"));
          DongDTO.setClubDate(RS.getString("CLUBDATE"));
          DongDTO.setClubStart(RS.getString("CLUBSTART"));
          DongDTO.setClubLocation(RS.getString("CLUBLOCATION"));
          DongDTO.setClubAmount(RS.getString("CLUBAMOUNT"));
          DongDTO.setClubIntro(RS.getString("CLUBINTRO"));
          DongDTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
        } catch (Exception e) {System.out.println("[DongPopular] 에러 : " + e);}
        return DongDTO;
    }
    
    public DongariDTO DongNew() {
       DongDTO = new DongariDTO();
       try {
              msg = "SELECT ROWNUM, X.* \r\n" + 
                    "  FROM ( \r\n" + 
                    "  SELECT TLCL.clubIntro,TCI.CustID, TCI.ClubCode,  TCI.clubLocation, TCI.clubGenre, TLCL.rePicture, "+
                    "          TCI.clubTitle, TCI.clubSkillLevel, TCI.clubAmount, TO_CHAR(TCI.ClubDate,'YY/MM/DD') AS CLUBDATE \r\n" + 
                    "  FROM TLeaderClubList TLCL, TCLUBINFO TCI\r\n" + 
                    "  WHERE CREATEDATE < SYSDATE\r\n" + 
                    "  ORDER BY CREATEDATE) X \r\n" + 
                    "  WHERE ROWNUM=1";
           ST = CN.createStatement();
           RS = ST.executeQuery(msg);
           RS.next();
           DongDTO.setClubIntro(RS.getString("ClubIntro"));
           DongDTO.setCustId(RS.getString("CustId"));
           DongDTO.setClubCode(RS.getString("ClubCode"));
           DongDTO.setClubLocation(RS.getString("ClubLocation"));
           DongDTO.setClubGenre(RS.getString("ClubGenre"));
           DongDTO.setRePicture(RS.getString("Repicture"));
           DongDTO.setClubTitle(RS.getString("ClubTitle"));
           DongDTO.setClubSkillLevel(RS.getString("ClubSkillLevel"));
           DongDTO.setClubAmount(RS.getString("ClubAmount"));
           DongDTO.setClubDate(RS.getString("ClubDate"));
        } catch (Exception e) {System.out.println("[DongNew] 에러 : " + e);}
       return DongDTO;
    }
    
     
     public DongariDTO DongSelect(String ClubCode) {
    	 DongDTO = new DongariDTO();
    	 try {
	    		 msg = "SELECT * FROM TCLUBINFO WHERE CLUBCODE='"+ClubCode+"'";
	    		 ST = CN.createStatement();
	   	     RS = ST.executeQuery(msg);
	   	     RS.next();
	   	     DongDTO.setCustId(RS.getString("CustId"));
	   	     DongDTO.setClubCode(RS.getString("ClubCode"));
	   	     DongDTO.setClubDate(RS.getString("clubDate"));
	   	     DongDTO.setClubTitle(RS.getString("clubTitle"));
	   	     DongDTO.setClubStart(RS.getString("clubStart"));
	   	     DongDTO.setClubEnd(RS.getString("clubEnd"));
	   	     DongDTO.setClubPicture1(RS.getString("clubPicture1"));
	   	     DongDTO.setClubPicture2(RS.getString("clubPicture2"));
	   	     DongDTO.setClubPicture3(RS.getString("clubPicture3"));
	   	     DongDTO.setClubPicture4(RS.getString("clubPicture4"));
	   	     DongDTO.setClubMax(RS.getString("clubMax"));
	   	     DongDTO.setClubCurrentNum(RS.getString("clubCurrentNum"));
	   	     DongDTO.setClubLocation(RS.getString("clubLocation"));
	   	     DongDTO.setClubAddress(RS.getString("clubAddress"));
	   	     DongDTO.setClubSupplies(RS.getString("clubSupplies"));
	   	     DongDTO.setAvgStarLevel(RS.getString("avgStarLevel"));
	   	     DongDTO.setClubAmount(RS.getString("clubAmount"));
	   	     DongDTO.setClubSkillLevel(RS.getString("clubSkillLevel"));
	   	     DongDTO.setClubGenre(RS.getString("clubGenre"));
	   	     DongDTO.setClubIntro(RS.getString("clubIntro"));
    	 }catch (Exception e) {System.out.println("[DongSelect] 에러 : " + e);}
    	 return DongDTO;
     }
     
     
     public ArrayList<ReviewDTO> DongReview(String ClubCode) {
    	 ArrayList<ReviewDTO> list = new ArrayList<ReviewDTO>();
    	 try {
    		 msg = "SELECT DISTINCT TCI.Review, TCI.ReviewDate, TCI.StarLevel1, TCI.StarLevel2, TCI.StarLevel3 , CI.CustName " + 
    		 			 " FROM TStudentCourseInfo TCI, Customerinfo CI " + 
    		 			 " WHERE CLUBCODE = ? " + 
    		 			 " AND TCI.CUSTID = CI.CUSTID";
    		 PST = CN.prepareStatement(msg);
    		 RS = PST.executeQuery();
    		 while(RS.next()==true) {
	    		 ReviewDTO = new ReviewDTO();
	    		 ReviewDTO.setReview(RS.getString("Review"));
	    		 ReviewDTO.setReviewDate(RS.getString("ReviewDate"));
	    		 ReviewDTO.setStarLevel1(RS.getString("StarLevel1"));
	    		 ReviewDTO.setStarLevel2(RS.getString("StarLevel2"));
	    		 ReviewDTO.setStarLevel3(RS.getString("StarLevel3"));
	    		 ReviewDTO.setCustId(RS.getString("CustId"));
	    		 list.add(ReviewDTO);
    		 }
			} catch (Exception e) {System.out.println("[DongReview] 에러 : " + e);}
    	 return list;
     }
     
     
     
     
     
     public ArrayList<DongariDTO> DongListSelect(String ClubCode, int start, int end){
    	 ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
    	 try {
				msg="  SELECT * FROM (SELECT ROWNUM RN, X.* FROM(\r\n" + 
						"    SELECT TLC.CUSTID, TLC.CLUBCODE, \r\n" + 
						"      TO_CHAR( TLC.CREATEDATE,'YY/MM/DD') AS CREATEDATE,\r\n" + 
						"      TO_CHAR( TLC.CLOSEDATE,'YY/MM/DD')  AS CLOSEDATE,\r\n" + 
						"      TO_CHAR( TCI.CLUBDATE,'YY/MM/DD')   AS CLUBDATE,\r\n" + 
						"      TO_CHAR( TCI.CLUBSTART,'HH24:MI')   AS CLUBSTART,\r\n" + 
						"      TO_CHAR( TCI.CLUBEND,'HH24:MI')     AS CLUBEND,\r\n" + 
						"      TLC.CLUBGENRE, TLC.CLUBINTRO, TLC.REPICTURE, TCI.CLUBTITLE,\r\n" + 
						"      TCI.CLUBPICTURE1, TCI.CLUBPICTURE2, TCI.CLUBPICTURE3, TCI.CLUBPICTURE4,\r\n" + 
						"      TCI.CLUBMAX, TCI.CLUBCURRENTNUM,\r\n" + 
						"      TCI.CLUBLOCATION,TCI.CLUBADDRESS,TCI.CLUBSUPPLIES,\r\n" + 
						"      TCI.CLUBAMOUNT,TCI.AVGSTARLEVEL,TCI.CLUBSKILLLEVEL\r\n" + 
						"      FROM TLEADERCLUBLIST TLC, TCLUBINFO TCI\r\n" + 
						"      WHERE TLC.CLUBCODE = TCI.CLUBCODE\r\n" + 
						"      AND TLC.CUSTID   = TCI.CUSTID\r\n" + 
						"      AND TCI.CLUBCODE LIKE '%"+ClubCode+"%'" + 
						"      ORDER BY TCI.CLUBDATE) X)  WHERE RN BETWEEN " + start + " AND " + end;
				PST = CN.prepareStatement(msg);
   		  RS = PST.executeQuery();
   		  
   		 while(RS.next()==true) {
    		 DongDTO = new DongariDTO();
    		 //페이징
    		 DongDTO.setRn(RS.getInt("RN"));
    		 //TLeaderClubList
    		 DongDTO.setCustId(RS.getString("CustId"));
    		 DongDTO.setClubCode(RS.getString("ClubCode"));
    		 DongDTO.setCreateDate(RS.getString("createDate"));
    		 DongDTO.setClubGenre(RS.getString("ClubGenre"));
    		 DongDTO.setClubIntro(RS.getString("ClubIntro"));
    		 DongDTO.setRePicture(RS.getString("RePicture"));
    		 //TCLUBINFO
    		 DongDTO.setClubDate(RS.getString("ClubDate"));
    		 DongDTO.setClubTitle(RS.getString("ClubTitle"));
    		 DongDTO.setClubStart(RS.getString("ClubStart"));
    		 DongDTO.setClubEnd(RS.getString("ClubEnd"));
    		 DongDTO.setClubPicture1(RS.getString("clubPicture1"));
   	     DongDTO.setClubPicture2(RS.getString("clubPicture2"));
   	     DongDTO.setClubPicture3(RS.getString("clubPicture3"));
   	     DongDTO.setClubPicture4(RS.getString("clubPicture4"));
   	     DongDTO.setClubMax(RS.getString("clubMax"));
  	     DongDTO.setClubCurrentNum(RS.getString("clubCurrentNum"));
  	     DongDTO.setClubLocation(RS.getString("clubLocation"));
  	     DongDTO.setClubAddress(RS.getString("clubAddress"));
  	     DongDTO.setClubSupplies(RS.getString("clubSupplies"));
  	     DongDTO.setClubAmount(RS.getString("ClubAmount"));
  	     DongDTO.setAvgStarLevel(RS.getString("avgStarLevel"));
  	     DongDTO.setClubSkillLevel(RS.getString("clubSkillLevel"));
    		 list.add(DongDTO);
  		 }
			} catch (Exception e) {System.out.println("[DongListSelect] error : " + e);}
    	 return list;
     }
     
     
     public int RecordTotal(String ClubCode) {
    	 int rcnt=0;
    	 try {
    		 msg="SELECT COUNT(*) as CNT FROM TCLUBINFO WHERE CLUBCODE LIKE '%"+ClubCode+"%'";
    		 ST = CN.createStatement();
         RS = ST.executeQuery(msg);
         RS.next();
         
         rcnt = RS.getInt("CNT");
    	 } catch (Exception e) {System.out.println("[RecordTotal] 에러 : " + e);}
    	 return rcnt;
     }
     
     public String ClubGenreSelect(String ClubCode) {
    	 String ClubGenre="";
    	 try {
    		 msg="SELECT CLUBGENRE FROM TLEADERCLUBLIST WHERE CLUBCODE LIKE '%"+ClubCode+"%'";
    		 ST = CN.createStatement();
         RS = ST.executeQuery(msg);
         RS.next();
         ClubGenre=RS.getString("ClubGenre");
			} catch (Exception e) {System.out.println("[ClubGenreSelect] 에러 : " + e);}
    	 return ClubGenre;
     }
     
     
     
     //=============================================================================================================

     // 동아리 정보에 출력 될 리더 정보
     public DongariLeaderDTO DongLeadDetail( DongariDTO DongDTO ) {
        DongariLeaderDTO DongLeadDTO = new DongariLeaderDTO();
        try {
                msg=" SELECT DISTINCT TCI.CUSTID, CI.LEADNAME, CI.CUSTPICTURE, TCI.CLUBINTRO , TEX.* , TLI.*\r\n" + 
                      "  FROM TCLUBINFO TCI, TCustomerInfo  CI, TEXPERTISE TEX, TLICENSE TLI\r\n" + 
                      " WHERE TEX.CUSTID  = TCI.CUSTID\r\n" + 
                      "   AND CI.CUSTID  = TCI.CUSTID\r\n" + 
                      "   AND TCI.CUSTID = '"+DongDTO.getCustId()+"'\r\n" + 
                      "   AND TCI.CLUBTITLE='"+DongDTO.getClubTitle()+"'";
              ST = CN.createStatement();
              RS = ST.executeQuery(msg);
              RS.next();
             
              DongLeadDTO.setCustid(RS.getString("CUSTID"));
              DongLeadDTO.setLeadname(RS.getString("LEADNAME"));
              DongLeadDTO.setCustpicture(RS.getString("CUSTPICTURE"));
              DongLeadDTO.setClubintro(RS.getString("CLUBINTRO"));
              
              DongLeadDTO.setExpertise1(RS.getString("EXPERTISE1"));
              DongLeadDTO.setExpertStart1(RS.getString("EXPERTSTART1"));
              DongLeadDTO.setExpertEnd1(RS.getString("EXPERTEND1"));
              DongLeadDTO.setExpertise2(RS.getString("EXPERTISE2"));
              DongLeadDTO.setExpertStart2(RS.getString("EXPERTSTART2"));
              DongLeadDTO.setExpertEnd2(RS.getString("EXPERTEND2"));
              DongLeadDTO.setExpertise3(RS.getString("EXPERTISE3"));
              DongLeadDTO.setExpertStart3(RS.getString("EXPERTSTART3"));
              DongLeadDTO.setExpertEnd3(RS.getString("EXPERTEND3"));
              DongLeadDTO.setExpertise4(RS.getString("EXPERTISE4"));
              DongLeadDTO.setExpertStart4(RS.getString("EXPERTSTART4"));
              DongLeadDTO.setExpertEnd4(RS.getString("EXPERTEND4"));
              DongLeadDTO.setExpertise5(RS.getString("EXPERTISE5"));
              DongLeadDTO.setExpertStart5(RS.getString("EXPERTSTART5"));
              DongLeadDTO.setExpertEnd5(RS.getString("EXPERTEND5"));
              
              DongLeadDTO.setLicense1(RS.getString("LICENSE1"));
              DongLeadDTO.setLicense2(RS.getString("LICENSE2"));
              DongLeadDTO.setLicense3(RS.getString("LICENSE3"));
              DongLeadDTO.setLicense4(RS.getString("LICENSE4"));
              DongLeadDTO.setLicense5(RS.getString("LICENSE5"));
         } catch (Exception e) {System.out.println("DongLeadDetail 에러 : " + e);}
        
         return DongLeadDTO;
     }
     
     
     // 동아리 정보 상세 페이지
     public ArrayList<DongariDTO> DongDetail( DongariDTO DongDTO1 ) {
         ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
         try {
           msg =" SELECT DISTINCT TCI.CUSTID ,TCI.CLUBCODE ,TCI.CLUBTITLE ,TCI.CLUBPICTURE1 ,TCI.CLUBPICTURE2 ,TCI.CLUBPICTURE3 ,TCI.CLUBPICTURE4 ,\r\n" + 
                 "        TCI.CLUBMAX ,TCI.CLUBCURRENTNUM ,TCI.CLUBLOCATION ,TCI.CLUBADDRESS ,TCI.CLUBSUPPLIES ,TCI.CLUBAMOUNT ,\r\n" + 
                 "        TCI.AVGSTARLEVEL ,TCI.CLUBSKILLLEVEL ,TCI.CLUBGENRE ,TCI.CLUBINTRO , \r\n" + 
                 "        TO_CHAR( CLUBDATE,'YY/MM/DD') AS CLUBDATE, \r\n" + 
                 "        TO_CHAR( CLUBSTART,'HH24:MI') AS CLUBSTART,\r\n" + 
                 "        TO_CHAR( CLUBEND ,'HH24:MI' ) AS CLUBEND,TLC.REPICTURE \r\n" + 
                 "  FROM TCLUBINFO TCI, TLEADERCLUBLIST TLC\r\n" + 
                 " WHERE CLUBTITLE IN (SELECT CLUBTITLE \r\n" + 
                 "                       FROM TCLUBINFO\r\n" + 
                 "                      WHERE CLUBCODE = '"+ DongDTO1.getClubCode() +"'\r\n" + 
                 "                        AND TO_CHAR(CLUBDATE,'YY/MM/DD') = '"+ DongDTO1.getClubDate() +"')";
            ST = CN.createStatement();
            RS = ST.executeQuery(msg);
            while( RS.next()==true ) {
               DongariDTO DongDTO = new DongariDTO();
                DongDTO.setCustId(RS.getString("CUSTID"));
                DongDTO.setClubCode(RS.getString("ClubCode"));
                DongDTO.setClubDate(RS.getString("ClubDate"));
                DongDTO.setClubTitle(RS.getString("ClubTitle"));
                DongDTO.setClubStart(RS.getString("ClubStart"));
                DongDTO.setClubEnd(RS.getString("ClubEnd"));
                DongDTO.setRePicture(RS.getString("REPICTURE"));
                DongDTO.setClubPicture1(RS.getString("ClubPicture1"));
                DongDTO.setClubPicture2(RS.getString("ClubPicture2"));
                DongDTO.setClubPicture3(RS.getString("ClubPicture3"));
                DongDTO.setClubPicture4(RS.getString("ClubPicture4"));
                DongDTO.setClubMax(RS.getString("CLUBMAX"));
                DongDTO.setClubCurrentNum(RS.getString("CLUBCURRENTNUM"));
                DongDTO.setClubLocation(RS.getString("CLUBLOCATION"));
                DongDTO.setClubAddress(RS.getString("CLUBADDRESS"));
                DongDTO.setClubSupplies(RS.getString("CLUBSUPPLIES"));
                DongDTO.setClubAmount(RS.getString("CLUBAMOUNT"));
                DongDTO.setAvgStarLevel(RS.getString("AVGSTARLEVEL"));
                DongDTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
                DongDTO.setClubGenre(RS.getString("CLUBGENRE"));
                DongDTO.setClubIntro(RS.getString("CLUBINTRO"));
                list.add(DongDTO);
            }
          } catch (Exception e) {System.out.println("DongDetail 에러 : " + e);}
          return list;
      }
     
     
     // 동아리 정보 상세 페이지
     public ArrayList<DongariDTO> DongDetail1( DongariDTO DongDTO1 ) {
         ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
         if( DongDTO1.getClubDate() == null || DongDTO1.getClubDate() =="") {
            DongDTO1.setClubDate("");
         }
         try {
            
        	 msg = "SELECT DISTINCT TCI.CUSTID ,TCI.CLUBCODE ,TCI.CLUBTITLE ,TCI.CLUBPICTURE1 ,TCI.CLUBPICTURE2 ,TCI.CLUBPICTURE3 ,TCI.CLUBPICTURE4 ,\r\n" + 
               "        TCI.CLUBMAX ,TCI.CLUBCURRENTNUM ,TCI.CLUBLOCATION ,TCI.CLUBADDRESS ,TCI.CLUBSUPPLIES ,TCI.CLUBAMOUNT ,\r\n" + 
               "        TCI.AVGSTARLEVEL ,TCI.CLUBSKILLLEVEL ,TCI.CLUBGENRE ,TCI.CLUBINTRO , \r\n" + 
               "        TO_CHAR( CLUBDATE,'YY/MM/DD') AS CLUBDATE, \r\n" + 
               "        TO_CHAR( CLUBSTART,'HH24:MI') AS CLUBSTART,\r\n" + 
               "        TO_CHAR( CLUBEND ,'HH24:MI' ) AS CLUBEND, TLC.REPICTURE \r\n" + 
               "  FROM TCLUBINFO TCI, TLEADERCLUBLIST TLC\r\n" + 
               " WHERE TLC.CLUBCODE = TCI.CLUBCODE\r\n" + 
               "   AND CLUBTITLE IN (SELECT CLUBTITLE \r\n" + 
               "                       FROM TCLUBINFO\r\n" + 
               "                      WHERE CLUBCODE LIKE '"+DongDTO1.getClubCode()+"'\r\n" + 
               "                        AND TO_CHAR(CLUBDATE,'YY/MM/DD') LIKE '%"+DongDTO1.getClubDate()+"%')";
            ST = CN.createStatement();
            RS = ST.executeQuery(msg);
            while( RS.next()==true ) {
               DongariDTO DongDTO = new DongariDTO();
                DongDTO.setCustId(RS.getString("CUSTID"));
                DongDTO.setClubCode(RS.getString("ClubCode"));
                DongDTO.setClubDate(RS.getString("ClubDate"));
                DongDTO.setClubTitle(RS.getString("ClubTitle"));
                DongDTO.setClubStart(RS.getString("ClubStart"));
                DongDTO.setClubEnd(RS.getString("ClubEnd"));
                DongDTO.setRePicture(RS.getString("REPICTURE"));
                DongDTO.setClubPicture1(RS.getString("ClubPicture1"));
                DongDTO.setClubPicture2(RS.getString("ClubPicture2"));
                DongDTO.setClubPicture3(RS.getString("ClubPicture3"));
                DongDTO.setClubPicture4(RS.getString("ClubPicture4"));
                DongDTO.setClubMax(RS.getString("CLUBMAX"));
                DongDTO.setClubCurrentNum(RS.getString("CLUBCURRENTNUM"));
                DongDTO.setClubLocation(RS.getString("CLUBLOCATION"));
                DongDTO.setClubAddress(RS.getString("CLUBADDRESS"));
                DongDTO.setClubSupplies(RS.getString("CLUBSUPPLIES"));
                DongDTO.setClubAmount(RS.getString("CLUBAMOUNT"));
                DongDTO.setAvgStarLevel(RS.getString("AVGSTARLEVEL"));
                DongDTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
                DongDTO.setClubGenre(RS.getString("CLUBGENRE"));
                DongDTO.setClubIntro(RS.getString("CLUBINTRO"));
                list.add(DongDTO);
            }
          } catch (Exception e) {System.out.println("DongDetail1 에러 : " + e);}
          return list;
      }
     // 동아리 정보 상세 페이지
     public ArrayList<DongariDTO> DongDetail2( DongariDTO DongDTO1 ) {
         ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
         if( DongDTO1.getClubDate() == null || DongDTO1.getClubDate() =="") {
            DongDTO1.setClubDate("");
         }
         try {
            
           msg ="SELECT DISTINCT TCI.CUSTID ,TCI.CLUBCODE ,TCI.CLUBTITLE ,TCI.CLUBPICTURE1 ,TCI.CLUBPICTURE2 ,TCI.CLUBPICTURE3 ,TCI.CLUBPICTURE4 ,\r\n" + 
               "        TCI.CLUBMAX ,TCI.CLUBCURRENTNUM ,TCI.CLUBLOCATION ,TCI.CLUBADDRESS ,TCI.CLUBSUPPLIES ,TCI.CLUBAMOUNT ,\r\n" + 
               "        TCI.AVGSTARLEVEL ,TCI.CLUBSKILLLEVEL ,TCI.CLUBGENRE ,TCI.CLUBINTRO , \r\n" + 
               "        TO_CHAR( CLUBDATE,'YY/MM/DD') AS CLUBDATE, \r\n" + 
               "        TO_CHAR( CLUBSTART,'HH24:MI') AS CLUBSTART,\r\n" + 
               "        TO_CHAR( CLUBEND ,'HH24:MI' ) AS CLUBEND, TLC.REPICTURE \r\n" + 
               "  FROM TCLUBINFO TCI, TLEADERCLUBLIST TLC\r\n" + 
               " WHERE TLC.CLUBCODE = TCI.CLUBCODE\r\n" + 
               "   AND CLUBTITLE IN (SELECT CLUBTITLE \r\n" + 
               "                       FROM TCLUBINFO\r\n" + 
               "                      WHERE CLUBCODE LIKE '"+DongDTO1.getClubCode()+"'\r\n" + 
               "                        AND TO_CHAR(CLUBDATE,'YY/MM/DD') LIKE '%"+DongDTO1.getClubTitleCode()+"%')";
            ST = CN.createStatement();
            RS = ST.executeQuery(msg);
            while( RS.next()==true ) {
               DongariDTO DongDTO = new DongariDTO();
                DongDTO.setCustId(RS.getString("CUSTID"));
                DongDTO.setClubCode(RS.getString("ClubCode"));
                DongDTO.setClubDate(RS.getString("ClubDate"));
                DongDTO.setClubTitle(RS.getString("ClubTitle"));
                DongDTO.setClubStart(RS.getString("ClubStart"));
                DongDTO.setClubEnd(RS.getString("ClubEnd"));
                DongDTO.setRePicture(RS.getString("REPICTURE"));
                DongDTO.setClubPicture1(RS.getString("ClubPicture1"));
                DongDTO.setClubPicture2(RS.getString("ClubPicture2"));
                DongDTO.setClubPicture3(RS.getString("ClubPicture3"));
                DongDTO.setClubPicture4(RS.getString("ClubPicture4"));
                DongDTO.setClubMax(RS.getString("CLUBMAX"));
                DongDTO.setClubCurrentNum(RS.getString("CLUBCURRENTNUM"));
                DongDTO.setClubLocation(RS.getString("CLUBLOCATION"));
                DongDTO.setClubAddress(RS.getString("CLUBADDRESS"));
                DongDTO.setClubSupplies(RS.getString("CLUBSUPPLIES"));
                DongDTO.setClubAmount(RS.getString("CLUBAMOUNT"));
                DongDTO.setAvgStarLevel(RS.getString("AVGSTARLEVEL"));
                DongDTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
                DongDTO.setClubGenre(RS.getString("CLUBGENRE"));
                DongDTO.setClubIntro(RS.getString("CLUBINTRO"));
                list.add(DongDTO);
            }
          } catch (Exception e) {System.out.println("DongDetail2 에러 : " + e);}
          return list;
      }
     // 수업 일정 insert
     public void DongClubInsert( DongariClubDTO DTO ) {
         try {
            msg = "INSERT INTO TClubInfo( CUSTID, CLUBCODE, CLUBDATE, CLUBTITLE, CLUBSTART, CLUBEND, CLUBPICTURE1, CLUBPICTURE2, CLUBPICTURE3, CLUBPICTURE4, CLUBMAX, CLUBCURRENTNUM, CLUBLOCATION, CLUBADDRESS, CLUBSUPPLIES, CLUBAMOUNT, AVGSTARLEVEL, CLUBSKILLLEVEL, CLUBGENRE, CLUBINTRO, CLUBTITLECODE ) \r\n" + 
                  "               VALUES( '"+DTO.getCustid()+"',\r\n" + 
                  "                       '"+DTO.getClubcode()+"',\r\n" + 
                  "                       TO_DATE('"+DTO.getClubDate()+"','MM/DD/YYYY'),\r\n" + 
                  "                       '"+DTO.getClubTitle()+"',\r\n" + 
                  "                       TO_DATE('"+DTO.getClubstart()+"','HH24:MI'),\r\n" + 
                  "                       TO_DATE('"+DTO.getClubend()+"','HH24:MI'),\r\n" + 
                  "                       '"+DTO.getClubpicture1()+"',\r\n" + 
                  "                       '"+DTO.getClubpicture2()+"',\r\n" + 
                  "                       '"+DTO.getClubpicture3()+"',\r\n" + 
                  "                       '"+DTO.getClubpicture4()+"',\r\n" + 
                  "                       '"+DTO.getClubmax()+"',\r\n" + 
                  "                       '0',\r\n" + 
                  "                       '"+DTO.getLocation()+"',\r\n" + 
                  "                       '"+DTO.getClubAddress()+"',\r\n" + 
                  "                       '"+DTO.getClubsupplies()+"',\r\n" + 
                  "                       '"+DTO.getClubamount()+"',\r\n" + 
                  "                       '0',\r\n" + 
                  "                       '"+DTO.getClubSkillLevel()+"',\r\n" + 
                  "                       '"+DTO.getClubGenre()+"',\r\n" + 
                  "                       '"+DTO.getClubIntro()+"',\r\n" + 
                  "                       '"+DTO.getClubTitleCode()+"')";
            System.out.println("[수업 개설] DongClubInsert");
            System.out.println(msg);
            PST = CN.prepareStatement(msg);
            PST.executeUpdate(); 
            System.out.println("성공");
         }catch (Exception e) {System.out.println("DongInsert ERROR "+ e);}
      }
     
     
     
     // 같은 수업의 이름이 존재하는지 확인
     public String ClubTitleCode( String ClubTitle ) {
      try {
         msg = "SELECT COUNT(CLUBTITLECODE) AS CNT FROM  TClubInfo WHERE CLUBTITLE LIKE '"+ClubTitle+"'";
           ST = CN.createStatement();
           RS = ST.executeQuery(msg);
           RS.next();
           String sCnt = RS.getString("CNT");
         int iCnt = Integer.parseInt(sCnt);
         if( iCnt == 0 ) {
            return "1";
         }else {
            iCnt++;
            return Integer.toString(iCnt);
         }
      }catch (Exception e) {
         System.out.println( "ClubTitleCode ERROR ");
      }
      return null;
   }
  
     //======================================================0924

     // CLUB UPDATE SELECT
     public DongariDTO LeadClubUpdateSelect( String ID, String clubCode, String clubTitleCode, String clubDate, String clubStart ) {
         DongariDTO DTO = new DongariDTO();
           try {
              msg = "SELECT CLUBTITLE, CLUBINTRO, CLUBADDRESS, CLUBSKILLLEVEL,\r\n" + 
                    "       CLUBAMOUNT, CLUBMAX, CLUBSUPPLIES, \r\n" + 
                    "       CLUBPICTURE1, CLUBPICTURE2, CLUBPICTURE3, CLUBPICTURE4,\r\n" + 
                    "       TO_CHAR(CLUBSTART, 'HH24:MI') AS CLUBSTART, TO_CHAR(CLUBEND, 'HH24:MI') AS CLUBEND, "+
                    "       TO_CHAR(CLUBDATE, 'YYYY / MM / DD') AS CLUBDATE"+
                    "  FROM TCLUBINFO \r\n" + 
                    " WHERE CLUBCODE LIKE '"+clubCode+"'\r\n" + 
                    "   AND TO_CHAR(CLUBDATE, 'YY/MM/DD') LIKE '"+clubDate+"'\r\n" + 
                    "   AND TO_CHAR(CLUBSTART, 'HH24:MI') LIKE '"+clubStart+"'\r\n" + 
                    "   AND CLUBTITLECODE LIKE '"+clubTitleCode+"'\r\n" + 
                    "   AND CUSTID LIKE '"+ID+"'"; 
              System.out.println(msg);
            ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            RS = ST.executeQuery(msg);
            RS.last();
            if( RS.getRow()==0) {  return null; }
            RS.beforeFirst();
            RS.next();
            DTO.setClubTitle(RS.getString("CLUBTITLE"));
            DTO.setClubIntro(RS.getString("CLUBINTRO"));
            DTO.setClubAddress(RS.getString("CLUBADDRESS"));
            DTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
            DTO.setClubAmount(RS.getString("CLUBAMOUNT"));
            DTO.setClubMax(RS.getString("CLUBMAX"));
            DTO.setClubStart(RS.getString("CLUBSTART"));
            DTO.setClubEnd(RS.getString("CLUBEND"));
            DTO.setClubDate(RS.getString("CLUBDATE"));
            DTO.setClubSupplies(RS.getString("CLUBSUPPLIES"));
            DTO.setClubPicture1(RS.getString("CLUBPICTURE1"));
            DTO.setClubPicture2(RS.getString("CLUBPICTURE1"));
            DTO.setClubPicture3(RS.getString("CLUBPICTURE1"));
            DTO.setClubPicture4(RS.getString("CLUBPICTURE1"));
            
           } catch (SQLException e) {System.out.println("LeadClubSelect ERROR : " + e);}
           return DTO;
        }
     
     // CLUB SELECT
     public ArrayList<DongariDTO> LeadClubSelect(String ID) {
           ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
           try {
              msg = "SELECT DISTINCT CLUBGENRE,  CLUBCODE, LEADLOCAL FROM TLEADERCLUBLIST WHERE CUSTID='"+ID+"'"; 
              ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            RS = ST.executeQuery(msg);
            RS.last();
            if( RS.getRow()==0) {  return null; }
            RS.beforeFirst();
              while (RS.next() == true) {
                DongariDTO DTO = new DongariDTO();
                DTO.setClubGenre(RS.getString("CLUBGENRE"));
                DTO.setClubCode(RS.getString("CLUBCODE")); 
                DTO.setLeadLocal(RS.getString("LEADLOCAL"));
                DTO.setkLeadLocal(RS.getString("CLUBGENRE"));
                 list.add(DTO);
              }
           } catch (SQLException e) {System.out.println("LeadClubSelect ERROR : " + e);}
           return list;
        }
     
     
     
     // 동아리 SELECT
     public ArrayList<DongariDTO> LeadDongariSelect( String genre, String ID) {
           ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
           try {
              msg = "SELECT  TCI.CLUBTITLE, TCI.CLUBCODE, TCI.CLUBSKILLLEVEL, TO_CHAR(TCI.CLUBDATE,'YY/MM/DD') AS CLUBDATE, "+ 
                    " TO_CHAR(TCI.CLUBSTART,'HH24:MI') AS CLUBSTART, TCI.CLUBLOCATION, \r\n" + 
                    " TCI.CLUBMAX, TCI.CLUBCURRENTNUM, TCI.CLUBAMOUNT, TCI.CLUBTITLECODE \r\n" + 
                    "  FROM TCLUBINFO TCI, TLEADERCLUBLIST TLCL\r\n" + 
                    " WHERE TCI.CLUBCODE  = TLCL.CLUBCODE\r\n" + 
                    "   AND TCI.CLUBGENRE = TLCL.CLUBGENRE\r\n" + 
                    "   AND TLCL.CLUBGENRE LIKE '"+genre+"'\r\n" + 
                    "   AND TCI.CUSTID = TLCL.CUSTID\r\n" + 
                    "   AND TLCL.CUSTID LIKE '"+ID+"'\r\n"+
                    "   ORDER BY TCI.CLUBTITLE, TCI.CLUBSKILLLEVEL";
             System.out.println(msg);
            ST = CN.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            RS = ST.executeQuery(msg);
            
            RS.last();
            if( RS.getRow()==0 ) { return null; }
            RS.beforeFirst();
              while (RS.next() == true) {
              DongariDTO DongDTO = new DongariDTO();
              DongDTO.setClubTitle(RS.getString("CLUBTITLE"));
              DongDTO.setClubCode(RS.getString("CLUBCODE"));
              DongDTO.setLeadLocal(RS.getString("CLUBLOCATION"));
              DongDTO.setClubSkillLevel(RS.getString("CLUBSKILLLEVEL"));
              DongDTO.setClubDate(RS.getString("CLUBDATE"));
              DongDTO.setClubStart(RS.getString("CLUBSTART"));
              DongDTO.setClubMax(RS.getString("CLUBMAX"));
              DongDTO.setClubCurrentNum(RS.getString("CLUBCURRENTNUM"));
              DongDTO.setClubAmount(RS.getString("CLUBAMOUNT"));
              DongDTO.setClubTitleCode(RS.getString("CLUBTITLECODE"));
              list.add(DongDTO);
              }
           } catch (SQLException e) {System.out.println("LeadDongariSelect ERROR : " + e);}
           return list;
        }

    // CLUB UPDATE
    public void LeadClubUpdateSelect(DongariDTO DTO) {
       try {
          msg = "UPDATE TCLUBINFO SET     CLUBPICTURE1 ='" + DTO.getClubPicture1() +"', \r\n" 
                + "                     CLUBPICTURE2 ='" + DTO.getClubPicture2() + "',\r\n"
                + "                     CLUBPICTURE3 ='" + DTO.getClubPicture3() + "',\r\n"
                + "                     CLUBPICTURE4 ='" + DTO.getClubPicture4() + "',\r\n"
                + "                     CLUBMAX = '"      + DTO.getClubMax() + "',\r\n"
                + "                     CLUBADDRESS = '" + DTO.getClubAddress() + "',\r\n"
                + "                     CLUBSUPPLIES = '" + DTO.getClubSupplies() + "',\r\n" 
                + "                     CLUBINTRO = '" + DTO.getClubIntro() + "'\r\n" 
                + "               WHERE CLUBCODE LIKE '" + DTO.getClubCode() + "'\r\n"
                + "                 AND TO_CHAR(CLUBDATE, 'YY/MM/DD') LIKE '" + DTO.getClubDate() + "'\r\n"
                + "                 AND TO_CHAR(CLUBSTART, 'HH24:MI') LIKE '" + DTO.getClubStart() + "'\r\n"
                + "                 AND CLUBTITLECODE LIKE '" + DTO.getClubTitleCode() + "'\r\n"
                + "                 AND CUSTID LIKE '" + DTO.getCustId() + "'";
          System.out.println(msg);
          PST = CN.prepareStatement(msg);
          PST.executeUpdate();
       } catch (Exception e) {
          System.out.println("LeadClubUpdateSelect ERROR : " + e);
       }

    }
     
     
     
}
