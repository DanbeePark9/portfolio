package club.pjt.sql;

public class DongariLeaderDTO {

   private String custid;
   private String leadname;
   private String custpicture;
   private String clubintro;
   
   private String Expertise1;
   private String ExpertStart1;
   private String ExpertEnd1;
   private String Expertise2;
   private String ExpertStart2;
   private String ExpertEnd2;
   private String Expertise3;
   private String ExpertStart3;
   private String ExpertEnd3;
   private String Expertise4;
   private String ExpertStart4;
   private String ExpertEnd4;
   private String Expertise5;
   private String ExpertStart5;
   private String ExpertEnd5;
   
   private String License1;
   private String License2;
   private String License3;
   private String License4;
   private String License5;
   
   public String getCustid() {
      return custid;
   }
   public void setCustid(String custid) {
      this.custid = custid;
   }
   public String getLeadname() {
      return leadname;
   }
   public void setLeadname(String leadname) {
      this.leadname = leadname;
   }
   public String getCustpicture() {
      return custpicture;
   }
   public void setCustpicture(String custpicture) {
      this.custpicture = custpicture;
   }
   public String getClubintro() {
      return clubintro;
   }
   public void setClubintro(String clubintro) {
      this.clubintro = clubintro;
   }
   public String getExpertise1() {
      return Expertise1;
   }
   public void setExpertise1(String expertise1) {
      Expertise1 = expertise1;
   }
   public String getExpertStart1() {
      return ExpertStart1;
   }
   public void setExpertStart1(String expertStart1) {
      ExpertStart1 = expertStart1;
   }
   public String getExpertEnd1() {
      return ExpertEnd1;
   }
   public void setExpertEnd1(String expertEnd1) {
      ExpertEnd1 = expertEnd1;
   }
   public String getExpertise2() {
      return Expertise2;
   }
   public void setExpertise2(String expertise2) {
      Expertise2 = expertise2;
   }
   public String getExpertStart2() {
      return ExpertStart2;
   }
   public void setExpertStart2(String expertStart2) {
      ExpertStart2 = expertStart2;
   }
   public String getExpertEnd2() {
      return ExpertEnd2;
   }
   public void setExpertEnd2(String expertEnd2) {
      ExpertEnd2 = expertEnd2;
   }
   public String getExpertise3() {
      return Expertise3;
   }
   public void setExpertise3(String expertise3) {
      Expertise3 = expertise3;
   }
   public String getExpertStart3() {
      return ExpertStart3;
   }
   public void setExpertStart3(String expertStart3) {
      ExpertStart3 = expertStart3;
   }
   public String getExpertEnd3() {
      return ExpertEnd3;
   }
   public void setExpertEnd3(String expertEnd3) {
      ExpertEnd3 = expertEnd3;
   }
   public String getExpertise4() {
      return Expertise4;
   }
   public void setExpertise4(String expertise4) {
      Expertise4 = expertise4;
   }
   public String getExpertStart4() {
      return ExpertStart4;
   }
   public void setExpertStart4(String expertStart4) {
      ExpertStart4 = expertStart4;
   }
   public String getExpertEnd4() {
      return ExpertEnd4;
   }
   public void setExpertEnd4(String expertEnd4) {
      ExpertEnd4 = expertEnd4;
   }
   public String getExpertise5() {
      return Expertise5;
   }
   public void setExpertise5(String expertise5) {
      Expertise5 = expertise5;
   }
   public String getExpertStart5() {
      return ExpertStart5;
   }
   public void setExpertStart5(String expertStart5) {
      ExpertStart5 = expertStart5;
   }
   public String getExpertEnd5() {
      return ExpertEnd5;
   }
   public void setExpertEnd5(String expertEnd5) {
      ExpertEnd5 = expertEnd5;
   }
   public String getLicense1() {
      return License1;
   }
   public void setLicense1(String license1) {
      License1 = license1;
   }
   public String getLicense2() {
      return License2;
   }
   public void setLicense2(String license2) {
      License2 = license2;
   }
   public String getLicense3() {
      return License3;
   }
   public void setLicense3(String license3) {
      License3 = license3;
   }
   public String getLicense4() {
      return License4;
   }
   public void setLicense4(String license4) {
      License4 = license4;
   }
   public String getLicense5() {
      return License5;
   }
   public void setLicense5(String license5) {
      License5 = license5;
   }

   
}