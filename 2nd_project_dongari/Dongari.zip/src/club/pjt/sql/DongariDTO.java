package club.pjt.sql;

import club.pjt.check.pageNum;

public class DongariDTO {
   private String rowNum;
   private String CustId;
   private String CustName;
   private String ClubCode;
   private String CreateDate;
   private String CloseDate;
   private String ClubGenre;
   private String ClubIntro;
   private String file;
   private String ClubTitle;
   private String ClubDate;
   private String ClubMonthlySum;
   private String ClubStart;
   private String ClubEnd;
   private String ClubPicture1;
   private String ClubPicture2;
   private String ClubPicture3;
   private String ClubPicture4;
   private String ClubMax;
   private String ClubCurrentNum;
   private String ClubLocation;
   private String ClubAddress;
   private String ClubSupplies;
   private String ClubAmount;
   private String ClubSkillLevel;
   private String SettlementAmount;
   private String ClubAmtSum;
   private String AvgStarLevel;
   private String LeadLocal;
   private pageNum PageData;
   private String RePicture;
   private int rcnt;
   private int rn;
   private String LeadName;
   private String ClubTitleCode;
   private String CustPassword;
   private String kLeadLocal;

	public String getCustPassword() {
		return CustPassword;
	}

	public void setCustPassword(String custPassword) {
		CustPassword = custPassword;
	}

	public String getClubTitleCode() {
		return ClubTitleCode;
	}

	public void setClubTitleCode(String clubTitleCode) {
		ClubTitleCode = clubTitleCode;
	}

	public String getLeadName() {
		return LeadName;
	}

	public void setLeadName(String leadName) {
		LeadName = leadName;
	}

	public int getRn() {
		return rn;
	}

	public void setRn(int rn) {
		this.rn = rn;
	}

	public int getRcnt() {
 		return rcnt;
 	}

 	public void setRcnt(int rcnt) {
 		this.rcnt = rcnt;
 	}
public String getRePicture() {
		return RePicture;
	}
public void setRePicture(String rePicture) {
		RePicture = rePicture;
	}
public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
public String getClubPicture1() {
		return ClubPicture1;
	}
	public void setClubPicture1(String clubPicture1) {
		ClubPicture1 = clubPicture1;
	}
	
public String getClubPicture2() {
		return ClubPicture2;
	}
	public void setClubPicture2(String clubPicture2) {
		ClubPicture2 = clubPicture2;
	}
	public String getClubPicture3() {
		return ClubPicture3;
	}
	public void setClubPicture3(String clubPicture3) {
		ClubPicture3 = clubPicture3;
	}
	public String getClubPicture4() {
		return ClubPicture4;
	}
	public void setClubPicture4(String clubPicture4) {
		ClubPicture4 = clubPicture4;
	}
public String getClubSkillLevel() {
		return ClubSkillLevel;
	}
	public void setClubSkillLevel(String clubSkillLevel) {
		ClubSkillLevel = clubSkillLevel;
	}
public String getLeadLocal() {
		return LeadLocal;
	}
	public void setLeadLocal(String leadLocal) {
		LeadLocal = leadLocal;
	}
public String getRowNum() {
   return rowNum;
}

public void setRowNum(String rowNum) {
   this.rowNum = rowNum;
}

public String getCustId() {
   return CustId;
}

public void setCustId(String custId) {
   CustId = custId;
}

public String getCustName() {
   return CustName;
}

public void setCustName(String custName) {
   CustName = custName;
}

public String getClubCode() {
   return ClubCode;
}

public void setClubCode(String clubCode) {
   ClubCode = clubCode;
}

public String getCreateDate() {
   return CreateDate;
}

public void setCreateDate(String createDate) {
   CreateDate = createDate;
}

public String getCloseDate() {
   return CloseDate;
}

public void setCloseDate(String closeDate) {
   CloseDate = closeDate;
}

public String getClubGenre() {
   return ClubGenre;
}

public void setClubGenre(String clubGenre) {
   ClubGenre = clubGenre;
}

public String getClubIntro() {
   return ClubIntro;
}

public void setClubIntro(String clubIntro) {
   ClubIntro = clubIntro;
}

public String getClubTitle() {
   return ClubTitle;
}

public void setClubTitle(String clubTitle) {
   ClubTitle = clubTitle;
}

public String getClubDate() {
   return ClubDate;
}

public void setClubDate(String clubDate) {
   ClubDate = clubDate;
}

public String getClubMonthlySum() {
   return ClubMonthlySum;
}

public void setClubMonthlySum(String clubMonthlySum) {
   ClubMonthlySum = clubMonthlySum;
}

public String getClubStart() {
   return ClubStart;
}

public void setClubStart(String clubStart) {
   ClubStart = clubStart;
}

public String getClubEnd() {
   return ClubEnd;
}

public void setClubEnd(String clubEnd) {
   ClubEnd = clubEnd;
}
public String getClubMax() {
   return ClubMax;
}

public void setClubMax(String clubMax) {
   ClubMax = clubMax;
}

public String getClubCurrentNum() {
   return ClubCurrentNum;
}

public void setClubCurrentNum(String clubCurrentNum) {
   ClubCurrentNum = clubCurrentNum;
}

public String getClubLocation() {
   return ClubLocation;
}

public void setClubLocation(String clubLocation) {
   ClubLocation = clubLocation;
}

public String getClubAddress() {
   return ClubAddress;
}

public void setClubAddress(String clubAddress) {
   ClubAddress = clubAddress;
}

public String getClubSupplies() {
   return ClubSupplies;
}

public void setClubSupplies(String clubSupplies) {
   ClubSupplies = clubSupplies;
}

public String getClubAmount() {
   return ClubAmount;
}

public void setClubAmount(String clubAmount) {
   ClubAmount = clubAmount;
}

public String getSettlementAmount() {
   return SettlementAmount;
}

public void setSettlementAmount(String settlementAmount) {
   SettlementAmount = settlementAmount;
}

public String getClubAmtSum() {
   return ClubAmtSum;
}

public void setClubAmtSum(String clubAmtSum) {
   ClubAmtSum = clubAmtSum;
}

public String getAvgStarLevel() {
   return AvgStarLevel;
}

public void setAvgStarLevel(String avgStarLevel) {
   AvgStarLevel = avgStarLevel;
}

public pageNum getPageData() {
   return PageData;
}

public void setPageData(pageNum pageData) {
   PageData = pageData;
}

// 평점을 별로 표시하기 위해 추가한 속성입니다.
private String average;

public String getAverage() {
	return average;
}

public void setAverage(String average) {
   if( average.equals("5")) {
      this.average = "★★★★★";
   }else if( average.equals("4")) {
      this.average = "★★★★☆";         
   }else if( average.equals("3")) {
      this.average = "★★★☆☆";
   }else if( average.equals("2")) {
      this.average = "★★☆☆☆";
   }else if( average.equals("1")) {
      this.average = "★☆☆☆☆";
   }else {
      this.average = "☆☆☆☆☆";
   }
}

// dselect.do 에서 사용
public void setDongDetail1(String CustId, String ClubCode, String ClubDate) {

   this.CustId = CustId;
   this.ClubCode = ClubCode;
   this.ClubDate = ClubDate;
}

// dselect.do 에서 사용
public void setDongDetail2(String CustId, String ClubCode, String ClubTitleCode) {

   this.CustId = CustId;
   this.ClubCode = ClubCode;
   this.ClubTitleCode = ClubTitleCode;
}
public String getkLeadLocal() {
  return kLeadLocal;
}

public void setkLeadLocal(String LeadLocal) {
  club.pjt.check.ClubGenre GG = new club.pjt.check.ClubGenre();
  this.kLeadLocal =  GG.ClubGenreToKorean(LeadLocal);
}
}