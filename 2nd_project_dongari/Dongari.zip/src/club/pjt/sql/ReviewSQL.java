package club.pjt.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ReviewSQL {
	
  Connection CN;
  Statement ST; 
  PreparedStatement PST;
  CallableStatement CST; 
  ResultSet RS; 
  String msg;
  
  public ReviewSQL() {
    CN = DB.getConnection();
 }
  
  public List<ReviewDTO> StudentReview(String ID) {

    List<ReviewDTO> list = new ArrayList<ReviewDTO>();
    try {
       msg = "SELECT CI.CLUBTITLE, TCI.CUSTPICTURE,\r\n" + 
             "       TO_CHAR( TSCI.CLUBDATE,'YY/MM/DD') AS CLUBDATE,\r\n" + 
             "       TSCI.REVIEW, TSCI.REVIEWDATE,\r\n" + 
             "       TSCI.STARLEVEL1, TSCI.STARLEVEL2, TSCI.STARLEVEL3\r\n" + 
             "  FROM TSTUDENTCOURSEINFO TSCI, TCLUBINFO CI,  TCUSTOMERINFO  TCI\r\n" + 
             " WHERE TCI.CUSTID   =  TSCI.CUSTID\r\n" + 
             "   AND CI.CLUBCODE  = TSCI.CLUBCODE\r\n" + 
             "   AND CI.CLUBDATE  = TSCI.CLUBDATE\r\n" + 
             "   AND CI.CLUBSTART = TSCI.CLUBSTART\r\n" + 
             "   AND TSCI.CUSTID='"+ID+"'";
       System.out.println(msg);
       ST = CN.createStatement();
       RS = ST.executeQuery(msg);
       
       while (RS.next() == true) {
          ReviewDTO DTO = new ReviewDTO();
          DTO.setCustId(ID);
          DTO.setClubTitle(RS.getString("CLUBTITLE"));
          DTO.setCustPicture(RS.getString("CUSTPICTURE"));
          DTO.setClubDate(RS.getString("CLUBDATE"));
          String REVIEW = RS.getString("REVIEW");
          if(REVIEW==null||REVIEW==""){
             return null;
          }else {
             DTO.setReview(REVIEW);
          }
          DTO.setReviewDate(RS.getString("REVIEWDATE"));
          DTO.setStarLevel1(RS.getString("STARLEVEL1"));
          DTO.setStarLevel2(RS.getString("STARLEVEL2"));
          DTO.setStarLevel3(RS.getString("STARLEVEL3"));
          list.add(DTO);
       }
    } catch (SQLException e) {System.out.println("StudentReview ERROR : " + e);}
    return list;
 }
	
	//0920일요일 추가=================================================================
	//후기를 모두 작성한 사람과 작성하지 않은 사람 구분
	public int ReviewCheck(String CustId) {
		int CheckResult = 0; //후기 있으면 1, 없으면0
		try {
			msg="SELECT count(*) AS CNT FROM TSTUDENTCOURSEINFO WHERE CUSTID='"+CustId+"' \r\n" + 
					"AND REVIEW IS NULL";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			int cnt = RS.getInt("CNT");
			if(cnt>0) {
				CheckResult = 1;
			} else {
				CheckResult = 0;
			}
		} catch (Exception e) {System.out.println("[ReviewCheck] ERROR : " + e);}
		return CheckResult;
	}
	
  //작성되지 않은 후기가 몇개인지 카운트
	public int NotWrittendReviewCount(String CustId) {
		int cnt=0;
		try {
			msg="SELECT COUNT(*) AS CNT \r\n" + 
					"FROM TSTUDENTCOURSEINFO\r\n" + 
					"WHERE CUSTID='"+CustId+"'\r\n" + 
					"AND REVIEW IS NULL";
			ST = CN.createStatement();
			RS = ST.executeQuery(msg);
			RS.next();
			cnt=RS.getInt("CNT"); // 작성이 안된 후기가 몇개인지 출력
		} catch (Exception e) {System.out.println("[NotWrittendReviewCount] ERROR : " + e);}
		return cnt;
	}
	
	//작성되지 않은 후기 리스트 출력
	public ArrayList<DongariDTO> NotWrittendReviewData(String CustId){
		ArrayList<DongariDTO> list = new ArrayList<DongariDTO>();
		try {
			msg="SELECT DISTINCT TCI.CLUBTITLE, TCI.CLUBSTART, TCI.CLUBCODE, TCUI.LEADNAME\r\n" + 
					"FROM TCLUBINFO TCI, TLEADERCLUBLIST TLCL, TCUSTOMERINFO TCUI\r\n" + 
					"WHERE TCI.CLUBCODE=(SELECT CLUBCODE \r\n" + 
					"FROM TSTUDENTCOURSEINFO\r\n" + 
					"WHERE CUSTID='"+CustId+"'\r\n" + 
					"AND REVIEW IS NULL)\r\n" + 
					"AND TLCL.CLUBCODE=TCI.CLUBCODE\r\n" + 
					"AND TCUI.CUSTID=TLCL.CUSTID";
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			while(RS.next() == true){
				DongariDTO DongDTO = new DongariDTO();
				DongDTO.setClubTitle(RS.getString("ClubTitle"));
				DongDTO.setLeadName(RS.getString("LeadName")); //DongariDTO에 LeadName 추가 
				DongDTO.setClubCode(RS.getString("ClubCode"));
				DongDTO.setClubStart(RS.getString("ClubStart"));
				list.add(DongDTO);
			}
		} catch (Exception e) {System.out.println("[NotWrittendReviewData] ERROR : " + e);}
		return list;
	}
	
	//후기 등록
	public void ReviewInsert(String CustId, String starLevel1, String starLevel2, String starLevel3, String review, String ClubCode) {
		try {
			msg="UPDATE TSTUDENTCOURSEINFO SET STARLEVEL1='"+starLevel1+"', STARLEVEL2='"+starLevel2+"', STARLEVEL3='"+starLevel3+"',\r\n" + 
					"REVIEW='"+review+"',REVIEWDATE=sysdate\r\n" + 
					"WHERE CUSTID='"+CustId+"'\r\n" + 
					"AND REVIEW IS NULL \n"		+ 
					"AND CLUBCODE='"+ClubCode+"'";
			ST=CN.createStatement();
			ST.executeUpdate(msg);
			RS.next();
		} catch (Exception e) {System.out.println("[ReviewInsert] ERROR : " + e);}
	}
	
	
	//동아리 평점 갱신
	public void ReviewAVGInsert(String ClubCode, int AVGStarLevel) {
		try {
			//기존의 평점을 출력하는 쿼리
			msg="SELECT DISTINCT AVGSTARLEVEL FROM TCLUBINFO \r\n" + 
					"WHERE CLUBCODE='"+ClubCode+"'";
			ST=CN.createStatement();
			RS=ST.executeQuery(msg);
			RS.next();
			int CurrentAVG = RS.getInt("AVGSTARLEVEL"); //기존의 평점
			int CalculatedAVG = (CurrentAVG + AVGStarLevel)/2; //변경될 평점
			
			//변경 쿼리
			msg="UPDATE TCLUBINFO SET AVGSTARLEVEL='"+CalculatedAVG+"'\r\n" + 
					"WHERE CLUBCODE='"+ClubCode+"'";
			ST=CN.createStatement();
			ST.executeUpdate(msg);
			RS.next(); //평점 변경 완료
		} catch (Exception e) {System.out.println("[ReviewInsert] ERROR : " + e);}
	}
}
