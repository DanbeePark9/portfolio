
package club.pjt.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import club.pjt.check.LeadLocal;

public class CustomerSQL {
  
  Connection CN;
  Statement ST; 
  PreparedStatement PST;
  CallableStatement CST; 
  ResultSet RS; 
  String msg;
  
   String CustId;
   String CustName;
   String CustPass;
   String CustEmail;
   String CustPhone;
   String CustGender;
   String CustBirth;
   String CustAddressess;
   String CustPhoto;
   
   String LeadNick;
   String LeadIntro;
   String LeadAccount;
   String LeadBankName;
   String LeadCertification;
   String LeadGrveDate;
   String LeadStopDate;
   
   CustomerDTO DTO;
   int count;
   
   public CustomerSQL() {
      CN = DB.getConnection();
   }
   
   public int CustLogin(String id, String password) {
      try {
       msg= "SELECT COUNT(CUSTID) AS COUNT FROM TCUSTOMERINFO\r\n" + 
            "WHERE  CUSTID='"+id+"' AND CUSTPASSWORD ='"+password+"'" ;
       ST = CN.createStatement();
       RS = ST.executeQuery(msg);
       RS.next();
       count = Integer.parseInt(RS.getString("COUNT"));
       }catch(Exception ex) { System.out.println("CustLogin ERROR : " + ex);}
      return count; 
    }
      

   public void CustInsert(CustomerDTO DTO){
      try {
         String a = "INSERT INTO TCUSTOMERINFO ( ";
         String b = " CustID, CustName, CustPassword, CustEmail, CustCall, CustGender, CustBirth, CustAddress, CustPicture "; 
         String c = " ) VALUES (?,?,?,?,?,?, TO_DATE(?, 'YY-MM-DD'),?,?)";
         msg = a+b+c;
         
	        PST = CN.prepareStatement(msg);
	        PST.setString(1, DTO.getCustId());
	        PST.setString(2, DTO.getCustName());
	        PST.setString(3, DTO.getCustPass());
	        PST.setString(4, DTO.getCustEmail());
	        PST.setString(5, DTO.getCustPhone());
	        PST.setString(6, DTO.getCustGender());
	        PST.setString(7, DTO.getCustBirth());
	        PST.setString(8, DTO.getCustAddress());
	        PST.setString(9, DTO.getCustPhoto());
	      	PST.executeUpdate(); //진짜저장
      } catch (Exception e) {System.out.println("CustInsert ERROR : "+e);}
   }
   
   
   /*public CustomerDTO CustProfile(String CustId) {
  	 CustomerDTO DTO = new CustomerDTO();
  	 LeadLocal LL = new LeadLocal();
  	 try {
  		 msg="SELECT * FROM TCUSTOMERINFO WHERE CUSTID='"+CustId+"'";
  		 ST=CN.createStatement();
  		 RS=ST.executeQuery(msg);
  		 if(RS.next()==true) {
  			 DTO.setCustId(RS.getString("CustId"));
  			 DTO.setCustName(RS.getString("CustName"));
  			 DTO.setCustEmail(RS.getString("CustEmail"));
  			 DTO.setCustPhone(RS.getString("CustCall"));
  			 DTO.setCustGender(RS.getString("CustGender"));
  			 String birth = RS.getString("CustBirth");
  			 				birth = birth.substring(2,10);
  			 				if(birth.contains("-")) {
  			 					birth = birth.replace("-", "/");
  			 				}
  			 DTO.setCustBirth(birth);
  			 DTO.setCustAddress( LL.LeadLocalToKorean(RS.getString("CustAddress")));
  			 DTO.setCustPhoto(RS.getString("CustPicture"));
  		 }
		} catch (Exception e) {
		}
  	 return DTO;
   }*/
   
   public CustomerDTO CustProfile(String CustId) {
     CustomerDTO DTO = new CustomerDTO();
     LeadLocal LL = new LeadLocal();
     try {
        msg="SELECT CustId, CustName, CustEmail, CustCall, CustGender, TO_CHAR(CustBirth,'YY/MM/DD') AS CustBirth, CustAddress FROM TCUSTOMERINFO WHERE CUSTID='"+CustId+"'";
        ST=CN.createStatement();
        RS=ST.executeQuery(msg);
        if(RS.next()==true) {
           DTO.setCustId(RS.getString("CustId"));
           DTO.setCustName(RS.getString("CustName"));
           DTO.setCustEmail(RS.getString("CustEmail"));
           DTO.setCustPhone(RS.getString("CustCall"));
           DTO.setCustGender(RS.getString("CustGender"));
           DTO.setCustBirth(RS.getString("CustBirth"));
           DTO.setCustAddress( LL.LeadLocalToKorean(RS.getString("CustAddress")));
           DTO.setCustPhoto(RS.getString("CustPicture"));
        }
     } catch (Exception e) {
     }
     return DTO;
  }

   
   public CustomerDTO CustSelect(String CUSTID){
     try {
        msg="SELECT * FROM TCUSTOMERINFO WHERE CUSTID='"+CUSTID+"'";
        ST=CN.createStatement();
        RS=ST.executeQuery(msg);
        RS.next();

        CustomerDTO DTO = new CustomerDTO();
       DTO.setCustId(RS.getString("CUSTID"));
       DTO.setCustName(RS.getString("CUSTNAME"));
       DTO.setCustPass(RS.getString("CUSTPASSWORD"));
       DTO.setCustEmail(RS.getString("CUSTEMAIL"));
       DTO.setCustPhone(RS.getString("CUSTCALL"));
       DTO.setCustGender(RS.getString("CUSTGENDER"));
       DTO.setCustBirth(RS.getString("CUSTBIRTH"));
       DTO.setCustAddress(RS.getString("CUSTADDRESS"));
       DTO.setCustPhoto(RS.getString("CUSTPICTURE"));
                
     } catch (Exception e) {System.out.println("CustSelect : " + e);}
     return DTO;
  }
  
   
   public void CustUpdate(CustomerDTO DTO) {
         try {
         String email =  DTO.getCustEmail();
         String phone =  DTO.getCustPhone();
         String birth =  DTO.getCustBirth();
         String addre =  DTO.getCustAddress();
         String id    =  DTO.getCustId();
               
         msg = "UPDATE TCUSTOMERINFO SET CUSTEMAIL='"+email+"', CUSTCALL='"+phone+"', CUSTBIRTH='"+birth+"', CustAddress='"+addre+"' WHERE CUSTID = '"+id+"'";
         ST = CN.createStatement();
         ST.executeUpdate(msg); 
         }catch(Exception ex) { System.out.println("CustUpdate ERROR : " + ex);}
     }
   
  public void CustEdit(String CustId, String photo, String name, String email, String phone, String birth, String address) {
  	try {
			msg="UPDATE TCUSTOMERINFO SET \r\n" + 
					"CUSTPICTURE='"+photo+"',\r\n" + 
					"CUSTNAME='"+name+"',\r\n" + 
					"CUSTEMAIL='"+email+"',\r\n" + 
					"CUSTCALL='"+phone+"',\r\n" + 
					"CUSTBIRTH='"+birth+"',\r\n" + 
					"CUSTADDRESS='"+address+"'\r\n" + 
					"WHERE CUSTID='"+CustId+"'";
					
					ST = CN.createStatement();
					ST.executeUpdate(msg); 
		} catch (Exception e) {
		}
  }
}