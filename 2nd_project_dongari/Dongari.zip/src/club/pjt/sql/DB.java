package club.pjt.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Date;

public class DB {
  public static Connection getConnection() {
  Connection CN = null;
  try{
  	Class.forName("oracle.jdbc.driver.OracleDriver");
      String url="jdbc:oracle:thin:@127.0.0.1:1521:XE" ;
      CN=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE","system","1234");
      Date now = new Date();
  	}catch(Exception ex){System.out.println("Error name :" + ex);}
  return CN;
  
  }
}// Global class end