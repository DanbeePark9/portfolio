package club.pjt.sql;

public class StudentDTO {
	
	private String CustId;
	private String ClubCode;
	private String ClubDate;
	private String ClubStart;
	private String ApplyDate;
	private String CancelDate;
	private String SettlementType;
	private String SettlementAmount;
	private String StarLevel1;
	private String StarLevel2;
	private String StarLevel3;
	private String Review;
	private String ReviewDate;
	
	public String getCustId() {
		return CustId;
	}
	public void setCustId(String custId) {
		CustId = custId;
	}
	public String getClubCode() {
		return ClubCode;
	}
	public void setClubCode(String clubCode) {
		ClubCode = clubCode;
	}
	public String getClubDate() {
		return ClubDate;
	}
	public void setClubDate(String clubDate) {
		ClubDate = clubDate;
	}
	public String getClubStart() {
		return ClubStart;
	}
	public void setClubStart(String clubStart) {
		ClubStart = clubStart;
	}
	public String getApplyDate() {
		return ApplyDate;
	}
	public void setApplyDate(String applyDate) {
		ApplyDate = applyDate;
	}
	public String getCancelDate() {
		return CancelDate;
	}
	public void setCancelDate(String cancelDate) {
		CancelDate = cancelDate;
	}
	public String getSettlementType() {
		return SettlementType;
	}
	public void setSettlementType(String settlementType) {
		SettlementType = settlementType;
	}
	
	public String getSettlementAmount() {
		return SettlementAmount;
	}
	public void setSettlementAmount(String settlementAmount) {
		SettlementAmount = settlementAmount;
	}
	public String getStarLevel1() {
		return StarLevel1;
	}
	public void setStarLevel1(String starLevel1) {
		StarLevel1 = starLevel1;
	}
	public String getStarLevel2() {
		return StarLevel2;
	}
	public void setStarLevel2(String starLevel2) {
		StarLevel2 = starLevel2;
	}
	public String getStarLevel3() {
		return StarLevel3;
	}
	public void setStarLevel3(String starLevel3) {
		StarLevel3 = starLevel3;
	}
	public String getReview() {
		return Review;
	}
	public void setReview(String review) {
		Review = review;
	}
	public String getReviewDate() {
		return ReviewDate;
	}
	public void setReviewDate(String reviewDate) {
		ReviewDate = reviewDate;
	}
	
	
}
