package club.pjt.check;

public class LeadLocal {
	public String LeadLocalToKorean(String LeadLocal) {
		
		switch(LeadLocal) {
		case "00":LeadLocal="서울";
				 break;
		case "13":LeadLocal="인천";
		 break;
		case "16":LeadLocal="경기";
		 break;
		case "26":LeadLocal="강원";
		 break;
		case "09":LeadLocal="부산";
		 break;
		case "67":LeadLocal="대구";
		 break;
		case "35":LeadLocal="충청";
		 break;
		case "40":LeadLocal="대전";
		 break;
		case "41":LeadLocal="충남";
		 break;
		case "44":LeadLocal="세종";
		 break;
		case "48":LeadLocal="전북";
		 break;
		case "55":LeadLocal="전남";
		 break;
		case "70":LeadLocal="경북";
		 break;
		case "82":LeadLocal="경남";
		 break;
		case "85":LeadLocal="울산";
		 break;
		case "93":LeadLocal="제주";
		 break;
		}
		return LeadLocal;
	}
}
