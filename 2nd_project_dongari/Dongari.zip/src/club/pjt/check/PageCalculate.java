package club.pjt.check;

public class PageCalculate {
      public pageNum LeaderDetailPage(int ToalSize, int pagenum ) {

            pageNum PAGE = new pageNum();

            if (pagenum == 0) {
               pagenum = 1;
            }

            int start = (pagenum - 1) * 10 + 1;
            int end = pagenum * 10;
            
            int tmp = (pagenum - 1) % 10;
            int startpage = pagenum - tmp;
            int endpage   = startpage + 9;
            int pagecount;

            if (ToalSize % 10 == 0) {
               pagecount = ToalSize / 10;
            } else {
               pagecount = (ToalSize / 10) + 1;
            }

            if (endpage > pagecount) {
               endpage = pagecount;
            }

            PAGE.setTotal(ToalSize);
            PAGE.setPagenum(pagenum);
            PAGE.setStart(start);
            PAGE.setEnd(end);
            PAGE.setStartpage(startpage);
            PAGE.setEndpage(endpage);
            PAGE.setPagecount(pagecount);

            return PAGE;
         }
      // 리더 동아리 후기 페이징
      public pageNum LeaderReviewPage(int ToalSize, int pagenum ) {

            pageNum PAGE = new pageNum();

            if ( pagenum == 0  ) {
               pagenum = 1;
            }
            //System.out.println(" LeaderReviewPage pagenum > " + pagenum +"  ToalSize>  "+ ToalSize );
            
            int start = (pagenum - 1) * 5 + 1;
            int end = pagenum * 5;
            //System.out.println(" LeaderReviewPage start > " + start +"  end >  "+ end );
            int tmp = (pagenum - 1) % 5;
            int startpage = pagenum - tmp;
            int endpage   = startpage + 4;
            int pagecount;
            //System.out.println(" LeaderReviewPage startpage > " + startpage +"  endpage >  "+ endpage );
            
            if (ToalSize % 5 == 0) {
               pagecount = ToalSize / 5;
            } else {
               pagecount = (ToalSize / 5) + 1;
            }

            if (endpage > pagecount) {
               endpage = pagecount;
            }
            //System.out.println(" LeaderReviewPage pagecount > " + pagecount +"  endpage >  "+ endpage );
            PAGE.setTotal(ToalSize);
            PAGE.setPagenum(pagenum);
            PAGE.setStart(start);
            PAGE.setEnd(end);
            PAGE.setStartpage(startpage);
            PAGE.setEndpage(endpage);
            PAGE.setPagecount(pagecount);

            return PAGE;
         }
}