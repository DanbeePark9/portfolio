package club.pjt.check;

public class ClubGenre {

  //알파벳으로 받은 클럽코드를 한글로번역하기
  public String ClubGenreToKorean(String ClubCodeAlphabet) {
 	 
 	 String ClubCode="";
 	 switch (ClubCodeAlphabet) {
 	 case "A" : ClubCode="축구";
 		 		break;
 	 case "B" : ClubCode="야구";
	 		break;
 	 case "C" : ClubCode="투포환";
	 		break;
 	 case "D" : ClubCode="족구";
	 		break;
 	 case "E" : ClubCode="수영";
	 		break;
 	 case "F" : ClubCode="요가";
	 		break;
 	 case "G" : ClubCode="사격";
	 		break;
 	 case "H" : ClubCode="스쿼시";
	 		break;
 	 case "I" : ClubCode="조깅";
	 		break;
 	 case "J" : ClubCode="육상";
	 		break;
 	 case "K" : ClubCode="등산";
	 		break;
 	 case "L" : ClubCode="핸드볼";
	 		break;
 	 case "M" : ClubCode="스트레칭";
	 		break;
 	 case "N" : ClubCode="헬스";
	 		break;
 	 case "O" : ClubCode="배드민턴";
	 		break;
 	 case "P" : ClubCode="스피드스케이팅";
	 		break;
 	 case "Q" : ClubCode="유도";
	 		break;
 	 case "R" : ClubCode="역도";
	 		break;
 	 case "S" : ClubCode="태권도";
	 		break;
 	 case "T" : ClubCode="체조";
	 		break;
 	 case "U" : ClubCode="테니스";
	 		break;
 	 case "V" : ClubCode="씨름";
	 		break;
 	 case "W" : ClubCode="암벽타기";
	 		break;
 	 case "X" : ClubCode="수구";
	 		break;
 	 case "Y" : ClubCode="마라톤";
	 		break;
 	 case "Z" : ClubCode="복싱";
	 		break;
 	 }
 	 return ClubCode;
  }
}
